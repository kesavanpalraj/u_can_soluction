import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Navigation } from './components/Navigation';
import { Footer } from './components/Footer';
import { WhatsAppButton } from './components/WhatsAppButton';
import { ToastProvider } from './components/Toast';
import { Home } from './pages/Home';
import { Projects } from './pages/Projects';
import { Courses } from './pages/Courses';
import { Internships } from './pages/Internships';
import { About } from './pages/About';
import { Admin } from './pages/Admin/Admin';
import { Dashboard } from './pages/Admin/Dashboard';
import { Projects as AdminProjects } from './pages/Admin/Projects';
import { Courses as AdminCourses } from './pages/Admin/Courses';
import { Internships as AdminInternships } from './pages/Admin/Internships';
import { Homepage } from './pages/Admin/Homepage/Homepage';
import { About as AdminAbout } from './pages/Admin/About/About';
import { Login } from './pages/Admin/Login';

import { Trash } from './pages/Admin/Trash';
import { Archive } from './pages/Admin/Archive';
import './styles/global.css';

const App: React.FC = () => {
  return (
    <ToastProvider>
      <Router>
        <Routes>
          <Route path="/" element={<><Navigation /><main><Home /></main><Footer /><WhatsAppButton /></>} />
          <Route path="/projects" element={<><Navigation /><main><Projects /></main><Footer /><WhatsAppButton /></>} />
          <Route path="/courses" element={<><Navigation /><main><Courses /></main><Footer /><WhatsAppButton /></>} />
          <Route path="/internships" element={<><Navigation /><main><Internships /></main><Footer /><WhatsAppButton /></>} />
          <Route path="/about" element={<><Navigation /><main><About /></main><Footer /><WhatsAppButton /></>} />
          <Route path="/admin/login" element={<Login />} />
          <Route path="/admin" element={<Admin />}>
            <Route index element={<Dashboard />} />
            <Route path="projects" element={<AdminProjects />} />
            <Route path="courses" element={<AdminCourses />} />
            <Route path="internships" element={<AdminInternships />} />
            <Route path="homepage" element={<Homepage />} />
            <Route path="about" element={<AdminAbout />} />

            <Route path="trash" element={<Trash />} />
            <Route path="archive" element={<Archive />} />
          </Route>
        </Routes>
      </Router>
    </ToastProvider>
  );
};

export default App;
