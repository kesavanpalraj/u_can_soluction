import React from 'react';
import styles from './Input.module.css';

type InputProps = React.InputHTMLAttributes<HTMLInputElement> & {
  variant?: 'default' | 'outline' | 'ghost';
};

export const Input: React.FC<InputProps> = ({ variant = 'default', className = '', ...props }) => {
  return (
    <input className={`${styles.input} ${styles[variant]} ${className}`} {...props} />
  );
};
