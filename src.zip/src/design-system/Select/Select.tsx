import React from 'react';
import styles from './Select.module.css';

type Option = { value: string; label: string };

type SelectProps = React.SelectHTMLAttributes<HTMLSelectElement> & {
  options: Option[];
};

export const Select: React.FC<SelectProps> = ({ options, className, ...props }) => {
  return (
    <select className={`${styles.select}${className ? ` ${className}` : ''}`} {...props}>
      {options.map((o) => (
        <option key={o.value} value={o.value}>{o.label}</option>
      ))}
    </select>
  );
};
