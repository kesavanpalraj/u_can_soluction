import React from 'react';
import styles from './Card.module.css';

interface CardProps {
  title?: string;
  children: React.ReactNode;
  className?: string;
  variant?: 'default' | 'plain';
}

export const Card: React.FC<CardProps> = ({ title, children, className = '', variant = 'default' }) => {
  return (
    <section className={`${styles.card} ${styles[variant]} ${className}`}>
      {title && <div className={styles.cardHeader}>{title}</div>}
      <div className={styles.cardBody}>{children}</div>
    </section>
  );
};
