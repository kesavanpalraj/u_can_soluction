import React from 'react';

type HeadingProps = {
  as?: 'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'h6';
  className?: string;
  children: React.ReactNode;
};

export const Heading: React.FC<HeadingProps> = ({ as = 'h2', className = '', children }) => {
  const Tag = as as keyof JSX.IntrinsicElements;
  return (
    <Tag style={{ fontFamily: 'var(--font-heading)', fontWeight: 700 }} className={className}>
      {children}
    </Tag>
  );
};
