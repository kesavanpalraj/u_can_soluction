import { useState, useRef, useEffect } from 'react';
import { ChevronDown } from 'lucide-react';
import styles from './StatusDropdown.module.css';

interface StatusDropdownProps {
    value: string;
    options: string[];
    onChange: (value: string) => void;
    size?: 'sm' | 'md';
}

export const StatusDropdown: React.FC<StatusDropdownProps> = ({ value, options, onChange, size = 'sm' }) => {
    const [open, setOpen] = useState(false);
    const [positionUp, setPositionUp] = useState(false);
    const triggerRef = useRef<HTMLButtonElement>(null);
    const menuRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handleClickOutside = (e: MouseEvent) => {
            if (
                triggerRef.current && !triggerRef.current.contains(e.target as Node) &&
                menuRef.current && !menuRef.current.contains(e.target as Node)
            ) {
                setOpen(false);
            }
        };
        const handleEscape = (e: KeyboardEvent) => {
            if (e.key === 'Escape') setOpen(false);
        };
        if (open) {
            document.addEventListener('mousedown', handleClickOutside);
            document.addEventListener('keydown', handleEscape);
        }
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
            document.removeEventListener('keydown', handleEscape);
        };
    }, [open]);

    useEffect(() => {
        if (open && triggerRef.current && menuRef.current) {
            const rect = triggerRef.current.getBoundingClientRect();
            const menuHeight = menuRef.current.scrollHeight;
            const spaceBelow = window.innerHeight - rect.bottom;
            const spaceAbove = rect.top;
            const up = menuHeight > spaceBelow && spaceAbove > spaceBelow;
            setPositionUp(up);
            menuRef.current.style.top = `${up ? rect.top - menuHeight : rect.bottom}px`;
            menuRef.current.style.left = `${rect.left}px`;
            menuRef.current.style.width = `${rect.width}px`;
        }
    }, [open]);

    const handleSelect = (opt: string) => {
        onChange(opt);
        setOpen(false);
    };

    return (
        <>
            <button
                ref={triggerRef}
                type="button"
                className={`${styles.trigger} ${size === 'md' ? styles.triggerMd : ''}`}
                onClick={() => setOpen(o => !o)}
                onMouseDown={(e) => e.stopPropagation()}
                aria-haspopup="listbox"
                aria-expanded={open}
            >
                <span className={styles.value}>{value.replace('_', ' ')}</span>
                <ChevronDown size={size === 'md' ? 14 : 12} className={`${styles.chevron} ${open ? styles.chevronOpen : ''}`} />
            </button>
            {open && (
                <div
                    ref={menuRef}
                    className={`${styles.menu} ${positionUp ? styles.menuUp : ''}`}
                    style={{ position: 'fixed', zIndex: 9999 }}
                    role="listbox"
                >
                    {options.map((opt) => (
                        <button
                            key={opt}
                            type="button"
                            role="option"
                            aria-selected={opt === value}
                            className={`${styles.option} ${opt === value ? styles.optionSelected : ''}`}
                            onClick={() => handleSelect(opt)}
                            onMouseDown={(e) => e.stopPropagation()}
                        >
                            {opt.replace('_', ' ')}
                        </button>
                    ))}
                </div>
            )}
        </>
    );
};
