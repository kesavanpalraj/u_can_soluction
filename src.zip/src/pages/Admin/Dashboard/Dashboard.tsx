import { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { Inbox, Clock, AlertCircle, FolderOpen, BookOpen, Briefcase, ArrowRight, ChevronRight, ChevronLeft, Check, CheckCircle, Trash2 } from 'lucide-react';
import { Drawer } from '../../../components/Drawer';
import { useToast } from '../../../components/Toast';
import { StatusDropdown } from './StatusDropdown';
import { Button } from '../../../components/Button';
import { ConfirmModal } from '../../../components/Modal';
import styles from './Dashboard.module.css';

interface Stats {
    total: number;
    new: number;
    thisWeek: number;
}

interface Enquiry {
    _id: string;
    type: 'project' | 'course' | 'internship';
    name: string;
    email: string;
    phone: string;
    college?: string;
    message?: string;
    item: { title?: string; projectId?: string; courseId?: string; internshipId?: string } | null;
    status: string;
    picked: boolean;
    createdAt: string;
    gender?: string;
    address?: string;
    degree?: string;
    yearOfStudy?: string;
    collegeLocation?: string;
    domain?: string;
    duration?: string;
    mode?: string;
}

const ALL_STATUS_OPTIONS: Record<string, string[]> = {
    inbox: ['new', 'reviewed'],
        activity: ['todo', 'in_progress'],
};

export const Dashboard: React.FC = () => {
    const [stats, setStats] = useState<Stats>({ total: 0, new: 0, thisWeek: 0 });
    const [enquiries, setEnquiries] = useState<Enquiry[]>([]);
    const [loading, setLoading] = useState(true);
    const [page, setPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const [inboxCount, setInboxCount] = useState(0);
    const [activityCount, setActivityCount] = useState(0);
    const [tab, setTab] = useState<'inbox' | 'activity'>('inbox');
    const [selectedEnquiry, setSelectedEnquiry] = useState<Enquiry | null>(null);
    const [drawerOpen, setDrawerOpen] = useState(false);
    const [confirmDelete, setConfirmDelete] = useState<Enquiry | null>(null);
    const { addToast } = useToast();

    useEffect(() => {
        fetchStats();
    }, []);

    useEffect(() => {
        setPage(1);
    }, [tab]);

    useEffect(() => {
        fetch('/api/enquiries/unified?page=1&limit=1&picked=true')
            .then(res => res.ok && res.json())
            .then(data => { if (data) setActivityCount(data.total); })
            .catch(() => {});
    }, []);

    const fetchEnquiries = useCallback(async () => {
        setLoading(true);
        try {
            const res = await fetch(`/api/enquiries/unified?page=${page}&limit=20&picked=${tab === 'activity'}`);
            if (res.ok) {
                const data = await res.json();
                setEnquiries(data.enquiries || []);
                setTotalPages(data.totalPages || 1);
                if (tab === 'inbox') {
                    setInboxCount(data.total || 0);
                } else {
                    setActivityCount(data.total || 0);
                }
            }
        } catch (error) {
            console.error('Failed to fetch enquiries:', error);
        } finally {
            setLoading(false);
        }
    }, [page, tab]);

    useEffect(() => {
        fetchEnquiries();
    }, [fetchEnquiries]);

    const fetchStats = async () => {
        try {
            const res = await fetch('/api/enquiries/stats');
            if (res.ok) {
                const data = await res.json();
                setStats(data);
            }
        } catch (error) {
            console.error('Failed to fetch stats:', error);
        }
    };

    const openDrawer = (enquiry: Enquiry) => {
        setSelectedEnquiry(enquiry);
        setDrawerOpen(true);
    };

    const closeDrawer = () => {
        setDrawerOpen(false);
        setSelectedEnquiry(null);
    };

    const handleStatusChange = async (enquiry: Enquiry, newStatus: string) => {
        try {
            const res = await fetch(`/api/enquiries/status/${enquiry._id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ type: enquiry.type, status: newStatus })
            });
            if (res.ok) {
                addToast(`Status updated to ${newStatus}`, 'success');
                fetchEnquiries();
            }
        } catch (error) {
            console.error('Failed to update status:', error);
            addToast('Failed to update status', 'error');
        }
    };

    const handlePick = async (enquiry: Enquiry) => {
        try {
            const res = await fetch(`/api/enquiries/pick/${enquiry._id}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ type: enquiry.type })
            });
            if (res.ok) {
                addToast('Moved to Activity', 'success');
                closeDrawer();
                fetchEnquiries();
            }
        } catch (error) {
            console.error('Failed to pick enquiry:', error);
            addToast('Failed to pick enquiry', 'error');
        }
    };

    const handleArchive = async (enquiry: Enquiry) => {
        try {
            const res = await fetch(`/api/enquiries/archive/${enquiry._id}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ type: enquiry.type })
            });
            if (res.ok) {
                addToast('Enquiry archived', 'success');
                closeDrawer();
                fetchEnquiries();
            }
        } catch (error) {
            console.error('Failed to archive enquiry:', error);
            addToast('Failed to archive enquiry', 'error');
        }
    };

    const handleTrash = async (enquiry: Enquiry) => {
        try {
            const res = await fetch(`/api/enquiries/trash/${enquiry._id}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ type: enquiry.type })
            });
            if (res.ok) {
                addToast('Moved to Trash', 'success');
                closeDrawer();
                setPage(1);
                fetchEnquiries();
            } else {
                const err = await res.json().catch(() => ({ message: 'Failed to trash enquiry' }));
                addToast(err.message, 'error');
            }
        } catch (error) {
            console.error('Failed to trash enquiry:', error);
            addToast('Failed to trash enquiry', 'error');
        }
    };

    const getTypeIcon = (type: string) => {
        switch (type) {
            case 'project': return <FolderOpen size={16} />;
            case 'course': return <BookOpen size={16} />;
            case 'internship': return <Briefcase size={16} />;
            default: return <Inbox size={16} />;
        }
    };

    const getTypeName = (type: string) => type.charAt(0).toUpperCase() + type.slice(1);

    const getItemTitle = (enquiry: Enquiry): string => {
        if (enquiry.type === 'internship') return enquiry.domain || '-';
        return enquiry.item?.title || '-';
    };

    const formatDate = (dateStr: string) => new Date(dateStr).toLocaleDateString();

    const statCards = [
        { label: 'Total Enquiries', value: stats.total, icon: Inbox, color: '#000000' },
        { label: 'New Enquiries', value: stats.new, icon: AlertCircle, color: '#333333' },
        { label: 'This Week', value: stats.thisWeek, icon: Clock, color: '#555555' },
    ];

    const drawerTitle = selectedEnquiry
        ? tab === 'inbox'
            ? 'Inbox'
            : `Activity > ${getTypeName(selectedEnquiry.type)}`
        : '';

    const drawerSubtitle = selectedEnquiry
        ? getItemTitle(selectedEnquiry)
        : '';

    return (
        <div className={styles.dashboard}>
            <div className={styles.header}>
                <h1 className={styles.title}>Dashboard</h1>
                <p className={styles.subtitle}>Welcome back! Here's what's happening.</p>
            </div>

            <div className={styles.statsGrid}>
                {statCards.map((stat) => (
                    <Link 
                        key={stat.label} 
                        to={stat.link || '#'} 
                        className={`${styles.statCard} ${stat.link ? styles.statCardClickable : ''}`}
                    >
                        <div className={styles.statIcon} style={{ backgroundColor: stat.color }}>
                            <stat.icon size={20} />
                        </div>
                        <div className={styles.statInfo}>
                            <span className={styles.statValue}>{stat.value}</span>
                            <span className={styles.statLabel}>{stat.label}</span>
                        </div>
                        {stat.link && <ArrowRight size={16} className={styles.statArrow} />}
                    </Link>
                ))}
            </div>

            <div className={styles.section}>
                <div className={styles.sectionHeader}>
                    <div className={styles.tabs}>
                        <button
                            className={`${styles.tab} ${tab === 'inbox' ? styles.tabActive : ''}`}
                            onClick={() => setTab('inbox')}
                        >
                            Inbox
                            <span className={styles.tabCount}>{inboxCount}</span>
                        </button>
                        <button
                            className={`${styles.tab} ${tab === 'activity' ? styles.tabActive : ''}`}
                            onClick={() => setTab('activity')}
                        >
                            Activity
                            <span className={styles.tabCount}>{activityCount}</span>
                        </button>
                    </div>
                </div>

                {loading ? (
                    <div className={styles.loading}>Loading...</div>
                ) : enquiries.length === 0 ? (
                    <div className={styles.empty}>
                        <p>{tab === 'inbox' ? 'No enquiries yet' : 'No activity yet'}</p>
                    </div>
                ) : (
                    <>
                        <div className={styles.table}>
                            <div className={styles.tableHeader}>
                                <span className={styles.colType}>Type</span>
                                <span className={styles.colItem}>Item</span>
                                <span className={styles.colName}>Name</span>
                                <span className={styles.colStatus}>Status</span>
                                <span className={styles.colDate}>Date</span>
                                <span className={styles.colAction}></span>
                            </div>
                            {enquiries.map((enquiry) => (
                                <div key={enquiry._id} className={styles.row}>
                                    <div className={styles.colType}>
                                        {getTypeIcon(enquiry.type)}
                                        <span className={styles.typeLabel}>{getTypeName(enquiry.type)}</span>
                                    </div>
                                    <div className={styles.colItem}>{getItemTitle(enquiry)}</div>
                                    <div className={styles.colName}>{enquiry.name}</div>
                                    <div className={styles.colStatus}>
                                        <StatusDropdown
                                            value={enquiry.status}
                                            options={ALL_STATUS_OPTIONS[tab]}
                                            onChange={(v) => handleStatusChange(enquiry, v)}
                                        />
                                    </div>
                                    <div className={styles.colDate}>{formatDate(enquiry.createdAt)}</div>
                                    <div className={styles.colAction}>
                                        <button
                                            className={styles.arrowBtn}
                                            onClick={() => openDrawer(enquiry)}
                                            aria-label="View details"
                                        >
                                            <ChevronRight size={16} />
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>

                        {totalPages > 1 && (
                            <div className={styles.pagination}>
                                <button
                                    className={styles.pageBtn}
                                    onClick={() => setPage(p => p - 1)}
                                    disabled={page === 1}
                                    aria-label="Previous page"
                                >
                                    <ChevronLeft size={16} />
                                </button>
                                <span className={styles.pageInfo}>
                                    Page {page} of {totalPages}
                                </span>
                                <button
                                    className={styles.pageBtn}
                                    onClick={() => setPage(p => p + 1)}
                                    disabled={page === totalPages}
                                    aria-label="Next page"
                                >
                                    <ChevronRight size={16} />
                                </button>
                            </div>
                        )}
                    </>
                )}
            </div>

            <Drawer
                isOpen={drawerOpen}
                onClose={closeDrawer}
                title={drawerTitle}
                subtitle={drawerSubtitle}
                footer={
                    selectedEnquiry && (
                        <div className={styles.drawerFooter}>
                            <div className={styles.drawerStatusWrapper}>
                                <StatusDropdown
                                    value={selectedEnquiry.status}
                                    options={ALL_STATUS_OPTIONS[tab]}
                                    onChange={(v) => {
                                        handleStatusChange(selectedEnquiry, v);
                                        setSelectedEnquiry({ ...selectedEnquiry, status: v });
                                    }}
                                    size="md"
                                />
                            </div>
                            {tab === 'inbox' && (
                                <Button
                                    className={styles.pickBtn}
                                    onClick={() => handlePick(selectedEnquiry)}
                                    disabled={selectedEnquiry.picked}
                                >
                                    <Check size={16} />
                                    {selectedEnquiry.picked ? 'Picked' : 'Pick'}
                                </Button>
                            )}
                            {tab === 'activity' && (
                                <Button onClick={() => handleArchive(selectedEnquiry)}>
                                    <CheckCircle size={16} />
                                    Complete
                                </Button>
                            )}
                            <Button
                                className={styles.trashBtn}
                                variant="outline"
                                onClick={() => setConfirmDelete(selectedEnquiry)}
                            >
                                <Trash2 size={16} />
                                Trash
                            </Button>
                        </div>
                    )
                }
            >
                {selectedEnquiry && (
                    <div className={styles.detailContent}>
                        <div className={styles.detailMeta}>
                            <span className={styles.detailCategory}>{getTypeName(selectedEnquiry.type)}</span>
                            <span className={styles.detailItemTitle}>{getItemTitle(selectedEnquiry)}</span>
                        </div>
                        <div className={styles.detailItem}>
                            <span className={styles.detailLabel}>Name</span>
                            <p className={styles.detailValue}>{selectedEnquiry.name}</p>
                        </div>
                        {selectedEnquiry.type === 'internship' ? (
                            <>
                                <div className={styles.detailItem}>
                                    <span className={styles.detailLabel}>Gender</span>
                                    <p className={styles.detailValue}>{selectedEnquiry.gender}</p>
                                </div>
                                <div className={styles.detailItem}>
                                    <span className={styles.detailLabel}>Email</span>
                                    <p className={styles.detailValue}>{selectedEnquiry.email}</p>
                                </div>
                                <div className={styles.detailItem}>
                                    <span className={styles.detailLabel}>Phone</span>
                                    <p className={styles.detailValue}>{selectedEnquiry.phone}</p>
                                </div>
                                <div className={styles.detailItem}>
                                    <span className={styles.detailLabel}>Address</span>
                                    <p className={styles.detailValue}>{selectedEnquiry.address}</p>
                                </div>
                                <div className={styles.detailItem}>
                                    <span className={styles.detailLabel}>Degree</span>
                                    <p className={styles.detailValue}>{selectedEnquiry.degree}</p>
                                </div>
                                <div className={styles.detailItem}>
                                    <span className={styles.detailLabel}>Year of Study</span>
                                    <p className={styles.detailValue}>{selectedEnquiry.yearOfStudy}</p>
                                </div>
                                <div className={styles.detailItem}>
                                    <span className={styles.detailLabel}>College</span>
                                    <p className={styles.detailValue}>{selectedEnquiry.college}</p>
                                </div>
                                <div className={styles.detailItem}>
                                    <span className={styles.detailLabel}>College Location</span>
                                    <p className={styles.detailValue}>{selectedEnquiry.collegeLocation}</p>
                                </div>
                                <div className={styles.detailItem}>
                                    <span className={styles.detailLabel}>Domain</span>
                                    <p className={styles.detailValue}>{selectedEnquiry.domain}</p>
                                </div>
                                <div className={styles.detailItem}>
                                    <span className={styles.detailLabel}>Duration</span>
                                    <p className={styles.detailValue}>{selectedEnquiry.duration}</p>
                                </div>
                                <div className={styles.detailItem}>
                                    <span className={styles.detailLabel}>Mode of Training</span>
                                    <p className={styles.detailValue}>{selectedEnquiry.mode}</p>
                                </div>
                                {selectedEnquiry.message && (
                                    <div className={styles.detailSection}>
                                        <h3 className={styles.detailSectionTitle}>Message</h3>
                                        <p className={styles.detailMessage}>{selectedEnquiry.message}</p>
                                    </div>
                                )}
                            </>
                        ) : (
                            <>
                                <div className={styles.detailItem}>
                                    <span className={styles.detailLabel}>Email</span>
                                    <p className={styles.detailValue}>{selectedEnquiry.email}</p>
                                </div>
                                <div className={styles.detailItem}>
                                    <span className={styles.detailLabel}>Phone</span>
                                    <p className={styles.detailValue}>{selectedEnquiry.phone}</p>
                                </div>
                                {selectedEnquiry.address && (
                                    <div className={styles.detailItem}>
                                        <span className={styles.detailLabel}>Address</span>
                                        <p className={styles.detailValue}>{selectedEnquiry.address}</p>
                                    </div>
                                )}
                                {selectedEnquiry.degree && (
                                    <div className={styles.detailItem}>
                                        <span className={styles.detailLabel}>Degree</span>
                                        <p className={styles.detailValue}>{selectedEnquiry.degree}</p>
                                    </div>
                                )}
                                {selectedEnquiry.college && (
                                    <div className={styles.detailItem}>
                                        <span className={styles.detailLabel}>College/University</span>
                                        <p className={styles.detailValue}>{selectedEnquiry.college}</p>
                                    </div>
                                )}
                                {selectedEnquiry.message && (
                                    <div className={styles.detailSection}>
                                        <h3 className={styles.detailSectionTitle}>Message</h3>
                                        <p className={styles.detailMessage}>{selectedEnquiry.message}</p>
                                    </div>
                                )}
                            </>
                        )}
                        <div className={styles.detailItem}>
                            <span className={styles.detailLabel}>Date Submitted</span>
                            <p className={styles.detailValue}>{new Date(selectedEnquiry.createdAt).toLocaleString()}</p>
                        </div>
                    </div>
                )}
            </Drawer>

            <ConfirmModal
                isOpen={!!confirmDelete}
                onClose={() => setConfirmDelete(null)}
                onConfirm={() => {
                    handleTrash(confirmDelete!);
                    setConfirmDelete(null);
                }}
                title="Move to trash?"
                message="This item will be moved to the trash. You can restore it later."
                confirmText="Trash"
                cancelText="Cancel"
            />
        </div>
    );
};
