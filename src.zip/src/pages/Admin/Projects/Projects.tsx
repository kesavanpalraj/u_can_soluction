import { useState, useEffect, useCallback, useMemo } from 'react';
import { X, Search, Trash2, Plus, ChevronLeft, ChevronRight, ArrowRight, ChevronDown, Filter, ArrowUpDown, Tag, ExternalLink, Edit, Check } from 'lucide-react';
import { Button } from '../../../components/Button';
import { Drawer } from '../../../components/Drawer';
import { useToast } from '../../../components/Toast';
import { ConfirmModal } from '../../../components/Modal';
import { ProjectForm } from './ProjectForm';
import styles from './Projects.module.css';

interface Project {
    _id: string;
    projectId: string;
    title: string;
    description: string;
    category: { _id: string; name: string; slug: string } | string;
    tags: string[];
    downloadAbstract: string;
    youtubeUrl: string;
    status: 'draft' | 'published' | 'archived';
    createdAt: string;
    updatedAt: string;
}

const ITEMS_PER_PAGE = 100;

export const Projects: React.FC = () => {
    const [projects, setProjects] = useState<Project[]>([]);
    const [categories, setCategories] = useState<{ _id: string; name: string; slug: string; type: string; order: number; createdAt: string }[]>([]);
    const [loading, setLoading] = useState(true);
    const [page, setPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const [total, setTotal] = useState(0);
    const [searchQuery, setSearchQuery] = useState('');
    const [debouncedSearch, setDebouncedSearch] = useState('');
    const [filterCategory, setFilterCategory] = useState('');
    const [sortBy, setSortBy] = useState('createdAt_desc');
    const [openDropdown, setOpenDropdown] = useState<string | null>(null);
    const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
    const [selectedProject, setSelectedProject] = useState<Project | null>(null);
    const [isDetailOpen, setIsDetailOpen] = useState(false);
    const [isFormOpen, setIsFormOpen] = useState(false);
    const [editingProject, setEditingProject] = useState<Project | null>(null);
    const [isCategoriesOpen, setIsCategoriesOpen] = useState(false);
    const [categoriesLoading, setCategoriesLoading] = useState(false);
    const [categoryToDelete, setCategoryToDelete] = useState<string | null>(null);
    const [projectToDelete, setProjectToDelete] = useState<string | null>(null);
    const [batchDeleteCount, setBatchDeleteCount] = useState(0);
    const [projectPdfUrl, setProjectPdfUrl] = useState('');
    const [editingPdfUrl, setEditingPdfUrl] = useState(false);
    const [pdfEditValue, setPdfEditValue] = useState('');
    const [showCategoryForm, setShowCategoryForm] = useState(false);
    const [editingCategory, setEditingCategory] = useState<{ _id: string; name: string; slug: string; order: number } | null>(null);
    const [categoryFormName, setCategoryFormName] = useState('');
    const [categoryFormOrder, setCategoryFormOrder] = useState(0);
    const { addToast } = useToast();

    useEffect(() => {
        fetchCategories();
        fetchPdfUrl();
    }, []);

    useEffect(() => {
        fetchProjects();
    }, [page, debouncedSearch, filterCategory]);

    useEffect(() => {
        const timer = setTimeout(() => {
            setDebouncedSearch(searchQuery);
        }, 300);
        return () => clearTimeout(timer);
    }, [searchQuery]);

    useEffect(() => {
        setPage(1);
    }, [debouncedSearch, filterCategory]);

    useEffect(() => {
        const handleClickOutside = (e: MouseEvent) => {
            if (openDropdown && !(e.target as Element).closest(`.${styles.filterDropdown}`)) {
                setOpenDropdown(null);
            }
        };
        document.addEventListener('click', handleClickOutside);
        return () => document.removeEventListener('click', handleClickOutside);
    }, [openDropdown]);

    const fetchCategories = async () => {
        setCategoriesLoading(true);
        try {
            const res = await fetch('/api/categories?type=project');
            if (res.ok) {
                const data = await res.json();
                setCategories(data);
            }
        } catch (error) {
            console.error('Failed to fetch categories:', error);
        } finally {
            setCategoriesLoading(false);
        }
    };

    const fetchProjects = async () => {
        setLoading(true);
        try {
            let queryParams = `page=${page}&limit=${ITEMS_PER_PAGE}`;
            if (debouncedSearch) queryParams += `&search=${encodeURIComponent(debouncedSearch)}`;
            if (filterCategory) queryParams += `&category=${encodeURIComponent(filterCategory)}`;
            const res = await fetch(`/api/projects?${queryParams}`);
            if (res.ok) {
                const data = await res.json();
                setProjects(data.projects || []);
                setTotalPages(data.totalPages || 1);
                setTotal(data.total || 0);
            }
        } catch (error) {
            console.error('Failed to fetch projects:', error);
        } finally {
            setLoading(false);
        }
    };

    const fetchPdfUrl = async () => {
        try {
            const res = await fetch('/api/project-pdf');
            if (res.ok) {
                const data = await res.json();
                setProjectPdfUrl(data.url || '');
            }
        } catch (error) {
            console.error('Failed to fetch project PDF URL:', error);
        }
    };

    const handleStartEditPdf = () => {
        setPdfEditValue(projectPdfUrl);
        setEditingPdfUrl(true);
    };

    const handleSavePdfUrl = async () => {
        try {
            const res = await fetch('/api/project-pdf', {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ url: pdfEditValue }),
            });
            if (res.ok) {
                const data = await res.json();
                setProjectPdfUrl(data.url || '');
                setEditingPdfUrl(false);
                addToast('Project list PDF link updated', 'success');
            } else {
                addToast('Failed to update PDF link', 'error');
            }
        } catch (error) {
            addToast('Failed to update PDF link', 'error');
        }
    };

    const handleCancelEditPdf = () => {
        setEditingPdfUrl(false);
        setPdfEditValue('');
    };

    const generateSlug = (name: string) => {
        return name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
    };

    const handleOpenAddCategory = () => {
        setEditingCategory(null);
        setCategoryFormName('');
        setCategoryFormOrder(0);
        setShowCategoryForm(true);
    };

    const handleOpenEditCategory = (cat: { _id: string; name: string; slug: string; order: number }) => {
        setEditingCategory(cat);
        setCategoryFormName(cat.name);
        setCategoryFormOrder(cat.order);
        setShowCategoryForm(true);
    };

    const handleCancelCategoryForm = () => {
        setShowCategoryForm(false);
        setEditingCategory(null);
        setCategoryFormName('');
        setCategoryFormOrder(0);
    };

    const handleSaveCategory = async () => {
        if (!categoryFormName.trim()) {
            addToast('Category name is required', 'error');
            return;
        }
        const slug = generateSlug(categoryFormName.trim());
        if (!slug) {
            addToast('Invalid category name', 'error');
            return;
        }
        try {
            const body = { name: categoryFormName.trim(), slug, type: 'project', order: categoryFormOrder };
            let res;
            if (editingCategory) {
                res = await fetch(`/api/categories/${editingCategory._id}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(body),
                });
            } else {
                res = await fetch('/api/categories', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(body),
                });
            }
            if (res.ok) {
                addToast(editingCategory ? 'Category updated' : 'Category added', 'success');
                handleCancelCategoryForm();
                fetchCategories();
                fetchProjects();
            } else {
                const err = await res.json();
                addToast(err.message || 'Failed to save category', 'error');
            }
        } catch (error) {
            addToast('Failed to save category', 'error');
        }
    };

    const handleOpenCategories = () => {
        setIsCategoriesOpen(true);
        fetchCategories();
    };

    const handleCategoryDelete = async (id: string) => {
        try {
            const res = await fetch(`/api/categories/${id}`, { method: 'DELETE' });
            if (res.ok) {
                addToast('Category moved to trash', 'success');
                setCategoryToDelete(null);
                fetchCategories();
                fetchProjects();
            } else {
                addToast('Failed to delete category', 'error');
            }
        } catch (error) {
            console.error('Failed to delete category:', error);
            addToast('Failed to delete category', 'error');
        }
    };

    const handleAdd = () => {
        setEditingProject(null);
        setIsFormOpen(true);
    };

    const handleShowDetails = (project: Project) => {
        setSelectedProject(project);
        setIsDetailOpen(true);
    };

    const handleEditFromDetail = () => {
        if (!selectedProject) return;
        setIsDetailOpen(false);
        setEditingProject(selectedProject);
        setTimeout(() => setIsFormOpen(true), 300);
    };

    const handleDeleteFromDetail = () => {
        if (!selectedProject) return;
        setProjectToDelete(selectedProject._id);
    };

    const handleConfirmDelete = async () => {
        if (!projectToDelete) return;
        try {
            const res = await fetch(`/api/projects/${projectToDelete}`, { method: 'DELETE' });
            if (res.ok) {
                addToast('Project moved to trash', 'success');
                setIsDetailOpen(false);
                setSelectedProject(null);
                fetchProjects();
            } else {
                addToast('Failed to delete project', 'error');
            }
        } catch (error) {
            console.error('Failed to delete project:', error);
            addToast('Failed to delete project', 'error');
        } finally {
            setProjectToDelete(null);
        }
    };

    const handleBatchDeleteConfirm = async () => {
        if (batchDeleteCount === 0) return;
        let success = 0;
        for (const id of selectedIds) {
            try {
                const res = await fetch(`/api/projects/${id}`, { method: 'DELETE' });
                if (res.ok) success++;
            } catch { }
        }

        addToast(`${success} project(s) moved to trash`, success > 0 ? 'success' : 'error');
        setSelectedIds(new Set());
        setBatchDeleteCount(0);
        fetchProjects();
    };

    const handleBatchDelete = () => {
        if (selectedIds.size === 0) return;
        setBatchDeleteCount(selectedIds.size);
    };

    const handleSave = async (projectData: Partial<Project>) => {
        try {
            if (editingProject?._id) {
                const res = await fetch(`/api/projects/${editingProject._id}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(projectData)
                });
                if (res.ok) {
                    addToast('Project updated', 'success');
                    fetchProjects();
                } else {
                    const error = await res.json();
                    addToast(error.message || 'Failed to update project', 'error');
                }
            } else {
                const res = await fetch('/api/projects', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(projectData)
                });
                if (res.ok) {
                    addToast('Project added', 'success');
                    fetchProjects();
                } else {
                    const error = await res.json();
                    addToast(error.message || 'Failed to add project', 'error');
                }
            }
        } catch (error) {
            console.error('Failed to save project:', error);
            addToast('Failed to save project', 'error');
        }
    };

    const toggleSelect = (id: string) => {
        setSelectedIds(prev => {
            const next = new Set(prev);
            if (next.has(id)) next.delete(id);
            else next.add(id);
            return next;
        });
    };

    const toggleSelectAll = () => {
        if (selectedIds.size === projects.length) {
            setSelectedIds(new Set());
        } else {
            setSelectedIds(new Set(projects.map(p => p._id)));
        }
    };

    const getCategoryName = (category: { name: string } | string) => {
        if (typeof category === 'object') return category.name;
        return category;
    };

    const formatProjectId = (id: string): string => {
        const num = id.replace(/\D/g, '');
        return `P${num.padStart(4, '0')}`;
    };

    const getYouTubeEmbedUrl = (url: string): string | null => {
        const match = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([a-zA-Z0-9_-]{11})/);
        return match ? `https://www.youtube.com/embed/${match[1]}` : null;
    };

    const categoryOptions = [
        { value: '', label: 'All categories' },
        ...categories
            .filter(cat => cat.name.toLowerCase() !== 'all')
            .map(cat => ({ value: cat._id, label: cat.name }))
    ];

    const sortOptions = [
        { key: 'createdAt_desc', label: 'Newest' },
        { key: 'createdAt_asc', label: 'Oldest' },
        { key: 'projectId_asc', label: 'ID A-Z' },
        { key: 'projectId_desc', label: 'ID Z-A' },
        { key: 'title_asc', label: 'Name A-Z' },
        { key: 'title_desc', label: 'Name Z-A' }
    ];

    const getSelectedCategoryLabel = () => {
        if (!filterCategory) return 'All categories';
        const cat = categories.find(c => c._id === filterCategory);
        return cat ? cat.name : 'All categories';
    };

    const sortedProjects = useMemo(() => {
        const sorted = [...projects];
        const [field, direction] = sortBy.split('_');
        sorted.sort((a, b) => {
            let aVal: any = a[field as keyof Project];
            let bVal: any = b[field as keyof Project];
            if (typeof aVal === 'object' && aVal !== null) aVal = (aVal as { name?: string }).name || '';
            if (typeof bVal === 'object' && bVal !== null) bVal = (bVal as { name?: string }).name || '';
            if (aVal === bVal) return 0;
            if (!aVal) return 1;
            if (!bVal) return -1;
            const cmp = String(aVal).localeCompare(String(bVal));
            return direction === 'asc' ? cmp : -cmp;
        });
        return sorted;
    }, [projects, sortBy]);

    const startItem = total === 0 ? 0 : (page - 1) * ITEMS_PER_PAGE + 1;
    const endItem = Math.min(page * ITEMS_PER_PAGE, total);

    return (
        <div className={styles.page}>
            <div className={styles.header}>
                <div className={styles.headerLeft}>
                    <h1 className={styles.title}>Projects</h1>
                    <p className={styles.subtitle}>{total} total projects</p>
                </div>
                <div className={styles.headerAction}>
                    <Button variant="outline" onClick={handleOpenCategories}>
                        <Tag size={16} />
                        Categories
                    </Button>
                    <Button onClick={handleAdd}>
                        <Plus size={16} />
                        Add Project
                    </Button>
                </div>
            </div>

            <div className={styles.downloadRow}>
                {editingPdfUrl ? (
                    <div className={styles.pdfEditRow}>
                        <input
                            type="text"
                            value={pdfEditValue}
                            onChange={(e) => setPdfEditValue(e.target.value)}
                            placeholder="Paste Google Drive PDF URL..."
                            className={styles.pdfEditInput}
                            onKeyDown={(e) => { if (e.key === 'Enter') handleSavePdfUrl(); if (e.key === 'Escape') handleCancelEditPdf(); }}
                            autoFocus
                        />
                        <button className={styles.pdfEditBtn} onClick={handleSavePdfUrl} aria-label="Save">
                            <Check size={16} />
                        </button>
                        <button className={styles.pdfEditBtn} onClick={handleCancelEditPdf} aria-label="Cancel">
                            <X size={16} />
                        </button>
                    </div>
                ) : projectPdfUrl ? (
                    <>
                        <a href={projectPdfUrl} target="_blank" rel="noopener noreferrer" className={styles.downloadLink}>
                            <ExternalLink size={14} />
                            Download Complete Project List (PDF)
                        </a>
                        <button className={styles.pdfEditIcon} onClick={handleStartEditPdf} aria-label="Edit PDF link">
                            <Edit size={14} />
                        </button>
                    </>
                ) : (
                    <Button variant="outline" size="sm" onClick={handleStartEditPdf}>
                        <Plus size={16} />
                        Add Project List PDF
                    </Button>
                )}
            </div>

            <div className={styles.toolbar}>
                <div className={styles.searchContainer}>
                    <Search size={18} className={styles.searchIcon} />
                    <input
                        type="text"
                        placeholder="Search by title, ID, or tags..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className={styles.searchInput}
                    />
                    {searchQuery && (
                        <button
                            className={styles.searchClear}
                            onClick={() => setSearchQuery('')}
                            aria-label="Clear search"
                        >
                            <X size={16} />
                        </button>
                    )}
                </div>
                <div className={styles.filtersRow}>
                    <div className={styles.filterDropdown}>
                        <button
                            className={`${styles.filterBtn} ${filterCategory ? styles.filterBtnActive : ''}`}
                            onClick={(e) => { e.stopPropagation(); setOpenDropdown(openDropdown === 'category' ? null : 'category'); }}
                        >
                            <Filter size={14} className={styles.filterIcon} />
                            <span>{getSelectedCategoryLabel()}</span>
                            <ChevronDown size={14} />
                        </button>
                        {openDropdown === 'category' && (
                            <div className={styles.filterMenu}>
                                {categoryOptions.map(opt => (
                                    <button
                                        key={opt.value}
                                        className={`${styles.filterMenuItem} ${filterCategory === opt.value ? styles.filterMenuItemActive : ''}`}
                                        onClick={() => { setFilterCategory(opt.value); setOpenDropdown(null); }}
                                    >
                                        {opt.label}
                                    </button>
                                ))}
                            </div>
                        )}
                    </div>
                    <div className={styles.filterDropdown}>
                        <button
                            className={styles.filterBtn}
                            onClick={(e) => { e.stopPropagation(); setOpenDropdown(openDropdown === 'sort' ? null : 'sort'); }}
                        >
                            <ArrowUpDown size={14} className={styles.filterIcon} />
                            <span>{sortOptions.find(o => o.key === sortBy)?.label || 'Sort'}</span>
                            <ChevronDown size={14} />
                        </button>
                        {openDropdown === 'sort' && (
                            <div className={styles.filterMenu}>
                                {sortOptions.map(opt => (
                                    <button
                                        key={opt.key}
                                        className={`${styles.filterMenuItem} ${sortBy === opt.key ? styles.filterMenuItemActive : ''}`}
                                        onClick={() => { setSortBy(opt.key); setOpenDropdown(null); }}
                                    >
                                        {opt.label}
                                    </button>
                                ))}
                            </div>
                        )}
                    </div>
                </div>
            </div>

            {loading ? (
                <div className={styles.loading}>Loading...</div>
            ) : projects.length === 0 ? (
                <div className={styles.empty}>
                    {debouncedSearch ? `No projects found for "${debouncedSearch}".` : 'No projects yet.'}
                </div>
            ) : (
                <>
                    <div className={styles.resultsHeader}>
                        <label className={styles.selectAll}>
                            <input
                                type="checkbox"
                                checked={selectedIds.size === projects.length && projects.length > 0}
                                onChange={toggleSelectAll}
                                className={styles.checkbox}
                            />
                            <span className={styles.selectAllText}>
                                {selectedIds.size > 0 ? `${selectedIds.size} selected` : 'Select all'}
                            </span>
                        </label>
                        <span className={styles.resultsCount}>
                            Showing {startItem}-{endItem} of {total}
                        </span>
                    </div>

                    <div className={styles.list}>
                        {sortedProjects.map((project) => (
                            <div key={project._id} className={styles.row}>
                                <div className={styles.rowCheckbox}>
                                    <input
                                        type="checkbox"
                                        checked={selectedIds.has(project._id)}
                                        onChange={() => toggleSelect(project._id)}
                                        className={styles.checkbox}
                                    />
                                </div>
                                <div
                                    className={styles.rowContent}
                                    onClick={() => handleShowDetails(project)}
                                    role="button"
                                    tabIndex={0}
                                    onKeyDown={(e) => { if (e.key === 'Enter') handleShowDetails(project); }}
                                >
                                    <span className={styles.rowId}>{formatProjectId(project.projectId ?? '')}</span>
                                    <span className={styles.rowTitle}>{project.title}</span>
                                </div>
                                <span className={styles.rowCategory}>{getCategoryName(project.category)}</span>
                                <button
                                    className={styles.rowArrow}
                                    onClick={() => handleShowDetails(project)}
                                    aria-label="Show details"
                                >
                                    <ChevronRight size={16} />
                                </button>
                            </div>
                        ))}
                    </div>

                    {totalPages > 1 && (
                        <div className={styles.pagination}>
                            <button
                                className={styles.paginationArrow}
                                onClick={() => { setPage(p => p - 1); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                                disabled={page === 1}
                                aria-label="Previous page"
                            >
                                <ChevronLeft size={18} />
                            </button>
                            <span className={styles.paginationInfo}>Page {page} of {totalPages}</span>
                            <button
                                className={styles.paginationArrow}
                                onClick={() => { setPage(p => p + 1); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                                disabled={page === totalPages}
                                aria-label="Next page"
                            >
                                <ChevronRight size={18} />
                            </button>
                        </div>
                    )}
                </>
            )}

            {selectedIds.size > 0 && (
                <div className={styles.deleteBar}>
                    <span className={styles.deleteBarCount}>{selectedIds.size} selected</span>
                    <button className={styles.deleteBarBtn} onClick={handleBatchDelete} aria-label="Delete selected">
                        <Trash2 size={18} />
                    </button>
                </div>
            )}

            <Drawer
                isOpen={isDetailOpen}
                onClose={() => setIsDetailOpen(false)}
                title="Project Details"
                footer={selectedProject && (<>
                    <Button variant="outline" onClick={handleDeleteFromDetail}>
                        <Trash2 size={14} /> Delete
                    </Button>
                    <Button onClick={handleEditFromDetail}>
                        Edit <ArrowRight size={14} />
                    </Button>
                </>)}
            >
                {selectedProject && (
                    <div className={styles.detailContent}>
                        <div className={styles.detailMeta}>
                            <span className={styles.detailCategory}>{getCategoryName(selectedProject.category)}</span>
                            <span className={styles.detailId}>{selectedProject.projectId}</span>
                        </div>
                        <h2 className={styles.detailTitle}>{selectedProject.title}</h2>
                        <p className={styles.detailDescription}>{selectedProject.description}</p>
                        {selectedProject.tags?.length > 0 && (
                            <div className={styles.detailTags}>
                                {selectedProject.tags.map(tag => (
                                    <span key={tag} className={styles.detailTag}>{tag}</span>
                                ))}
                            </div>
                        )}
                        {selectedProject.downloadAbstract && (
                            <a
                                href={selectedProject.downloadAbstract}
                                target="_blank"
                                rel="noopener noreferrer"
                                className={styles.abstractLink}
                            >
                                Download full abstract <ExternalLink size={14} />
                            </a>
                        )}
                        {selectedProject.youtubeUrl && (() => {
                            const embedUrl = getYouTubeEmbedUrl(selectedProject.youtubeUrl);
                            return embedUrl ? (
                                <div className={styles.youtubeContainer}>
                                    <iframe
                                        src={embedUrl}
                                        title="YouTube video"
                                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                        allowFullScreen
                                    />
                                </div>
                            ) : null;
                        })()}
                    </div>
                )}
            </Drawer>

            <ProjectForm
                isOpen={isFormOpen}
                onClose={() => {
                    setIsFormOpen(false);
                    setEditingProject(null);
                }}
                onSave={handleSave}
                project={editingProject}
                categories={categories}
            />

            <Drawer
                isOpen={isCategoriesOpen}
                onClose={() => setIsCategoriesOpen(false)}
                title="Manage Categories"
                maxWidth="600px"
            >
                {!showCategoryForm && (
                    <div className={styles.categoryFormBar}>
                        <Button variant="outline" size="sm" onClick={handleOpenAddCategory}>
                            <Plus size={14} />
                            Add Category
                        </Button>
                    </div>
                )}
                {showCategoryForm && (
                    <div className={styles.categoryForm}>
                        <input
                            type="text"
                            placeholder="Category name"
                            value={categoryFormName}
                            onChange={(e) => setCategoryFormName(e.target.value)}
                            className={styles.categoryFormInput}
                            onKeyDown={(e) => { if (e.key === 'Enter') handleSaveCategory(); if (e.key === 'Escape') handleCancelCategoryForm(); }}
                            autoFocus
                        />
                        <input
                            type="number"
                            placeholder="Order"
                            value={categoryFormOrder}
                            onChange={(e) => setCategoryFormOrder(Number(e.target.value))}
                            className={styles.categoryFormOrder}
                        />
                        <Button size="sm" onClick={handleSaveCategory}>
                            {editingCategory ? 'Update' : 'Add'}
                        </Button>
                        <Button variant="outline" size="sm" onClick={handleCancelCategoryForm}>
                            Cancel
                        </Button>
                    </div>
                )}
                {categoriesLoading ? (
                    <div className={styles.categoriesLoading}>Loading...</div>
                ) : categories.length === 0 && !showCategoryForm ? (
                    <div className={styles.categoriesEmpty}>No categories yet</div>
                ) : categories.length > 0 && (
                    <div className={styles.categoriesTable}>
                        <div className={styles.categoriesHeader}>
                            <span className={styles.catColName}>Name</span>
                            <span className={styles.catColSlug}>Slug</span>
                            <span className={styles.catColOrder}>Order</span>
                            <span className={styles.catColAction}></span>
                        </div>
                        {categories.map((cat) => (
                            <div key={cat._id} className={`${styles.categoriesRow}${cat.slug === 'all' ? ` ${styles.categoriesRowAll}` : ''}`}>
                                <span className={styles.catColName}>{cat.name}</span>
                                <span className={styles.catColSlug}>{cat.slug}</span>
                                <span className={styles.catColOrder}>{cat.slug === 'all' ? 0 : cat.order}</span>
                                <span className={styles.catColAction}>
                                    {cat.slug !== 'all' && (
                                        <button
                                            className={styles.catEditBtn}
                                            onClick={() => handleOpenEditCategory(cat)}
                                            aria-label="Edit category"
                                        >
                                            <Edit size={14} />
                                        </button>
                                    )}
                                    {cat.slug !== 'all' && (
                                        <button
                                            className={styles.catDeleteBtn}
                                            onClick={() => setCategoryToDelete(cat._id)}
                                            aria-label="Delete category"
                                        >
                                            <Trash2 size={14} />
                                        </button>
                                    )}
                                </span>
                            </div>
                        ))}
                    </div>
                )}
            </Drawer>

            <ConfirmModal
                isOpen={!!projectToDelete}
                onClose={() => setProjectToDelete(null)}
                onConfirm={handleConfirmDelete}
                title="Move project to trash?"
                message="This project will be moved to trash."
                confirmText="Move to trash"
                cancelText="Cancel"
            />

            <ConfirmModal
                isOpen={batchDeleteCount > 0}
                onClose={() => setBatchDeleteCount(0)}
                onConfirm={handleBatchDeleteConfirm}
                title={`Move ${batchDeleteCount} project(s) to trash?`}
                message="Selected projects will be moved to trash."
                confirmText="Move to trash"
                cancelText="Cancel"
            />

            <ConfirmModal
                isOpen={!!categoryToDelete}
                onClose={() => setCategoryToDelete(null)}
                onConfirm={() => {
                    if (categoryToDelete) handleCategoryDelete(categoryToDelete);
                }}
                title="Delete category?"
                message="This category will be moved to trash."
                confirmText="Delete"
                cancelText="Cancel"
            />
        </div>
    );
};