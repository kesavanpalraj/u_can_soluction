import React, { useState, useEffect } from 'react';
import { Drawer } from '../../../components/Drawer/Drawer';
import { Input } from '../../../components/Input/Input';
import { Button } from '../../../components/Button/Button';
import { Select } from '../../../components/Select';
import { useToast } from '../../../components/Toast';
import styles from './ProjectForm.module.css';

interface ProjectFormProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (project: any) => void;
    project?: any;
    categories: any[];
}

export const ProjectForm: React.FC<ProjectFormProps> = ({
    isOpen,
    onClose,
    onSave,
    project,
    categories
}) => {
    const [formData, setFormData] = useState<any>({
        projectId: '',
        title: '',
        description: '',
        category: '',
        tags: [],
        downloadAbstract: '',
        youtubeUrl: '',
        status: 'draft'
    });
    const [tagInput, setTagInput] = useState('');
    const [saving, setSaving] = useState(false);
    const { addToast } = useToast();

    useEffect(() => {
        if (project) {
            setFormData({
                _id: project._id,
                projectId: project.projectId,
                title: project.title,
                description: project.description,
                category: typeof project.category === 'object' ? project.category._id : project.category,
                tags: project.tags || [],
                downloadAbstract: project.downloadAbstract || '',
                youtubeUrl: project.youtubeUrl || '',
                status: project.status,
                updatedAt: project.updatedAt
            });
        } else {
            setFormData({
                projectId: '',
                title: '',
                description: '',
                category: categories[0]?._id || '',
                tags: [],
                downloadAbstract: '',
                youtubeUrl: '',
                status: 'draft'
            });
        }
        setTagInput('');
    }, [project, isOpen, categories]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData((prev: any) => ({ ...prev, [name]: value }));
    };

    const addTag = () => {
        const val = tagInput.trim();
        if (val && !formData.tags?.includes(val) && (formData.tags?.length || 0) < 5) {
            setFormData((prev: any) => ({
                ...prev,
                tags: [...(prev.tags || []), val]
            }));
            setTagInput('');
        }
    };

    const removeTag = (tag: string) => {
        setFormData((prev: any) => ({
            ...prev,
            tags: prev.tags?.filter((t: string) => t !== tag) || []
        }));
    };

    const handleSubmit = async () => {
        const trimmed = {
            ...formData,
            projectId: formData.projectId?.trim() || '',
            title: formData.title?.trim() || '',
            description: formData.description?.trim() || '',
            downloadAbstract: formData.downloadAbstract?.trim() || '',
            youtubeUrl: formData.youtubeUrl?.trim() || '',
        };

        if (!trimmed.projectId || !trimmed.title || !trimmed.description || !trimmed.category) {
            addToast('Please fill in required fields', 'error');
            return;
        }

        if (!/^[a-zA-Z0-9]+$/.test(trimmed.projectId)) {
            addToast('Project ID must be alphanumeric with no special characters', 'error');
            return;
        }

        setSaving(true);
        try {
            await onSave(trimmed);
            onClose();
        } catch (error) {
            addToast('Failed to save project', 'error');
        } finally {
            setSaving(false);
        }
    };

    const formatDate = (dateString?: string) => {
        if (!dateString) return 'Never';
        return new Date(dateString).toLocaleString();
    };

    const isEditing = !!project?._id;

    return (
        <Drawer
            isOpen={isOpen}
            onClose={onClose}
            title={isEditing ? 'Edit Project' : 'Add Project'}
            subtitle={isEditing && formData.updatedAt ? `Last edited: ${formatDate(formData.updatedAt)}` : undefined}
            footer={
                <>
                    <Button variant="secondary" onClick={onClose}>
                        Cancel
                    </Button>
                    <Button onClick={handleSubmit} disabled={saving}>
                        {isEditing ? 'Save Changes' : 'Add Project'}
                    </Button>
                </>
            }
        >
            <div className={styles.form}>
                <div className={styles.field}>
                    <label className={styles.label}>Project ID *</label>
                    <Input
                        name="projectId"
                        value={formData.projectId || ''}
                        onChange={handleChange}
                        placeholder="e.g., P0001"
                        maxLength={5}
                        disabled={isEditing}
                    />
                </div>

                <div className={styles.field}>
                    <label className={styles.label}>Title *</label>
                    <Input
                        name="title"
                        value={formData.title || ''}
                        onChange={handleChange}
                        placeholder="Project title"
                    />
                </div>

                <div className={styles.field}>
                    <label className={styles.label}>Category *</label>
                    <Select
                        value={typeof formData.category === 'object' ? formData.category._id : formData.category}
                        options={categories.filter(cat => cat.name.toLowerCase() !== 'all').map((cat: any) => ({ value: cat._id, label: cat.name }))}
                        onChange={(val) => setFormData((prev: any) => ({ ...prev, category: val }))}
                        placeholder="Select category"
                    />
                </div>

                <div className={styles.field}>
                    <label className={styles.label}>Description *</label>
                    <textarea
                        name="description"
                        value={formData.description || ''}
                        onChange={handleChange}
                        placeholder="Brief description"
                        className={styles.textarea}
                        rows={2}
                    />
                </div>

                <div className={styles.field}>
                    <label className={styles.label}>Tags (max 5)</label>
                    <div className={styles.chipInput}>
                        <Input
                            value={tagInput}
                            onChange={(e: any) => setTagInput(e.target.value)}
                            placeholder="Add tag"
                            onKeyDown={(e: any) => e.key === 'Enter' && (e.preventDefault(), addTag())}
                        />
                        <Button variant="outline" onClick={addTag}>Add</Button>
                    </div>
                    <div className={styles.chips}>
                        {formData.tags?.map((tag: string) => (
                            <span key={tag} className={styles.chip}>
                                {tag}
                                <button onClick={() => removeTag(tag)}>&times;</button>
                            </span>
                        ))}
                    </div>
                </div>

                <div className={styles.field}>
                    <label className={styles.label}>Download Abstract</label>
                    <Input
                        name="downloadAbstract"
                        value={formData.downloadAbstract || ''}
                        onChange={handleChange}
                        placeholder="Google Drive PDF link"
                    />
                </div>

                <div className={styles.field}>
                    <label className={styles.label}>YouTube Video</label>
                    <Input
                        name="youtubeUrl"
                        value={formData.youtubeUrl || ''}
                        onChange={handleChange}
                        placeholder="YouTube video URL"
                    />
                </div>
            </div>
        </Drawer>
    );
};
