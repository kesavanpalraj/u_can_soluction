import { useState, useEffect } from 'react';
import { FolderOpen, BookOpen, Briefcase, ChevronLeft, ChevronRight, Trash2 } from 'lucide-react';
import { useToast } from '../../../components/Toast';
import { ConfirmModal } from '../../../components/Modal';
import { Drawer } from '../../../components/Drawer';
import styles from './Archive.module.css';

interface ArchivedEnquiry {
    _id: string;
    type: 'project' | 'course' | 'internship';
    name: string;
    email: string;
    phone: string;
    address?: string;
    degree?: string;
    college?: string;
    gender?: string;
    yearOfStudy?: string;
    collegeLocation?: string;
    domain?: string;
    duration?: string;
    mode?: string;
    message?: string;
    status: string;
    item: { title?: string; projectId?: string; courseId?: string; internshipId?: string } | null;
    updatedAt: string;
}

export const Archive: React.FC = () => {
    const [enquiries, setEnquiries] = useState<ArchivedEnquiry[]>([]);
    const [loading, setLoading] = useState(true);
    const [page, setPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const [total, setTotal] = useState(0);
    const [confirmDelete, setConfirmDelete] = useState<ArchivedEnquiry | null>(null);
    const [viewItem, setViewItem] = useState<ArchivedEnquiry | null>(null);
    const { addToast } = useToast();

    useEffect(() => {
        fetchArchived();
    }, [page]);

    const fetchArchived = async () => {
        setLoading(true);
        try {
            const res = await fetch(`/api/enquiries/archived?page=${page}&limit=20`);
            if (res.ok) {
                const data = await res.json();
                setEnquiries(data.enquiries || []);
                setTotal(data.total || 0);
                setTotalPages(data.totalPages || 1);
            }
        } catch (error) {
            console.error('Failed to fetch archived enquiries:', error);
        } finally {
            setLoading(false);
        }
    };

    const getTypeIcon = (type: string) => {
        switch (type) {
            case 'project': return <FolderOpen size={16} />;
            case 'course': return <BookOpen size={16} />;
            case 'internship': return <Briefcase size={16} />;
            default: return null;
        }
    };

    const getTypeName = (type: string) => type.charAt(0).toUpperCase() + type.slice(1);

    const getItemTitle = (enquiry: ArchivedEnquiry): string => {
        if (enquiry.type === 'internship') return enquiry.domain || enquiry.item?.title || '-';
        return enquiry.item?.title || '-';
    };

    const formatDate = (dateStr: string) => new Date(dateStr).toLocaleDateString();

    const handleTrash = async (enquiry: ArchivedEnquiry) => {
        try {
            const res = await fetch(`/api/enquiries/trash/${enquiry._id}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ type: enquiry.type })
            });
            if (res.ok) {
                addToast('Moved to Trash', 'success');
                setConfirmDelete(null);
                fetchArchived();
            }
        } catch (error) {
            console.error('Failed to trash enquiry:', error);
            addToast('Failed to trash enquiry', 'error');
        }
    };

    return (
        <div className={styles.page}>
            <div className={styles.header}>
                <div>
                    <h1 className={styles.title}>Archive</h1>
                    <p className={styles.subtitle}>Completed enquiries ({total})</p>
                </div>
            </div>

            {loading ? (
                <div className={styles.loading}>Loading...</div>
            ) : enquiries.length === 0 ? (
                <div className={styles.empty}>No archived enquiries</div>
            ) : (
                <>
                    <div className={styles.table}>
                        <div className={styles.tableHeader}>
                            <span className={styles.colType}>Type</span>
                            <span className={styles.colItem}>Item</span>
                            <span className={styles.colName}>Name</span>
                            <span className={styles.colDate}>Archived</span>
                            <span className={styles.colView}></span>
                            <span className={styles.colAction}></span>
                        </div>
                        {enquiries.map((enquiry) => (
                            <div key={enquiry._id} className={styles.row}>
                                <div className={styles.colType}>
                                    {getTypeIcon(enquiry.type)}
                                    <span className={styles.typeLabel}>{getTypeName(enquiry.type)}</span>
                                </div>
                                <div className={styles.colItem}>{getItemTitle(enquiry)}</div>
                                <div className={styles.colName}>{enquiry.name}</div>
                                <div className={styles.colDate}>{formatDate(enquiry.updatedAt)}</div>
                                <div className={styles.colView}>
                                    <button
                                        className={styles.viewBtn}
                                        onClick={() => setViewItem(enquiry)}
                                        aria-label="View details"
                                    >
                                        <ChevronRight size={16} />
                                    </button>
                                </div>
                                <div className={styles.colAction}>
                                    <button
                                        className={styles.actionBtn}
                                        onClick={() => setConfirmDelete(enquiry)}
                                        aria-label="Trash"
                                    >
                                        <Trash2 size={16} />
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>

                    {totalPages > 1 && (
                        <div className={styles.pagination}>
                            <button
                                className={styles.pageBtn}
                                onClick={() => setPage(p => p - 1)}
                                disabled={page === 1}
                                aria-label="Previous page"
                            >
                                <ChevronLeft size={16} />
                            </button>
                            <span className={styles.pageInfo}>
                                Page {page} of {totalPages}
                            </span>
                            <button
                                className={styles.pageBtn}
                                onClick={() => setPage(p => p + 1)}
                                disabled={page === totalPages}
                                aria-label="Next page"
                            >
                                <ChevronRight size={16} />
                            </button>
                        </div>
                    )}
                </>
            )}

            <ConfirmModal
                isOpen={!!confirmDelete}
                onClose={() => setConfirmDelete(null)}
                onConfirm={() => {
                    if (confirmDelete) handleTrash(confirmDelete);
                }}
                title="Move to trash?"
                message="This item will be moved to the trash."
                confirmText="Trash"
                cancelText="Cancel"
            />

            <Drawer
                isOpen={!!viewItem}
                onClose={() => setViewItem(null)}
                title={viewItem?.name || 'Details'}
                maxWidth="500px"
            >
                {viewItem && (
                    <div className={styles.detailContent}>
                        <div className={styles.detailMeta}>
                            <span className={styles.detailCategory}>{getTypeName(viewItem.type)}</span>
                            <span className={styles.detailItemTitle}>{getItemTitle(viewItem)}</span>
                        </div>
                        <div className={styles.detailItem}>
                            <span className={styles.detailLabel}>Name</span>
                            <p className={styles.detailValue}>{viewItem.name}</p>
                        </div>
                        {viewItem.type === 'internship' ? (
                            <>
                                <div className={styles.detailItem}>
                                    <span className={styles.detailLabel}>Gender</span>
                                    <p className={styles.detailValue}>{viewItem.gender}</p>
                                </div>
                                <div className={styles.detailItem}>
                                    <span className={styles.detailLabel}>Email</span>
                                    <p className={styles.detailValue}>{viewItem.email}</p>
                                </div>
                                <div className={styles.detailItem}>
                                    <span className={styles.detailLabel}>Phone</span>
                                    <p className={styles.detailValue}>{viewItem.phone}</p>
                                </div>
                                <div className={styles.detailItem}>
                                    <span className={styles.detailLabel}>Address</span>
                                    <p className={styles.detailValue}>{viewItem.address}</p>
                                </div>
                                <div className={styles.detailItem}>
                                    <span className={styles.detailLabel}>Degree</span>
                                    <p className={styles.detailValue}>{viewItem.degree}</p>
                                </div>
                                <div className={styles.detailItem}>
                                    <span className={styles.detailLabel}>Year of Study</span>
                                    <p className={styles.detailValue}>{viewItem.yearOfStudy}</p>
                                </div>
                                <div className={styles.detailItem}>
                                    <span className={styles.detailLabel}>College</span>
                                    <p className={styles.detailValue}>{viewItem.college}</p>
                                </div>
                                <div className={styles.detailItem}>
                                    <span className={styles.detailLabel}>College Location</span>
                                    <p className={styles.detailValue}>{viewItem.collegeLocation}</p>
                                </div>
                                <div className={styles.detailItem}>
                                    <span className={styles.detailLabel}>Domain</span>
                                    <p className={styles.detailValue}>{viewItem.domain}</p>
                                </div>
                                <div className={styles.detailItem}>
                                    <span className={styles.detailLabel}>Duration</span>
                                    <p className={styles.detailValue}>{viewItem.duration}</p>
                                </div>
                                <div className={styles.detailItem}>
                                    <span className={styles.detailLabel}>Mode of Training</span>
                                    <p className={styles.detailValue}>{viewItem.mode}</p>
                                </div>
                                {viewItem.message && (
                                    <div className={styles.detailSection}>
                                        <h3 className={styles.detailSectionTitle}>Message</h3>
                                        <p className={styles.detailMessage}>{viewItem.message}</p>
                                    </div>
                                )}
                            </>
                        ) : (
                            <>
                                <div className={styles.detailItem}>
                                    <span className={styles.detailLabel}>Email</span>
                                    <p className={styles.detailValue}>{viewItem.email}</p>
                                </div>
                                <div className={styles.detailItem}>
                                    <span className={styles.detailLabel}>Phone</span>
                                    <p className={styles.detailValue}>{viewItem.phone}</p>
                                </div>
                                {viewItem.address && (
                                    <div className={styles.detailItem}>
                                        <span className={styles.detailLabel}>Address</span>
                                        <p className={styles.detailValue}>{viewItem.address}</p>
                                    </div>
                                )}
                                {viewItem.degree && (
                                    <div className={styles.detailItem}>
                                        <span className={styles.detailLabel}>Degree</span>
                                        <p className={styles.detailValue}>{viewItem.degree}</p>
                                    </div>
                                )}
                                {viewItem.college && (
                                    <div className={styles.detailItem}>
                                        <span className={styles.detailLabel}>College/University</span>
                                        <p className={styles.detailValue}>{viewItem.college}</p>
                                    </div>
                                )}
                                {viewItem.message && (
                                    <div className={styles.detailSection}>
                                        <h3 className={styles.detailSectionTitle}>Message</h3>
                                        <p className={styles.detailMessage}>{viewItem.message}</p>
                                    </div>
                                )}
                            </>
                        )}
                    </div>
                )}
            </Drawer>
        </div>
    );
};
