import { useState, FormEvent } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./Login.module.css";
import logo from "../../../assets/logo.jpg";

type Step = "login" | "forgot" | "otp" | "reset" | "done";

export const Login: React.FC = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState<Step>("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [otp, setOtp] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [resetToken, setResetToken] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const clearMsg = () => {
    setMessage("");
    setError("");
  };

  const handleLogin = async (e: FormEvent) => {
    e.preventDefault();
    clearMsg();
    setLoading(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message);
      localStorage.setItem("admin_token", data.token);
      navigate("/admin");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleForgot = async () => {
    clearMsg();
    if (!email) {
      setError("Enter your email first");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/auth/forgot-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message);
      setMessage(data.message);
      setStep("otp");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtp = async (e: FormEvent) => {
    e.preventDefault();
    clearMsg();
    setLoading(true);
    try {
      const res = await fetch("/api/auth/verify-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, otp }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message);
      setResetToken(data.resetToken);
      setMessage(data.message);
      setStep("reset");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleReset = async (e: FormEvent) => {
    e.preventDefault();
    clearMsg();
    if (newPassword.length < 6) {
      setError("Password must be at least 6 characters");
      return;
    }
    if (newPassword !== confirmPassword) {
      setError("Passwords do not match");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/auth/reset-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ resetToken, password: newPassword }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message);
      setMessage(data.message);
      setStep("done");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const backToLogin = () => {
    setStep("login");
    setOtp("");
    setNewPassword("");
    setConfirmPassword("");
    setResetToken("");
    setMessage("");
    setError("");
  };

  return (
    <div className={styles.loginPage}>
      <div className={styles.card}>
        <div className={styles.logo}>
          <img src={logo} alt="U Can Solution" className={styles.logoImg} />
          <span className={styles.logoText}>Admin</span>
        </div>

        {step === "login" && (
          <form className={styles.form} onSubmit={handleLogin}>
            <div className={styles.field}>
              <label className={styles.label}>Email</label>
              <input
                className={styles.input}
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                autoFocus
              />
            </div>
            <div className={styles.field}>
              <label className={styles.label}>Password</label>
              <input
                className={styles.input}
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            {error && <div className={`${styles.message} ${styles.error}`}>{error}</div>}
            <button className={styles.button} type="submit" disabled={loading}>
              {loading ? "Signing in..." : "Sign in"}
            </button>
            <button
              type="button"
              className={styles.forgotLink}
              onClick={() => { clearMsg(); setStep("forgot"); }}
            >
              Forgot password?
            </button>
          </form>
        )}

        {step === "forgot" && (
          <div className={styles.form}>
            <div className={styles.stepIndicator}>Step 1 of 3</div>
            <div className={styles.field}>
              <label className={styles.label}>Email</label>
              <input
                className={styles.input}
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                autoFocus
              />
            </div>
            {error && <div className={`${styles.message} ${styles.error}`}>{error}</div>}
            {message && <div className={`${styles.message} ${styles.success}`}>{message}</div>}
            <button className={styles.button} onClick={handleForgot} disabled={loading}>
              {loading ? "Sending..." : "Send OTP"}
            </button>
            <button type="button" className={styles.secondaryBtn} onClick={backToLogin}>
              Back to Sign in
            </button>
          </div>
        )}

        {step === "otp" && (
          <form className={styles.form} onSubmit={handleVerifyOtp}>
            <div className={styles.stepIndicator}>Step 2 of 3</div>
            <div className={styles.field}>
              <label className={styles.label}>Enter OTP sent to {email}</label>
              <input
                className={styles.input}
                type="text"
                inputMode="numeric"
                maxLength={6}
                value={otp}
                onChange={(e) => setOtp(e.target.value.replace(/\D/g, ""))}
                required
                autoFocus
              />
            </div>
            {error && <div className={`${styles.message} ${styles.error}`}>{error}</div>}
            {message && <div className={`${styles.message} ${styles.success}`}>{message}</div>}
            <button className={styles.button} type="submit" disabled={loading}>
              {loading ? "Verifying..." : "Verify OTP"}
            </button>
            <button type="button" className={styles.secondaryBtn} onClick={handleForgot} disabled={loading}>
              Resend OTP
            </button>
            <button type="button" className={styles.forgotLink} onClick={backToLogin}>
              Back to Sign in
            </button>
          </form>
        )}

        {step === "reset" && (
          <form className={styles.form} onSubmit={handleReset}>
            <div className={styles.stepIndicator}>Step 3 of 3</div>
            <div className={styles.field}>
              <label className={styles.label}>New password</label>
              <input
                className={styles.input}
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                required
                minLength={6}
                autoFocus
              />
            </div>
            <div className={styles.field}>
              <label className={styles.label}>Confirm password</label>
              <input
                className={styles.input}
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
                minLength={6}
              />
            </div>
            {error && <div className={`${styles.message} ${styles.error}`}>{error}</div>}
            <button className={styles.button} type="submit" disabled={loading}>
              {loading ? "Resetting..." : "Reset Password"}
            </button>
            <button type="button" className={styles.secondaryBtn} onClick={backToLogin}>
              Back to Sign in
            </button>
          </form>
        )}

        {step === "done" && (
          <div className={styles.form}>
            {message && <div className={`${styles.message} ${styles.success}`}>{message}</div>}
            <button className={styles.button} onClick={backToLogin}>
              Sign in with new password
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
