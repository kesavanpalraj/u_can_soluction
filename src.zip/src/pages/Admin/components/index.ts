export { NotionTable, type Column, type SortOption, type NotionTableProps } from './NotionTable';
