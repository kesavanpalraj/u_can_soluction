import { useState, useMemo, useEffect, useCallback } from 'react';
import { Search, ChevronUp, ChevronDown, ChevronLeft, ChevronRight, Pencil, Trash2, RotateCcw, ChevronDown as ChevronDownIcon, Filter, ArrowUpDown } from 'lucide-react';
import styles from './NotionTable.module.css';

export interface Column {
    key: string;
    label: string;
    sortable?: boolean;
    filterable?: boolean;
    width?: string;
    minWidth?: string;
    render?: (item: any) => React.ReactNode;
}

export type SortOption = {
    key: string;
    label: string;
    direction?: 'asc' | 'desc';
};

export interface NotionTableProps {
    data: any[];
    columns: Column[];
    selectable?: boolean;
    onSelect?: (selectedIds: string[]) => void;
    onView?: (item: any) => void;
    onEdit?: (item: any) => void;
    onDelete?: (item: any) => void;
    onRestore?: (item: any) => void;
    getRowId: (item: any) => string;
    searchPlaceholder?: string;
    emptyMessage?: string;
    showActions?: boolean;
    actionsConfig?: {
        view?: boolean;
        edit?: boolean;
        delete?: boolean;
        restore?: boolean;
    };
    pagination?: {
        page: number;
        totalPages: number;
        total: number;
        onPageChange: (page: number) => void;
    };
    filterOptions?: { key: string; label: string; options: { value: string; label: string; slug?: string }[] }[];
    sortOptions?: SortOption[];
}

export function NotionTable({
    data,
    columns,
    selectable = true,
    onSelect,
    onView,
    onEdit,
    onDelete,
    onRestore,
    getRowId,
    searchPlaceholder = 'Search...',
    emptyMessage = 'No data found',
    showActions = true,
    actionsConfig = { view: true, edit: true, delete: true, restore: false },
    pagination,
    filterOptions = [],
    sortOptions = []
}: NotionTableProps) {
    console.log('NotionTable received filterOptions:', filterOptions);
    const [search, setSearch] = useState('');
    const [sortKey, setSortKey] = useState<string | null>(sortOptions[0]?.key || null);
    const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>(sortOptions[0]?.direction || 'asc');
    const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
    const [filters, setFilters] = useState<Record<string, string>>({});
    const [openDropdown, setOpenDropdown] = useState<string | null>(null);

    useEffect(() => {
        const handleClickOutside = (e: MouseEvent) => {
            if (openDropdown && !(e.target as Element).closest(`.${styles.filterDropdown}`)) {
                setOpenDropdown(null);
            }
        };
        document.addEventListener('click', handleClickOutside);
        return () => document.removeEventListener('click', handleClickOutside);
    }, [openDropdown]);

    useEffect(() => {
        onSelect?.(Array.from(selectedIds));
    }, [selectedIds]);

    const handleSortChange = useCallback((key: string) => {
        if (sortKey === key) {
            setSortOrder(prev => prev === 'asc' ? 'desc' : 'asc');
        } else {
            setSortKey(key);
            const option = sortOptions.find(o => o.key === key);
            setSortOrder(option?.direction || 'asc');
        }
    }, [sortKey, sortOptions]);

    const handleSelectAll = useCallback(() => {
        if (selectedIds.size === data.length) {
            setSelectedIds(new Set());
        } else {
            setSelectedIds(new Set(data.map(getRowId)));
        }
    }, [data, getRowId, selectedIds.size]);

    const handleSelectOne = useCallback((id: string) => {
        setSelectedIds(prev => {
            const next = new Set(prev);
            if (next.has(id)) {
                next.delete(id);
            } else {
                next.add(id);
            }
            return next;
        });
    }, []);

    const filteredData = useMemo(() => {
        let result = [...data];

        if (search) {
            const searchLower = search.toLowerCase();
            result = result.filter(item => {
                return columns.some(col => {
                    const value = item[col.key];
                    if (value === null || value === undefined) return false;
                    return String(value).toLowerCase().includes(searchLower);
                });
            });
        }

        Object.entries(filters).forEach(([key]) => {
            if (filters[key] !== undefined && filters[key] !== null && filters[key] !== '') {
                const filterValue = filters[key];
                result = result.filter(item => {
                    const itemValue = item[key];
                    if (itemValue === null || itemValue === undefined) return false;
                    if (typeof itemValue === 'object' && itemValue !== null) {
                        if ('_id' in itemValue) {
                            return String(itemValue._id) === String(filterValue);
                        }
                        if ('name' in itemValue) {
                            return String(itemValue.name).toLowerCase().includes(filterValue.toLowerCase());
                        }
                    }
                    return String(itemValue).toLowerCase().includes(filterValue.toLowerCase());
                });
            }
        });

        if (sortKey) {
            const sortParts = sortKey.split('_');
            const sortField = sortParts[0];
            const direction = sortParts.length > 1 ? sortParts[1] : sortOrder;
            const dir = direction as 'asc' | 'desc';
            
            result.sort((a: any, b: any) => {
                let aVal = a[sortField];
                let bVal = b[sortField];
                
                if (typeof aVal === 'object' && aVal !== null) {
                    aVal = aVal.name || aVal.title || JSON.stringify(aVal);
                }
                if (typeof bVal === 'object' && bVal !== null) {
                    bVal = bVal.name || bVal.title || JSON.stringify(bVal);
                }
                
                if (aVal === bVal) return 0;
                if (aVal === null || aVal === undefined) return 1;
                if (bVal === null || bVal === undefined) return -1;
                
                const comparison = String(aVal).localeCompare(String(bVal));
                return dir === 'asc' ? comparison : -comparison;
            });
        }

        return result;
    }, [data, search, sortKey, sortOrder, filters, columns]);

    const getCellValue = (item: any, col: Column) => {
        if (col.render) {
            return col.render(item);
        }
        const value = item[col.key];
        if (value === null || value === undefined) return '-';
        if (typeof value === 'object') {
            return value.name || value.title || '-';
        }
        return String(value);
    };

    return (
        <div className={styles.container}>
            <div className={styles.toolbar}>
                <div className={styles.toolbarLeft}>
                    <div className={styles.searchContainer}>
                        <Search size={16} className={styles.searchIcon} />
                        <input
                            type="text"
                            placeholder={searchPlaceholder}
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                            className={styles.searchInput}
                        />
                    </div>
                    {filterOptions.map(filter => (
                        <div key={filter.key} className={styles.filterDropdown}>
                            <button 
                                className={`${styles.filterButton} ${openDropdown === filter.key ? styles.filterButtonActive : ''} ${filters[filter.key] ? styles.filterButtonActive : ''}`}
                                onClick={(e) => {
                                    e.stopPropagation();
                                    setOpenDropdown(openDropdown === filter.key ? null : filter.key);
                                }}
                            >
                                <Filter size={14} className={styles.filterIcon} />
                                <span className={filters[filter.key] ? styles.filterLabelActive : styles.filterLabel}>{filters[filter.key] ? filter.options.find(o => o.value === filters[filter.key])?.label || 'All' : 'All'}</span>
                                <ChevronDownIcon size={14} />
                            </button>
                            {openDropdown === filter.key && (
                                <div className={styles.filterMenu}>
                                    {filter.options.map(opt => (
                                        <button
                                            key={opt.value}
                                            className={`${styles.filterMenuItem} ${filters[filter.key] === opt.value ? styles.filterMenuItemActive : ''}`}
                                            onClick={() => {
                                                setFilters(prev => {
                                                    if (opt.slug === 'all') {
                                                        const newFilters = { ...prev };
                                                        delete newFilters[filter.key];
                                                        return newFilters;
                                                    }
                                                    return { ...prev, [filter.key]: opt.value };
                                                });
                                                setOpenDropdown(null);
                                            }}
                                        >
                                            {opt.label}
                                        </button>
                                    ))}
                                </div>
                            )}
                        </div>
                    ))}
                    {sortOptions.length > 0 && (
                        <div className={styles.filterDropdown}>
                            <button 
                                className={`${styles.filterButton} ${openDropdown === 'sort' ? styles.filterButtonActive : ''} ${sortKey ? styles.filterButtonActive : ''}`}
                                onClick={(e) => {
                                    e.stopPropagation();
                                    setOpenDropdown(openDropdown === 'sort' ? null : 'sort');
                                }}
                            >
                                <ArrowUpDown size={14} className={styles.filterIcon} />
                                <span className={sortKey ? styles.filterLabelActive : styles.filterLabel}>{sortOptions.find(o => o.key === sortKey)?.label || 'Sort'}</span>
                                <ChevronDownIcon size={14} />
                            </button>
                            {openDropdown === 'sort' && (
                                <div className={styles.filterMenu}>
                                    {sortOptions.map(opt => (
                                        <button
                                            key={opt.key}
                                            className={`${styles.filterMenuItem} ${sortKey === opt.key ? styles.filterMenuItemActive : ''}`}
                                            onClick={() => {
                                                handleSortChange(opt.key);
                                                setOpenDropdown(null);
                                            }}
                                        >
                                            {opt.label}
                                        </button>
                                    ))}
                                </div>
                            )}
                        </div>
                    )}
                </div>
                {selectedIds.size > 0 && (
                    <div className={styles.selectedCount}>
                        {selectedIds.size} selected
                    </div>
                )}
            </div>

            <div className={styles.tableWrapper}>
                <table className={styles.table}>
                    <thead>
                        <tr>
                            {selectable && (
                                <th className={styles.checkboxHeader}>
                                    <input
                                        type="checkbox"
                                        checked={selectedIds.size === data.length && data.length > 0}
                                        onChange={handleSelectAll}
                                        className={styles.checkbox}
                                    />
                                </th>
                            )}
                            {showActions && (
                                <th className={styles.actionsHeader}>Actions</th>
                            )}
                            {columns.map(col => (
                                <th key={col.key} style={{ width: col.width, minWidth: col.minWidth }}>
                                    <div className={styles.headerCell}>
                                        {col.sortable ? (
                                            <button
                                                className={styles.sortButton}
                                                onClick={() => handleSortChange(col.key)}
                                            >
                                                <span>{col.label}</span>
                                                {sortKey === col.key && (
                                                    sortOrder === 'asc' ? <ChevronUp size={14} /> : <ChevronDown size={14} />
                                                )}
                                            </button>
                                        ) : (
                                            <span>{col.label}</span>
                                        )}
                                    </div>
                                </th>
                            ))}
                        </tr>
                    </thead>
                    <tbody>
                        {filteredData.length === 0 ? (
                            <tr>
                                <td colSpan={(selectable ? 1 : 0) + (showActions ? 1 : 0) + columns.length} className={styles.emptyRow}>
                                    {emptyMessage}
                                </td>
                            </tr>
                        ) : (
                            filteredData.map((item: any) => (
                                <tr key={getRowId(item)} className={selectedIds.has(getRowId(item)) ? styles.selectedRow : ''}>
                                    {selectable && (
                                        <td className={styles.checkboxCell}>
                                            <input
                                                type="checkbox"
                                                checked={selectedIds.has(getRowId(item))}
                                                onChange={() => handleSelectOne(getRowId(item))}
                                                className={styles.checkbox}
                                            />
                                        </td>
                                    )}
                                    {showActions && (
                                        <td className={styles.actionsCell}>
                                            {actionsConfig?.edit && onEdit && (
                                                <button onClick={() => onEdit(item)} className={styles.actionBtn} title="Edit">
                                                    <Pencil size={16} />
                                                </button>
                                            )}
                                            {actionsConfig?.restore && onRestore && (
                                                <button onClick={() => onRestore(item)} className={`${styles.actionBtn} ${styles.restoreBtn}`} title="Restore">
                                                    <RotateCcw size={16} />
                                                </button>
                                            )}
                                            {actionsConfig?.delete && onDelete && (
                                                <button onClick={() => onDelete(item)} className={`${styles.actionBtn} ${styles.deleteBtn}`} title="Delete">
                                                    <Trash2 size={16} />
                                                </button>
                                            )}
                                            {actionsConfig?.view && onView && (
                                                <button onClick={() => onView(item)} className={styles.actionBtn} title="View">
                                                    <ChevronRight size={16} />
                                                </button>
                                            )}
                                        </td>
                                    )}
                                    {columns.map(col => (
                                        <td key={col.key} className={styles.cell}>
                                            {getCellValue(item, col)}
                                        </td>
                                    ))}
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>

            <div className={styles.cardList}>
                {filteredData.length === 0 ? (
                    <div className={styles.cardEmpty}>{emptyMessage}</div>
                ) : (
                    filteredData.map((item: any) => (
                        <div 
                            key={getRowId(item)} 
                            className={`${styles.card} ${selectedIds.has(getRowId(item)) ? styles.selected : ''}`}
                        >
                            <div className={styles.cardHeader}>
                                {selectable && (
                                    <input
                                        type="checkbox"
                                        checked={selectedIds.has(getRowId(item))}
                                        onChange={() => handleSelectOne(getRowId(item))}
                                        className={`${styles.checkbox} ${styles.cardCheckbox}`}
                                    />
                                )}
                                <div className={styles.cardContent}>
                                    {columns.slice(0, 2).map((col) => (
                                        <div key={col.key} className={styles.cardMeta}>
                                            <span className={styles.cardMetaItem}>{getCellValue(item, col)}</span>
                                        </div>
                                    ))}
                                    {columns.slice(2).map((col) => (
                                        <div key={col.key} className={styles.cardMeta}>
                                            <span style={{ fontWeight: 500, color: '#737373', fontSize: '12px' }}>{col.label}: </span>
                                            <span className={styles.cardMetaItem}>{getCellValue(item, col)}</span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                            {showActions && (
                                <div className={styles.cardActions}>
                                    {actionsConfig?.edit && onEdit && (
                                        <button onClick={() => onEdit(item)} className={styles.cardActionBtn} title="Edit">
                                            <Pencil size={18} />
                                        </button>
                                    )}
                                    {actionsConfig?.restore && onRestore && (
                                        <button onClick={() => onRestore(item)} className={styles.cardActionBtn} title="Restore">
                                            <RotateCcw size={18} />
                                        </button>
                                    )}
                                    {actionsConfig?.delete && onDelete && (
                                        <button onClick={() => onDelete(item)} className={`${styles.cardActionBtn} ${styles.delete}`} title="Delete">
                                            <Trash2 size={18} />
                                        </button>
                                    )}
                                    {actionsConfig?.view && onView && (
                                        <button onClick={() => onView(item)} className={styles.cardActionBtn} title="View">
                                            <ChevronRight size={18} />
                                        </button>
                                    )}
                                </div>
                            )}
                        </div>
                    ))
                )}
            </div>

            {pagination && (
                <div className={styles.pagination}>
                    <span className={styles.paginationInfo}>
                        Showing {filteredData.length} of {pagination.total}
                    </span>
                    <div className={styles.paginationControls}>
                        <button
                            onClick={() => pagination.onPageChange(pagination.page - 1)}
                            disabled={pagination.page === 1}
                            className={styles.paginationBtn}
                        >
                            <ChevronLeft size={16} />
                        </button>
                        <span className={styles.paginationPage}>
                            Page {pagination.page} of {pagination.totalPages}
                        </span>
                        <button
                            onClick={() => pagination.onPageChange(pagination.page + 1)}
                            disabled={pagination.page === pagination.totalPages}
                            className={styles.paginationBtn}
                        >
                            <ChevronRight size={16} />
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
}
