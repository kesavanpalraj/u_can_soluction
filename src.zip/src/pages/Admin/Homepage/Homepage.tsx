import { useState, useEffect, useRef } from 'react';
import { Plus, Edit, Trash2, X, Check, ChevronDown, Upload } from 'lucide-react';
import { newsEventApi, homepageSettingsApi, uploadApi, NewsEvent, HomepageSettings } from '../../../api';
import { Button } from '../../../components/Button';
import { Drawer } from '../../../components/Drawer';
import { Input } from '../../../components/Input';
import { Select } from '../../../components/Select';
import { useToast } from '../../../components/Toast';
import { ConfirmModal } from '../../../components/Modal';
import styles from './Homepage.module.css';

type SectionKey = 'news' | 'stats' | 'testimonials';

const SectionToggle: React.FC<{ label: string; isOpen: boolean; onToggle: () => void }> = ({ label, isOpen, onToggle }) => (
    <button className={styles.sectionToggle} onClick={onToggle} type="button">
        <span>{label}</span>
        <ChevronDown size={18} className={`${styles.sectionChevron} ${isOpen ? styles.sectionChevronOpen : ''}`} />
    </button>
);

export const Homepage = () => {
    const { addToast } = useToast();

    const [openSections, setOpenSections] = useState<Record<SectionKey, boolean>>({
        news: false, stats: false, testimonials: false,
    });

    const toggleSection = (key: SectionKey) => setOpenSections(prev => ({ ...prev, [key]: !prev[key] }));

    // ── News & Events ──
    const [newsItems, setNewsItems] = useState<NewsEvent[]>([]);
    const [newsLoading, setNewsLoading] = useState(true);
    const [newsFormOpen, setNewsFormOpen] = useState(false);
    const [editingNews, setEditingNews] = useState<NewsEvent | null>(null);
    const [deleteNewsId, setDeleteNewsId] = useState<string | null>(null);
    const [newsForm, setNewsForm] = useState({ title: '', type: 'news' as 'news' | 'event', link: '', isActive: true, order: 0 });

    const fetchNews = async () => {
        setNewsLoading(true);
        try {
            const data = await newsEventApi.getAll();
            setNewsItems(data);
        } catch (error) {
            console.error('Failed to fetch news:', error);
        } finally {
            setNewsLoading(false);
        }
    };

    useEffect(() => { fetchNews(); }, []);

    const handleAddNews = () => {
        setEditingNews(null);
        setNewsForm({ title: '', type: 'news', link: '', isActive: true, order: 0 });
        setNewsFormOpen(true);
    };

    const handleEditNews = (item: NewsEvent) => {
        setEditingNews(item);
        setNewsForm({ title: item.title, type: item.type, link: item.link || '', isActive: item.isActive, order: item.order });
        setNewsFormOpen(true);
    };

    const handleDeleteNews = async () => {
        if (!deleteNewsId) return;
        try {
            await newsEventApi.remove(deleteNewsId);
            addToast('Item deleted', 'success');
            setDeleteNewsId(null);
            fetchNews();
        } catch (error) {
            addToast('Failed to delete', 'error');
        }
    };

    const handleSaveNews = async () => {
        if (!newsForm.title.trim()) {
            addToast('Title is required', 'error');
            return;
        }
        try {
            if (editingNews) {
                await newsEventApi.update(editingNews._id, newsForm);
                addToast('Item updated', 'success');
            } else {
                await newsEventApi.create(newsForm);
                addToast('Item added', 'success');
            }
            setNewsFormOpen(false);
            fetchNews();
        } catch (error) {
            addToast('Failed to save', 'error');
        }
    };

    // ── Settings (Stats + Testimonials + Google Rating) ──
    const [settings, setSettings] = useState<HomepageSettings | null>(null);
    const [settingsLoading, setSettingsLoading] = useState(true);

    const fetchSettings = async () => {
        setSettingsLoading(true);
        try {
            const data = await homepageSettingsApi.get();
            setSettings(data);
        } catch (error) {
            console.error('Failed to fetch settings:', error);
        } finally {
            setSettingsLoading(false);
        }
    };

    useEffect(() => { fetchSettings(); }, []);

    // Stats
    const [localStats, setLocalStats] = useState<HomepageSettings['stats']>([]);
    useEffect(() => {
        if (settings) setLocalStats(settings.stats);
    }, [settings]);

    const handleStatChange = (index: number, field: 'value' | 'suffix' | 'label', value: string | number) => {
        setLocalStats(prev => prev.map((s, i) => i === index ? { ...s, [field]: value } : s));
    };

    const handleSaveStats = async () => {
        try {
            if (!settings) return;
            const updated = await homepageSettingsApi.update({ ...settings, stats: localStats });
            setSettings(updated);
            addToast('Stats saved', 'success');
        } catch (error) {
            addToast('Failed to save stats', 'error');
        }
    };

    // Google Rating
    const [googleRating, setGoogleRating] = useState({ rating: 4.9, count: 120 });
    useEffect(() => {
        if (settings) setGoogleRating(settings.googleRating);
    }, [settings]);

    const handleSaveGoogleRating = async () => {
        try {
            if (!settings) return;
            const updated = await homepageSettingsApi.update({ ...settings, googleRating });
            setSettings(updated);
            addToast('Google rating saved', 'success');
        } catch (error) {
            addToast('Failed to save Google rating', 'error');
        }
    };

    // Testimonials
    const [localTestimonials, setLocalTestimonials] = useState<HomepageSettings['testimonials']>([]);
    useEffect(() => {
        if (settings) setLocalTestimonials(settings.testimonials);
    }, [settings]);

    const [testimonialFormOpen, setTestimonialFormOpen] = useState(false);
    const [editingTestimonial, setEditingTestimonial] = useState<{ index: number } | null>(null);
    const [deleteTestimonialIndex, setDeleteTestimonialIndex] = useState<number | null>(null);
    const [testimonialForm, setTestimonialForm] = useState({ name: '', profilePic: '', rating: 5, text: '' });
    const [uploading, setUploading] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleAddTestimonial = () => {
        setEditingTestimonial(null);
        setTestimonialForm({ name: '', profilePic: '', rating: 5, text: '' });
        setTestimonialFormOpen(true);
    };

    const handleEditTestimonial = (index: number) => {
        setEditingTestimonial({ index });
        setTestimonialForm(localTestimonials[index]);
        setTestimonialFormOpen(true);
    };

    const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;
        setUploading(true);
        try {
            if (editingTestimonial !== null) {
                const oldUrl = localTestimonials[editingTestimonial.index]?.profilePic;
                if (oldUrl) uploadApi.delete(oldUrl).catch(() => {});
            }
            const result = await uploadApi.upload(file);
            setTestimonialForm(prev => ({ ...prev, profilePic: result.url }));
            addToast('Image uploaded', 'success');
        } catch (error) {
            addToast('Upload failed', 'error');
        } finally {
            setUploading(false);
            if (fileInputRef.current) fileInputRef.current.value = '';
        }
    };

    const handleSaveTestimonial = () => {
        if (!testimonialForm.name.trim()) {
            addToast('Name is required', 'error');
            return;
        }
        if (!testimonialForm.text.trim()) {
            addToast('Review text is required', 'error');
            return;
        }

        setLocalTestimonials(prev => {
            if (editingTestimonial !== null) {
                const updated = [...prev];
                updated[editingTestimonial.index] = testimonialForm;
                return updated;
            }
            return [...prev, testimonialForm];
        });
        setTestimonialFormOpen(false);
    };

    const handleDeleteTestimonial = () => {
        if (deleteTestimonialIndex === null) return;
        setLocalTestimonials(prev => prev.filter((_, i) => i !== deleteTestimonialIndex));
        setDeleteTestimonialIndex(null);
    };

    const handleSaveTestimonials = async () => {
        try {
            if (!settings) return;
            const updated = await homepageSettingsApi.update({ ...settings, testimonials: localTestimonials });
            setSettings(updated);
            addToast('Testimonials saved', 'success');
        } catch (error) {
            addToast('Failed to save testimonials', 'error');
        }
    };

    // ── Render ──
    return (
        <div className={styles.page}>
            <div className={styles.header}>
                <h1 className={styles.title}>Homepage Settings</h1>
            </div>

            {/* ────────────── News & Events Section ────────────── */}
            <div className={styles.section}>
                <SectionToggle label={`News & Events (${newsItems.length})`} isOpen={openSections.news} onToggle={() => toggleSection('news')} />
                {openSections.news && (
                    <div className={styles.sectionContent}>
                        <div className={styles.sectionActions}>
                            <Button onClick={handleAddNews}><Plus size={16} /> Add News</Button>
                        </div>

                        {newsLoading ? (
                            <div className={styles.loading}>Loading...</div>
                        ) : newsItems.length === 0 ? (
                            <div className={styles.empty}>No news or events yet</div>
                        ) : (
                            <div className={styles.list}>
                                {newsItems.map(item => (
                                    <div key={item._id} className={styles.row}>
                                        <div className={styles.rowLeft}>
                                            <span className={`${styles.dot} ${item.type === 'event' ? styles.dotEvent : styles.dotNews}`} />
                                            <div className={styles.rowContent}>
                                                <span className={styles.rowTitle}>{item.title}</span>
                                                <span className={styles.rowMeta}>{item.type === 'event' ? 'Event' : 'News'} · Order {item.order}</span>
                                            </div>
                                        </div>
                                        <div className={styles.rowRight}>
                                            <span className={`${styles.badge} ${item.isActive ? styles.badgeActive : styles.badgeInactive}`}>
                                                {item.isActive ? 'Active' : 'Inactive'}
                                            </span>
                                            <button className={styles.rowBtn} onClick={() => handleEditNews(item)} aria-label="Edit"><Edit size={14} /></button>
                                            <button className={styles.rowBtn} onClick={() => setDeleteNewsId(item._id)} aria-label="Delete"><Trash2 size={14} /></button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                )}
            </div>

            {/* ────────────── Stats Section ────────────── */}
            <div className={styles.section}>
                <SectionToggle label={`Stats (${localStats.length} items)`} isOpen={openSections.stats} onToggle={() => toggleSection('stats')} />
                {openSections.stats && (
                    <div className={styles.sectionContent}>
                        {settingsLoading ? (
                            <div className={styles.loading}>Loading...</div>
                        ) : (
                            <>
                                <div className={styles.statsTable}>
                                    <div className={styles.statsHeader}>
                                        <span>Value</span><span>Suffix</span><span>Label</span><span />
                                    </div>
                                    {localStats.map((stat, i) => (
                                        <div key={i} className={styles.statsRow}>
                                            <Input type="number" value={String(stat.value)} onChange={e => handleStatChange(i, 'value', Number(e.target.value))} />
                                            <Input value={stat.suffix} onChange={e => handleStatChange(i, 'suffix', e.target.value)} placeholder="e.g. +" />
                                            <Input value={stat.label} onChange={e => handleStatChange(i, 'label', e.target.value)} placeholder="e.g. Students Trained" />
                                        </div>
                                    ))}
                                </div>
                                <div className={styles.sectionActions}>
                                    <Button onClick={handleSaveStats}>Save Stats</Button>
                                </div>
                            </>
                        )}
                    </div>
                )}
            </div>

            {/* ────────────── Testimonials Section ────────────── */}
            <div className={styles.section}>
                <SectionToggle label={`Testimonials (${localTestimonials.length})`} isOpen={openSections.testimonials} onToggle={() => toggleSection('testimonials')} />
                {openSections.testimonials && (
                    <div className={styles.sectionContent}>
                        {settingsLoading ? (
                            <div className={styles.loading}>Loading...</div>
                        ) : (
                            <>
                                {/* Google Rating */}
                                <div className={styles.fieldGroup}>
                                    <h3 className={styles.fieldGroupTitle}>Google Rating</h3>
                                    <div className={styles.googleFields}>
                                        <div className={styles.field}>
                                            <label className={styles.label}>Rating</label>
                                            <Input type="number" step="0.1" min="0" max="5" value={String(googleRating.rating)} onChange={e => setGoogleRating(prev => ({ ...prev, rating: Number(e.target.value) }))} />
                                        </div>
                                        <div className={styles.field}>
                                            <label className={styles.label}>Review Count</label>
                                            <Input type="number" value={String(googleRating.count)} onChange={e => setGoogleRating(prev => ({ ...prev, count: Number(e.target.value) }))} />
                                        </div>
                                    </div>
                                    <div className={styles.sectionActions}>
                                        <Button onClick={handleSaveGoogleRating}>Save Google Rating</Button>
                                    </div>
                                </div>

                                {/* Student Reviews */}
                                <div className={styles.fieldGroup}>
                                    <h3 className={styles.fieldGroupTitle}>Student Reviews</h3>
                                    <div className={styles.sectionActions}>
                                        <Button onClick={handleAddTestimonial}><Plus size={16} /> Add Review</Button>
                                    </div>

                                    {localTestimonials.length === 0 ? (
                                        <div className={styles.empty}>No reviews yet</div>
                                    ) : (
                                        <div className={styles.list}>
                                            {localTestimonials.map((t, i) => (
                                                <div key={i} className={styles.row}>
                                                    <div className={styles.rowLeft}>
                                                        <div className={styles.testimonialAvatar}>
                                                            {t.profilePic ? <img src={t.profilePic} alt={t.name} className={styles.avatarImg} /> : t.name.charAt(0).toUpperCase()}
                                                        </div>
                                                        <div className={styles.rowContent}>
                                                            <span className={styles.rowTitle}>{t.name}</span>
                                                            <span className={styles.rowMeta}>{'★'.repeat(t.rating)} · {t.text.slice(0, 60)}...</span>
                                                        </div>
                                                    </div>
                                                    <div className={styles.rowRight}>
                                                        <button className={styles.rowBtn} onClick={() => handleEditTestimonial(i)} aria-label="Edit"><Edit size={14} /></button>
                                                        <button className={styles.rowBtn} onClick={() => setDeleteTestimonialIndex(i)} aria-label="Delete"><Trash2 size={14} /></button>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    )}

                                    <div className={styles.sectionActions}>
                                        <Button onClick={handleSaveTestimonials}>Save All Testimonials</Button>
                                    </div>
                                </div>
                            </>
                        )}
                    </div>
                )}
            </div>

            {/* ── News Form Drawer ── */}
            <Drawer isOpen={newsFormOpen} onClose={() => setNewsFormOpen(false)} title={editingNews ? 'Edit News / Event' : 'Add News / Event'} maxWidth="500px"
                footer={<><Button variant="secondary" onClick={() => setNewsFormOpen(false)}>Cancel</Button><Button onClick={handleSaveNews}>{editingNews ? 'Save Changes' : 'Add'}</Button></>}
            >
                <div className={styles.form}>
                    <div className={styles.field}><label className={styles.label}>Title *</label><Input value={newsForm.title} onChange={e => setNewsForm(prev => ({ ...prev, title: e.target.value }))} placeholder="News or event title" /></div>
                    <div className={styles.field}><label className={styles.label}>Type</label><Select value={newsForm.type} options={[{ value: 'news', label: 'News' }, { value: 'event', label: 'Event' }]} onChange={val => setNewsForm(prev => ({ ...prev, type: val as 'news' | 'event' }))} /></div>
                    <div className={styles.field}><label className={styles.label}>Link (optional)</label><Input value={newsForm.link} onChange={e => setNewsForm(prev => ({ ...prev, link: e.target.value }))} placeholder="https://..." /></div>
                    <div className={styles.fieldRow}>
                        <div className={styles.field}><label className={styles.label}>Order</label><Input type="number" value={String(newsForm.order)} onChange={e => setNewsForm(prev => ({ ...prev, order: Number(e.target.value) }))} /></div>
                        <div className={styles.field}>
                            <label className={styles.label}>Active</label>
                            <div className={styles.toggleGroup}>
                                <button className={`${styles.toggleBtn} ${newsForm.isActive ? styles.toggleActive : ''}`} onClick={() => setNewsForm(prev => ({ ...prev, isActive: true }))}><Check size={14} /> Active</button>
                                <button className={`${styles.toggleBtn} ${!newsForm.isActive ? styles.toggleInactive : ''}`} onClick={() => setNewsForm(prev => ({ ...prev, isActive: false }))}><X size={14} /> Inactive</button>
                            </div>
                        </div>
                    </div>
                </div>
            </Drawer>

            {/* ── Testimonial Form Drawer ── */}
            <Drawer isOpen={testimonialFormOpen} onClose={() => setTestimonialFormOpen(false)} title={editingTestimonial !== null ? 'Edit Review' : 'Add Review'} maxWidth="500px"
                footer={<><Button variant="secondary" onClick={() => setTestimonialFormOpen(false)}>Cancel</Button><Button onClick={handleSaveTestimonial}>{editingTestimonial !== null ? 'Save Changes' : 'Add'}</Button></>}
            >
                <div className={styles.form}>
                    <div className={styles.field}><label className={styles.label}>Name *</label><Input value={testimonialForm.name} onChange={e => setTestimonialForm(prev => ({ ...prev, name: e.target.value }))} placeholder="Student name" /></div>
                    <div className={styles.field}>
                        <label className={styles.label}>Rating</label>
                        <Select value={String(testimonialForm.rating)} options={[5, 4, 3, 2, 1].map(v => ({ value: String(v), label: '★'.repeat(v) }))} onChange={val => setTestimonialForm(prev => ({ ...prev, rating: Number(val) }))} />
                    </div>
                    <div className={styles.field}>
                        <label className={styles.label}>Review *</label>
                        <textarea className={styles.textarea} value={testimonialForm.text} onChange={e => setTestimonialForm(prev => ({ ...prev, text: e.target.value }))} placeholder="What the student said..." rows={4} />
                    </div>
                    <div className={styles.field}>
                        <label className={styles.label}>Profile Picture</label>
                        <div className={styles.uploadRow}>
                            <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFileUpload} hidden />
                            <Button variant="secondary" onClick={() => fileInputRef.current?.click()} disabled={uploading}>
                                <Upload size={14} /> {uploading ? 'Uploading...' : 'Choose Image'}
                            </Button>
                            {testimonialForm.profilePic && (
                                <>
                                    <img src={testimonialForm.profilePic} alt="Preview" className={styles.uploadPreview} />
                                    <button className={styles.removePicBtn} onClick={() => setTestimonialForm(prev => ({ ...prev, profilePic: '' }))} aria-label="Remove image"><X size={14} /></button>
                                </>
                            )}
                        </div>
                    </div>
                </div>
            </Drawer>

            {/* ── Confirm Modals ── */}
            <ConfirmModal isOpen={!!deleteNewsId} onClose={() => setDeleteNewsId(null)} onConfirm={handleDeleteNews} title="Delete item?" message="This news/event will be permanently deleted." confirmText="Delete" cancelText="Cancel" />
            <ConfirmModal isOpen={deleteTestimonialIndex !== null} onClose={() => setDeleteTestimonialIndex(null)} onConfirm={handleDeleteTestimonial} title="Delete review?" message="This review will be removed. Changes are saved only when you click 'Save All Testimonials'." confirmText="Delete" cancelText="Cancel" />
        </div>
    );
};
