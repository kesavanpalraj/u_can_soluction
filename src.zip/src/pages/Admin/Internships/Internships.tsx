import { useState, useEffect } from 'react';
import { Plus, Pencil, Trash2, X, Check } from 'lucide-react';
import { internshipDomainApi, internshipDurationApi, InternshipDomain, InternshipDuration } from '../../../api';
import { Button } from '../../../components/Button';
import { useToast } from '../../../components/Toast';
import { ConfirmModal } from '../../../components/Modal';
import styles from './Internships.module.css';

export const Internships: React.FC = () => {
  const [domains, setDomains] = useState<InternshipDomain[]>([]);
  const [durations, setDurations] = useState<InternshipDuration[]>([]);
  const [newDomain, setNewDomain] = useState('');
  const [newDuration, setNewDuration] = useState('');
  const [editingDomain, setEditingDomain] = useState<{ id: string; name: string; order: number } | null>(null);
  const [editingDuration, setEditingDuration] = useState<{ id: string; name: string; order: number } | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<{ type: 'domain' | 'duration'; id: string } | null>(null);
  const { addToast } = useToast();

  const fetchDomains = () => {
    internshipDomainApi.getAll().then(setDomains).catch(() => addToast('Failed to load domains', 'error'));
  };

  const fetchDurations = () => {
    internshipDurationApi.getAll().then(setDurations).catch(() => addToast('Failed to load durations', 'error'));
  };

  useEffect(() => { fetchDomains(); fetchDurations(); }, []);

  const addDomain = async () => {
    const name = newDomain.trim();
    if (!name) return;
    try {
      await internshipDomainApi.create({ name, order: domains.length });
      setNewDomain('');
      addToast('Domain added', 'success');
      fetchDomains();
    } catch { addToast('Failed to add domain', 'error'); }
  };

  const addDuration = async () => {
    const name = newDuration.trim();
    if (!name) return;
    try {
      await internshipDurationApi.create({ name, order: durations.length });
      setNewDuration('');
      addToast('Duration added', 'success');
      fetchDurations();
    } catch { addToast('Failed to add duration', 'error'); }
  };

  const saveDomainEdit = async () => {
    if (!editingDomain) return;
    try {
      await internshipDomainApi.update(editingDomain.id, { name: editingDomain.name, order: editingDomain.order });
      setEditingDomain(null);
      addToast('Domain updated', 'success');
      fetchDomains();
    } catch { addToast('Failed to update domain', 'error'); }
  };

  const saveDurationEdit = async () => {
    if (!editingDuration) return;
    try {
      await internshipDurationApi.update(editingDuration.id, { name: editingDuration.name, order: editingDuration.order });
      setEditingDuration(null);
      addToast('Duration updated', 'success');
      fetchDurations();
    } catch { addToast('Failed to update duration', 'error'); }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      if (deleteTarget.type === 'domain') {
        await internshipDomainApi.remove(deleteTarget.id);
        addToast('Domain deleted', 'success');
      } else {
        await internshipDurationApi.remove(deleteTarget.id);
        addToast('Duration deleted', 'success');
      }
      setDeleteTarget(null);
      fetchDomains();
      fetchDurations();
    } catch { addToast('Failed to delete', 'error'); }
  };

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <h1 className={styles.title}>Internships</h1>
        <p className={styles.subtitle}>Manage internship form options</p>
      </div>

      <div className={styles.sections}>
        <section className={styles.section}>
          <h2 className={styles.sectionTitle}>Internship Domains</h2>
          <div className={styles.addRow}>
            <input
              className={styles.addInput}
              placeholder="Enter domain name"
              value={newDomain}
              onChange={e => setNewDomain(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && addDomain()}
            />
            <Button onClick={addDomain} disabled={!newDomain.trim()}>
              <Plus size={16} />
              Add
            </Button>
          </div>
          <div className={styles.list}>
            {domains.map(d => (
              <div key={d._id} className={styles.item}>
                {editingDomain?.id === d._id ? (
                  <>
                    <input
                      className={styles.editInput}
                      value={editingDomain.name}
                      onChange={e => setEditingDomain({ ...editingDomain, name: e.target.value })}
                    />
                    <input
                      className={styles.orderInput}
                      type="number"
                      value={editingDomain.order}
                      onChange={e => setEditingDomain({ ...editingDomain, order: Number(e.target.value) })}
                    />
                    <button className={styles.iconBtn} onClick={saveDomainEdit} aria-label="Save">
                      <Check size={16} />
                    </button>
                    <button className={styles.iconBtn} onClick={() => setEditingDomain(null)} aria-label="Cancel">
                      <X size={16} />
                    </button>
                  </>
                ) : (
                  <>
                    <span className={styles.itemOrder}>{d.order}</span>
                    <span className={styles.itemName}>{d.name}</span>
                    <button className={styles.iconBtn} onClick={() => setEditingDomain({ id: d._id, name: d.name, order: d.order })} aria-label="Edit">
                      <Pencil size={16} />
                    </button>
                    <button className={styles.iconBtnDanger} onClick={() => setDeleteTarget({ type: 'domain', id: d._id })} aria-label="Delete">
                      <Trash2 size={16} />
                    </button>
                  </>
                )}
              </div>
            ))}
          </div>
        </section>

        <section className={styles.section}>
          <h2 className={styles.sectionTitle}>Internship Durations</h2>
          <div className={styles.addRow}>
            <input
              className={styles.addInput}
              placeholder="Enter duration (e.g. 15 Days)"
              value={newDuration}
              onChange={e => setNewDuration(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && addDuration()}
            />
            <Button onClick={addDuration} disabled={!newDuration.trim()}>
              <Plus size={16} />
              Add
            </Button>
          </div>
          <div className={styles.list}>
            {durations.map(d => (
              <div key={d._id} className={styles.item}>
                {editingDuration?.id === d._id ? (
                  <>
                    <input
                      className={styles.editInput}
                      value={editingDuration.name}
                      onChange={e => setEditingDuration({ ...editingDuration, name: e.target.value })}
                    />
                    <input
                      className={styles.orderInput}
                      type="number"
                      value={editingDuration.order}
                      onChange={e => setEditingDuration({ ...editingDuration, order: Number(e.target.value) })}
                    />
                    <button className={styles.iconBtn} onClick={saveDurationEdit} aria-label="Save">
                      <Check size={16} />
                    </button>
                    <button className={styles.iconBtn} onClick={() => setEditingDuration(null)} aria-label="Cancel">
                      <X size={16} />
                    </button>
                  </>
                ) : (
                  <>
                    <span className={styles.itemOrder}>{d.order}</span>
                    <span className={styles.itemName}>{d.name}</span>
                    <button className={styles.iconBtn} onClick={() => setEditingDuration({ id: d._id, name: d.name, order: d.order })} aria-label="Edit">
                      <Pencil size={16} />
                    </button>
                    <button className={styles.iconBtnDanger} onClick={() => setDeleteTarget({ type: 'duration', id: d._id })} aria-label="Delete">
                      <Trash2 size={16} />
                    </button>
                  </>
                )}
              </div>
            ))}
          </div>
        </section>
      </div>

      <ConfirmModal
        isOpen={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        title="Delete option?"
        message={`This will remove the selected ${deleteTarget?.type}. Existing applications will keep their value.`}
        confirmText="Delete"
        cancelText="Cancel"
      />
    </div>
  );
};
