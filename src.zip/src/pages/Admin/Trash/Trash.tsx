import { useState, useEffect, useRef } from 'react';
import { ChevronDown, Filter } from 'lucide-react';
import { NotionTable } from '../components';
import { Drawer } from '../../../components/Drawer';
import { useToast } from '../../../components/Toast';
import { ConfirmModal } from '../../../components/Modal';
import styles from './Trash.module.css';

interface TrashItem {
    _id: string;
    type: string;
    source: string;
    name?: string;
    title?: string;
    item?: { title?: string; projectId?: string; courseId?: string; internshipId?: string };
    deletedAt: string;
}

const FILTER_OPTIONS = [
    { value: 'all', label: 'All Sources' },
    { value: 'project', label: 'Projects' },
    { value: 'course', label: 'Courses' },
    { value: 'enquiry-project', label: 'Project Enquiries' },
    { value: 'enquiry-course', label: 'Course Enquiries' },
    { value: 'enquiry-internship', label: 'Internship Applications' },
];

export const Trash: React.FC = () => {
    const [items, setItems] = useState<TrashItem[]>([]);
    const [loading, setLoading] = useState(true);
    const [page, setPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const [total, setTotal] = useState(0);
    const [filterSource, setFilterSource] = useState<string>('all');
    const [filterOpen, setFilterOpen] = useState(false);
    const [confirmDelete, setConfirmDelete] = useState<TrashItem | null>(null);
    const [viewItem, setViewItem] = useState<any>(null);
    const filterRef = useRef<HTMLDivElement>(null);
    const { addToast } = useToast();

    useEffect(() => {
        const handleClickOutside = (e: MouseEvent) => {
            if (filterRef.current && !filterRef.current.contains(e.target as Node)) {
                setFilterOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    useEffect(() => {
        fetchTrash();
    }, [page, filterSource]);

    const fetchTrash = async () => {
        setLoading(true);
        try {
            await fetch('/api/enquiries/cleanup', { method: 'POST' });

            const params = new URLSearchParams({ page: String(page), limit: '20' });
            if (filterSource !== 'all') params.set('type', filterSource);

            const res = await fetch(`/api/enquiries/trashed?${params}`);
            if (res.ok) {
                const data = await res.json();
                setItems(data.items || []);
                setTotal(data.total || 0);
                setTotalPages(data.totalPages || 1);
            }
        } catch (error) {
            console.error('Failed to fetch trash:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleRestore = async (item: TrashItem) => {
        try {
            let res;
            
            if (item.source === 'Inventory') {
                if (item.type === 'project') {
                    res = await fetch(`/api/projects/${item._id}/restore`, { method: 'POST' });
                } else if (item.type === 'course') {
                    res = await fetch(`/api/courses/${item._id}/restore`, { method: 'POST' });
                }
            } else {
                const typeMap: Record<string, string> = {
                    'Project Enquiry': 'project',
                    'Course Enquiry': 'course',
                    'Internship Application': 'internship'
                };
                const type = typeMap[item.source] || 'project';
                res = await fetch(`/api/enquiries/restore/${item._id}`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ type })
                });
            }

            if (res?.ok) {
                addToast('Item restored', 'success');
                fetchTrash();
            }
        } catch (error) {
            console.error('Failed to restore item:', error);
            addToast('Failed to restore item', 'error');
        }
    };

    const handlePermanentDelete = async (item: TrashItem) => {
        try {
            const typeMap: Record<string, string> = {
                'Inventory': item.type === 'project' ? 'project' : 'course',
                'Project Enquiry': 'enquiry-project',
                'Course Enquiry': 'enquiry-course',
                'Internship Application': 'enquiry-internship',
            };
            const type = typeMap[item.source] || 'project';

            const res = await fetch(`/api/enquiries/permanent/${item._id}`, {
                method: 'DELETE',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ type })
            });

            if (res.ok) {
                addToast('Item permanently deleted', 'success');
                setConfirmDelete(null);
                fetchTrash();
            }
        } catch (error) {
            console.error('Failed to delete item:', error);
            addToast('Failed to delete item', 'error');
        }
    };

    const getDaysRemaining = (deletedAt: string) => {
        const deleted = new Date(deletedAt);
        const deleteDate = new Date(deleted.getTime() + 14 * 24 * 60 * 60 * 1000);
        const now = new Date();
        const diff = deleteDate.getTime() - now.getTime();
        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        return days > 0 ? `${days}d` : '0d';
    };

    const getTypeBadge = (type: string) => {
        const colors: Record<string, string> = {
            project: '#000000',
            course: '#333333',
            internship: '#555555',
            enquiry: '#777777'
        };
        return (
            <span 
                className={styles.typeBadge}
                style={{ backgroundColor: `${colors[type] || '#6b7280'}20`, color: colors[type] || '#6b7280' }}
            >
                {type}
            </span>
        );
    };

    const columns = [
        {
            key: 'type',
            label: 'Type',
            sortable: true,
            width: '90px',
            render: (item: any) => getTypeBadge(item.type)
        },
        {
            key: 'source',
            label: 'From',
            sortable: true,
            width: '130px',
            render: (item: any) => (
                <span className={styles.sourceCell}>{item.source}</span>
            )
        },
        {
            key: 'name',
            label: 'Name',
            sortable: true,
            render: (item: any) => (
                <span className={styles.nameCell}>
                    {item.name || item.title || item.item?.title || '-'}
                </span>
            )
        },
        {
            key: 'deletedAt',
            label: 'Deletes in',
            sortable: true,
            width: '90px',
            render: (item: any) => (
                <span className={styles.timerCell}>
                    {getDaysRemaining(item.deletedAt)}
                </span>
            )
        },
        {
            key: 'deletedAtDate',
            label: 'Deleted',
            sortable: true,
            width: '100px',
            render: (item: any) => (
                <span className={styles.dateCell}>
                    {new Date(item.deletedAt).toLocaleDateString()}
                </span>
            )
        }
    ];

    return (
        <div className={styles.page}>
            <div className={styles.header}>
                <div>
                    <h1 className={styles.title}>Trash</h1>
                    <p className={styles.subtitle}>Items are permanently deleted after 14 days</p>
                </div>
                <div className={styles.headerActions}>
                    <div className={styles.filterDropdown} ref={filterRef}>
                        <button
                            className={`${styles.filterBtn} ${filterSource !== 'all' ? styles.filterBtnActive : ''}`}
                            onClick={() => setFilterOpen(!filterOpen)}
                        >
                            <Filter size={14} />
                            <span>{FILTER_OPTIONS.find(o => o.value === filterSource)?.label || 'All Sources'}</span>
                            <ChevronDown size={14} />
                        </button>
                        {filterOpen && (
                            <div className={styles.filterMenu}>
                                {FILTER_OPTIONS.map(opt => (
                                    <button
                                        key={opt.value}
                                        className={`${styles.filterMenuItem} ${filterSource === opt.value ? styles.filterMenuItemActive : ''}`}
                                        onClick={() => {
                                            setFilterSource(opt.value);
                                            setPage(1);
                                            setFilterOpen(false);
                                        }}
                                    >
                                        {opt.label}
                                    </button>
                                ))}
                            </div>
                        )}
                    </div>
                </div>
            </div>

            {loading ? (
                <div className={styles.loading}>Loading...</div>
            ) : (
                <NotionTable
                    data={items as any}
                    columns={columns as any}
                    getRowId={(item: any) => item._id}
                    selectable={false}
                    showActions={true}
                    actionsConfig={{ view: true, edit: false, delete: true, restore: true }}
                    onView={(item: any) => setViewItem(item)}
                    onRestore={(item: any) => handleRestore(item)}
                    onDelete={(item: any) => setConfirmDelete(item)}
                    emptyMessage="Trash is empty"
                    searchPlaceholder="Search trash..."
                    pagination={{ page, totalPages, total, onPageChange: setPage }}
                />
            )}

            <ConfirmModal
                isOpen={!!confirmDelete}
                onClose={() => setConfirmDelete(null)}
                onConfirm={() => {
                    if (confirmDelete) handlePermanentDelete(confirmDelete);
                }}
                title="Delete permanently?"
                message="This action cannot be undone. The item will be permanently removed."
                confirmText="Delete"
                cancelText="Cancel"
            />

            <Drawer
                isOpen={!!viewItem}
                onClose={() => setViewItem(null)}
                title={viewItem?.name || viewItem?.title || 'Details'}
                maxWidth="500px"
            >
                {viewItem && (
                    <div className={styles.detailContent}>
                        <div className={styles.detailMeta}>
                            <span className={styles.detailCategory}>{viewItem.source}</span>
                            {viewItem.name || viewItem.title || viewItem.item?.title ? (
                                <span className={styles.detailItemTitle}>{viewItem.name || viewItem.title || viewItem.item?.title}</span>
                            ) : null}
                        </div>
                        {viewItem.source === 'Inventory' ? (
                            <>
                                {viewItem.projectId && (
                                    <div className={styles.detailItem}>
                                        <span className={styles.detailLabel}>Project ID</span>
                                        <p className={styles.detailValue}>{viewItem.projectId}</p>
                                    </div>
                                )}
                                {viewItem.courseId && (
                                    <div className={styles.detailItem}>
                                        <span className={styles.detailLabel}>Course ID</span>
                                        <p className={styles.detailValue}>{viewItem.courseId}</p>
                                    </div>
                                )}
                                {viewItem.description && (
                                    <div className={styles.detailSection}>
                                        <h3 className={styles.detailSectionTitle}>Description</h3>
                                        <p className={styles.detailMessage}>{viewItem.description}</p>
                                    </div>
                                )}
                                {viewItem.tags?.length > 0 && (
                                    <div className={styles.detailItem}>
                                        <span className={styles.detailLabel}>Tags</span>
                                        <p className={styles.detailValue}>{viewItem.tags.join(', ')}</p>
                                    </div>
                                )}
                                {viewItem.category && (
                                    <div className={styles.detailItem}>
                                        <span className={styles.detailLabel}>Category</span>
                                        <p className={styles.detailValue}>{viewItem.category?.name || viewItem.category}</p>
                                    </div>
                                )}
                                {viewItem.mode && (
                                    <div className={styles.detailItem}>
                                        <span className={styles.detailLabel}>Mode</span>
                                        <p className={styles.detailValue}>{viewItem.mode}</p>
                                    </div>
                                )}
                                {viewItem.price && (
                                    <div className={styles.detailItem}>
                                        <span className={styles.detailLabel}>Price</span>
                                        <p className={styles.detailValue}>{viewItem.price}</p>
                                    </div>
                                )}
                                {viewItem.youtubeUrl && (
                                    <div className={styles.detailItem}>
                                        <span className={styles.detailLabel}>YouTube</span>
                                        <p className={styles.detailValue}>{viewItem.youtubeUrl}</p>
                                    </div>
                                )}
                                {viewItem.downloadAbstract && (
                                    <div className={styles.detailItem}>
                                        <span className={styles.detailLabel}>Download Abstract</span>
                                        <p className={styles.detailValue}>{viewItem.downloadAbstract}</p>
                                    </div>
                                )}
                            </>
                        ) : (
                            <>
                                <div className={styles.detailItem}>
                                    <span className={styles.detailLabel}>Email</span>
                                    <p className={styles.detailValue}>{viewItem.email}</p>
                                </div>
                                <div className={styles.detailItem}>
                                    <span className={styles.detailLabel}>Phone</span>
                                    <p className={styles.detailValue}>{viewItem.phone}</p>
                                </div>
                                {viewItem.address && (
                                    <div className={styles.detailItem}>
                                        <span className={styles.detailLabel}>Address</span>
                                        <p className={styles.detailValue}>{viewItem.address}</p>
                                    </div>
                                )}
                                {viewItem.degree && (
                                    <div className={styles.detailItem}>
                                        <span className={styles.detailLabel}>Degree</span>
                                        <p className={styles.detailValue}>{viewItem.degree}</p>
                                    </div>
                                )}
                                {viewItem.college && (
                                    <div className={styles.detailItem}>
                                        <span className={styles.detailLabel}>College</span>
                                        <p className={styles.detailValue}>{viewItem.college}</p>
                                    </div>
                                )}
                                {viewItem.source === 'Internship Application' && (
                                    <>
                                        {viewItem.gender && (
                                            <div className={styles.detailItem}>
                                                <span className={styles.detailLabel}>Gender</span>
                                                <p className={styles.detailValue}>{viewItem.gender}</p>
                                            </div>
                                        )}
                                        {viewItem.yearOfStudy && (
                                            <div className={styles.detailItem}>
                                                <span className={styles.detailLabel}>Year of Study</span>
                                                <p className={styles.detailValue}>{viewItem.yearOfStudy}</p>
                                            </div>
                                        )}
                                        {viewItem.collegeLocation && (
                                            <div className={styles.detailItem}>
                                                <span className={styles.detailLabel}>College Location</span>
                                                <p className={styles.detailValue}>{viewItem.collegeLocation}</p>
                                            </div>
                                        )}
                                        {viewItem.domain && (
                                            <div className={styles.detailItem}>
                                                <span className={styles.detailLabel}>Domain</span>
                                                <p className={styles.detailValue}>{viewItem.domain}</p>
                                            </div>
                                        )}
                                        {viewItem.duration && (
                                            <div className={styles.detailItem}>
                                                <span className={styles.detailLabel}>Duration</span>
                                                <p className={styles.detailValue}>{viewItem.duration}</p>
                                            </div>
                                        )}
                                        {viewItem.mode && (
                                            <div className={styles.detailItem}>
                                                <span className={styles.detailLabel}>Mode</span>
                                                <p className={styles.detailValue}>{viewItem.mode}</p>
                                            </div>
                                        )}
                                    </>
                                )}
                                {viewItem.message && (
                                    <div className={styles.detailSection}>
                                        <h3 className={styles.detailSectionTitle}>Message</h3>
                                        <p className={styles.detailMessage}>{viewItem.message}</p>
                                    </div>
                                )}
                            </>
                        )}
                        <div className={styles.detailItem}>
                            <span className={styles.detailLabel}>Deleted</span>
                            <p className={styles.detailValue}>{new Date(viewItem.deletedAt).toLocaleString()}</p>
                        </div>
                        {viewItem.createdAt && (
                            <div className={styles.detailItem}>
                                <span className={styles.detailLabel}>Created</span>
                                <p className={styles.detailValue}>{new Date(viewItem.createdAt).toLocaleString()}</p>
                            </div>
                        )}
                    </div>
                )}
            </Drawer>
        </div>
    );
};
