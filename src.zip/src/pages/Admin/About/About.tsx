import { useState, useEffect, useRef } from 'react';
import { Plus, Edit, Trash2, X, ChevronDown, Upload } from 'lucide-react';
import { aboutSettingsApi, uploadApi, AboutSettings } from '../../../api';
import { Button } from '../../../components/Button';
import { Drawer } from '../../../components/Drawer';
import { Input } from '../../../components/Input';
import { useToast } from '../../../components/Toast';
import { ConfirmModal } from '../../../components/Modal';
import styles from './About.module.css';

type SectionKey = 'team' | 'gallery';

const SectionToggle: React.FC<{ label: string; isOpen: boolean; onToggle: () => void }> = ({ label, isOpen, onToggle }) => (
    <button className={styles.sectionToggle} onClick={onToggle} type="button">
        <span>{label}</span>
        <ChevronDown size={18} className={`${styles.sectionChevron} ${isOpen ? styles.sectionChevronOpen : ''}`} />
    </button>
);

const saveSettings = async (settings: AboutSettings, update: Partial<AboutSettings>, addToast: ReturnType<typeof useToast>['addToast']) => {
    try {
        const updated = await aboutSettingsApi.update({ ...settings, ...update });
        return updated;
    } catch (error) {
        addToast('Failed to save', 'error');
        return null;
    }
};

export const About = () => {
    const { addToast } = useToast();

    const [openSections, setOpenSections] = useState<Record<SectionKey, boolean>>({
        team: false, gallery: false,
    });
    const toggleSection = (key: SectionKey) => setOpenSections(prev => ({ ...prev, [key]: !prev[key] }));

    const [settings, setSettings] = useState<AboutSettings | null>(null);
    const [loading, setLoading] = useState(true);

    const fetchSettings = async () => {
        setLoading(true);
        try {
            const data = await aboutSettingsApi.get();
            setSettings(data);
        } catch (error) {
            console.error('Failed to fetch about settings:', error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => { fetchSettings(); }, []);

    // ── Team Members ──
    const [localTeam, setLocalTeam] = useState<AboutSettings['team']>([]);
    useEffect(() => {
        if (settings) setLocalTeam(settings.team);
    }, [settings]);

    const [teamFormOpen, setTeamFormOpen] = useState(false);
    const [editingTeamIdx, setEditingTeamIdx] = useState<number | null>(null);
    const [deleteTeamIdx, setDeleteTeamIdx] = useState<number | null>(null);
    const [teamForm, setTeamForm] = useState({ name: '', role: '', image: '', description: '' });
    const [teamUploading, setTeamUploading] = useState(false);
    const teamFileRef = useRef<HTMLInputElement>(null);

    const handleAddTeam = () => {
        setEditingTeamIdx(null);
        setTeamForm({ name: '', role: '', image: '', description: '' });
        setTeamFormOpen(true);
    };

    const handleEditTeam = (idx: number) => {
        setEditingTeamIdx(idx);
        setTeamForm(localTeam[idx]);
        setTeamFormOpen(true);
    };

    const handleTeamFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;
        setTeamUploading(true);
        try {
            if (editingTeamIdx !== null) {
                const oldUrl = localTeam[editingTeamIdx]?.image;
                if (oldUrl) uploadApi.delete(oldUrl).catch(() => {});
            }
            const result = await uploadApi.upload(file);
            setTeamForm(prev => ({ ...prev, image: result.url }));
            addToast('Image uploaded', 'success');
        } catch (error) {
            addToast('Upload failed', 'error');
        } finally {
            setTeamUploading(false);
            if (teamFileRef.current) teamFileRef.current.value = '';
        }
    };

    const handleSaveTeam = async () => {
        if (!teamForm.name.trim()) { addToast('Name is required', 'error'); return; }
        if (!settings) return;
        const newTeam = editingTeamIdx !== null
            ? localTeam.map((m, i) => i === editingTeamIdx ? teamForm : m)
            : [...localTeam, teamForm];
        setLocalTeam(newTeam);
        setTeamFormOpen(false);
        const updated = await saveSettings(settings, { team: newTeam }, addToast);
        if (updated) setSettings(updated);
    };

    const handleDeleteTeam = async () => {
        if (deleteTeamIdx === null || !settings) return;
        const oldUrl = localTeam[deleteTeamIdx]?.image;
        const newTeam = localTeam.filter((_, i) => i !== deleteTeamIdx);
        setLocalTeam(newTeam);
        setDeleteTeamIdx(null);
        if (oldUrl) uploadApi.delete(oldUrl).catch(() => {});
        const updated = await saveSettings(settings, { team: newTeam }, addToast);
        if (updated) setSettings(updated);
    };

    // ── Gallery Images ──
    const [localGallery, setLocalGallery] = useState<AboutSettings['gallery']>([]);
    useEffect(() => {
        if (settings) setLocalGallery(settings.gallery);
    }, [settings]);

    const [galleryFormOpen, setGalleryFormOpen] = useState(false);
    const [editingGalleryIdx, setEditingGalleryIdx] = useState<number | null>(null);
    const [deleteGalleryIdx, setDeleteGalleryIdx] = useState<number | null>(null);
    const [galleryForm, setGalleryForm] = useState({ alt: '', image: '' });
    const [galleryUploading, setGalleryUploading] = useState(false);
    const galleryFileRef = useRef<HTMLInputElement>(null);

    const handleAddGallery = () => {
        setEditingGalleryIdx(null);
        setGalleryForm({ alt: '', image: '' });
        setGalleryFormOpen(true);
    };

    const handleEditGallery = (idx: number) => {
        setEditingGalleryIdx(idx);
        setGalleryForm(localGallery[idx]);
        setGalleryFormOpen(true);
    };

    const handleGalleryFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;
        setGalleryUploading(true);
        try {
            if (editingGalleryIdx !== null) {
                const oldUrl = localGallery[editingGalleryIdx]?.image;
                if (oldUrl) uploadApi.delete(oldUrl).catch(() => {});
            }
            const result = await uploadApi.upload(file);
            setGalleryForm(prev => ({ ...prev, image: result.url }));
            addToast('Image uploaded', 'success');
        } catch (error) {
            addToast('Upload failed', 'error');
        } finally {
            setGalleryUploading(false);
            if (galleryFileRef.current) galleryFileRef.current.value = '';
        }
    };

    const handleSaveGallery = async () => {
        if (!galleryForm.alt.trim()) { addToast('Alt text is required', 'error'); return; }
        if (!settings) return;
        const newGallery = editingGalleryIdx !== null
            ? localGallery.map((g, i) => i === editingGalleryIdx ? galleryForm : g)
            : [...localGallery, galleryForm];
        setLocalGallery(newGallery);
        setGalleryFormOpen(false);
        const updated = await saveSettings(settings, { gallery: newGallery }, addToast);
        if (updated) setSettings(updated);
    };

    const handleDeleteGallery = async () => {
        if (deleteGalleryIdx === null || !settings) return;
        const oldUrl = localGallery[deleteGalleryIdx]?.image;
        const newGallery = localGallery.filter((_, i) => i !== deleteGalleryIdx);
        setLocalGallery(newGallery);
        setDeleteGalleryIdx(null);
        if (oldUrl) uploadApi.delete(oldUrl).catch(() => {});
        const updated = await saveSettings(settings, { gallery: newGallery }, addToast);
        if (updated) setSettings(updated);
    };

    return (
        <div className={styles.page}>
            <div className={styles.header}>
                <h1 className={styles.title}>About Us Settings</h1>
            </div>

            {/* ───── Team Members ───── */}
            <div className={styles.section}>
                <SectionToggle label={`Team Members (${localTeam.length})`} isOpen={openSections.team} onToggle={() => toggleSection('team')} />
                {openSections.team && (
                    <div className={styles.sectionContent}>
                        {loading ? (
                            <div className={styles.loading}>Loading...</div>
                        ) : (
                            <>
                                <div className={styles.sectionActions}>
                                    <Button onClick={handleAddTeam}><Plus size={16} /> Add Member</Button>
                                </div>
                                {localTeam.length === 0 ? (
                                    <div className={styles.empty}>No team members yet</div>
                                ) : (
                                    <div className={styles.list}>
                                        {localTeam.map((m, i) => (
                                            <div key={i} className={styles.row}>
                                                <div className={styles.rowLeft}>
                                                    {m.image ? (
                                                        <img src={m.image} alt={m.name} className={styles.thumb} />
                                                    ) : (
                                                        <div className={styles.thumbPlaceholder}>{m.name.charAt(0)}</div>
                                                    )}
                                                    <div className={styles.rowContent}>
                                                        <span className={styles.rowTitle}>{m.name}</span>
                                                        <span className={styles.rowMeta}>{m.role}</span>
                                                    </div>
                                                </div>
                                                <div className={styles.rowRight}>
                                                    <button className={styles.rowBtn} onClick={() => handleEditTeam(i)} aria-label="Edit"><Edit size={14} /></button>
                                                    <button className={styles.rowBtn} onClick={() => setDeleteTeamIdx(i)} aria-label="Delete"><Trash2 size={14} /></button>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </>
                        )}
                    </div>
                )}
            </div>

            {/* ───── Gallery Images ───── */}
            <div className={styles.section}>
                <SectionToggle label={`Gallery Images (${localGallery.length})`} isOpen={openSections.gallery} onToggle={() => toggleSection('gallery')} />
                {openSections.gallery && (
                    <div className={styles.sectionContent}>
                        {loading ? (
                            <div className={styles.loading}>Loading...</div>
                        ) : (
                            <>
                                <div className={styles.sectionActions}>
                                    <Button onClick={handleAddGallery}><Plus size={16} /> Add Image</Button>
                                </div>
                                {localGallery.length === 0 ? (
                                    <div className={styles.empty}>No gallery images yet</div>
                                ) : (
                                    <div className={styles.list}>
                                        {localGallery.map((g, i) => (
                                            <div key={i} className={styles.row}>
                                                <div className={styles.rowLeft}>
                                                    {g.image ? (
                                                        <img src={g.image} alt={g.alt} className={styles.thumb} />
                                                    ) : (
                                                        <div className={styles.thumbPlaceholder}>📷</div>
                                                    )}
                                                    <div className={styles.rowContent}>
                                                        <span className={styles.rowTitle}>{g.alt}</span>
                                                    </div>
                                                </div>
                                                <div className={styles.rowRight}>
                                                    <button className={styles.rowBtn} onClick={() => handleEditGallery(i)} aria-label="Edit"><Edit size={14} /></button>
                                                    <button className={styles.rowBtn} onClick={() => setDeleteGalleryIdx(i)} aria-label="Delete"><Trash2 size={14} /></button>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </>
                        )}
                    </div>
                )}
            </div>

            {/* ── Team Form Drawer ── */}
            <Drawer isOpen={teamFormOpen} onClose={() => setTeamFormOpen(false)} title={editingTeamIdx !== null ? 'Edit Team Member' : 'Add Team Member'} maxWidth="500px"
                footer={<><Button variant="secondary" onClick={() => setTeamFormOpen(false)}>Cancel</Button><Button onClick={handleSaveTeam}>{editingTeamIdx !== null ? 'Save Changes' : 'Add'}</Button></>}
            >
                <div className={styles.form}>
                    <div className={styles.field}><label className={styles.label}>Name *</label><Input value={teamForm.name} onChange={e => setTeamForm(prev => ({ ...prev, name: e.target.value }))} placeholder="Member name" /></div>
                    <div className={styles.field}><label className={styles.label}>Role</label><Input value={teamForm.role} onChange={e => setTeamForm(prev => ({ ...prev, role: e.target.value }))} placeholder="e.g. Founder & CEO" /></div>
                    <div className={styles.field}>
                        <label className={styles.label}>Profile Picture</label>
                        <div className={styles.uploadRow}>
                            <input ref={teamFileRef} type="file" accept="image/*" onChange={handleTeamFileUpload} hidden />
                            <Button variant="secondary" onClick={() => teamFileRef.current?.click()} disabled={teamUploading}>
                                <Upload size={14} /> {teamUploading ? 'Uploading...' : 'Choose Image'}
                            </Button>
                            {teamForm.image && (
                                <><img src={teamForm.image} alt="Preview" className={styles.uploadPreview} /><button className={styles.removePicBtn} onClick={() => setTeamForm(prev => ({ ...prev, image: '' }))} aria-label="Remove image"><X size={14} /></button></>
                            )}
                        </div>
                    </div>
                    <div className={styles.field}>
                        <label className={styles.label}>Description</label>
                        <textarea className={styles.textarea} value={teamForm.description} onChange={e => setTeamForm(prev => ({ ...prev, description: e.target.value }))} placeholder="Short bio..." rows={3} />
                    </div>
                </div>
            </Drawer>

            {/* ── Gallery Form Drawer ── */}
            <Drawer isOpen={galleryFormOpen} onClose={() => setGalleryFormOpen(false)} title={editingGalleryIdx !== null ? 'Edit Gallery Image' : 'Add Gallery Image'} maxWidth="500px"
                footer={<><Button variant="secondary" onClick={() => setGalleryFormOpen(false)}>Cancel</Button><Button onClick={handleSaveGallery}>{editingGalleryIdx !== null ? 'Save Changes' : 'Add'}</Button></>}
            >
                <div className={styles.form}>
                    <div className={styles.field}><label className={styles.label}>Alt Text *</label><Input value={galleryForm.alt} onChange={e => setGalleryForm(prev => ({ ...prev, alt: e.target.value }))} placeholder="Describe the image" /></div>
                    <div className={styles.field}>
                        <label className={styles.label}>Image</label>
                        <div className={styles.uploadRow}>
                            <input ref={galleryFileRef} type="file" accept="image/*" onChange={handleGalleryFileUpload} hidden />
                            <Button variant="secondary" onClick={() => galleryFileRef.current?.click()} disabled={galleryUploading}>
                                <Upload size={14} /> {galleryUploading ? 'Uploading...' : 'Choose Image'}
                            </Button>
                            {galleryForm.image && (
                                <><img src={galleryForm.image} alt="Preview" className={styles.uploadPreview} /><button className={styles.removePicBtn} onClick={() => setGalleryForm(prev => ({ ...prev, image: '' }))} aria-label="Remove image"><X size={14} /></button></>
                            )}
                        </div>
                    </div>
                </div>
            </Drawer>

            {/* ── Confirm Modals ── */}
            <ConfirmModal isOpen={deleteTeamIdx !== null} onClose={() => setDeleteTeamIdx(null)} onConfirm={handleDeleteTeam} title="Delete team member?" message="This member will be permanently deleted." confirmText="Delete" cancelText="Cancel" />
            <ConfirmModal isOpen={deleteGalleryIdx !== null} onClose={() => setDeleteGalleryIdx(null)} onConfirm={handleDeleteGallery} title="Delete gallery image?" message="This image will be permanently deleted." confirmText="Delete" cancelText="Cancel" />
        </div>
    );
};
