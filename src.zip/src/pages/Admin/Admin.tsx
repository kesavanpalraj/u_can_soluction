import { useState, useEffect } from 'react';
import { Link, useLocation, Outlet, useNavigate } from 'react-router-dom';
import { 
    LayoutDashboard, 
    FolderOpen, 
    BookOpen, 
    Briefcase,
    Trash2, 
    Archive as ArchiveIcon,
    Home,
    Info,
    ArrowLeft,
    Menu,
    X,
    Settings as SettingsIcon,
    Check,
} from 'lucide-react';
import styles from './Admin.module.css';
import logo from '../../assets/logo.jpg';
import { Drawer } from '../../components/Drawer';
import { useToast } from '../../components/Toast';

const sidebarLinks = [
    { path: '/admin', label: 'Dashboard', icon: LayoutDashboard, exact: true },
    { path: '/admin/homepage', label: 'Homepage', icon: Home },
    { path: '/admin/projects', label: 'Projects', icon: FolderOpen },
    { path: '/admin/courses', label: 'Courses', icon: BookOpen },
    { path: '/admin/internships', label: 'Internships', icon: Briefcase },
    { path: '/admin/about', label: 'About', icon: Info },
];

export const Admin: React.FC = () => {
    const [checkingAuth, setCheckingAuth] = useState(true);
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
    const [settingsOpen, setSettingsOpen] = useState(false);
    const [notificationsEnabled, setNotificationsEnabled] = useState(true);
    const [cpCurrent, setCpCurrent] = useState('');
    const [cpNew, setCpNew] = useState('');
    const [cpConfirm, setCpConfirm] = useState('');
    const [cpLoading, setCpLoading] = useState(false);
    const location = useLocation();
    const navigate = useNavigate();
    const { addToast } = useToast();

    useEffect(() => {
        const token = localStorage.getItem('admin_token');
        if (!token) {
            navigate('/admin/login', { replace: true });
            return;
        }
        fetch('/api/auth/me', {
            headers: { Authorization: `Bearer ${token}` },
        })
            .then((r) => {
                if (!r.ok) throw new Error('Invalid token');
                return r.json();
            })
            .then((data) => {
                if (data.notificationsEnabled !== undefined) {
                    setNotificationsEnabled(data.notificationsEnabled);
                }
                setCheckingAuth(false);
            })
            .catch(() => {
                localStorage.removeItem('admin_token');
                navigate('/admin/login', { replace: true });
            });
    }, [navigate]);

    useEffect(() => {
        setIsMobileMenuOpen(false);
    }, [location.pathname]);

    useEffect(() => {
        if (isMobileMenuOpen) {
            document.body.style.overflow = 'hidden';
        } else {
            document.body.style.overflow = '';
        }
        return () => {
            document.body.style.overflow = '';
        };
    }, [isMobileMenuOpen]);

    const handleToggleNotifications = async (enabled: boolean) => {
        const token = localStorage.getItem('admin_token');
        if (!token) return;
        try {
            const res = await fetch('/api/auth/notifications', {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${token}`,
                },
                body: JSON.stringify({ enabled }),
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.message);
            setNotificationsEnabled(data.notificationsEnabled);
            addToast(data.notificationsEnabled ? 'Notifications enabled' : 'Notifications disabled', 'success');
        } catch (err: any) {
            addToast(err.message, 'error');
        }
    };

    const handleChangePassword = async () => {
        if (cpNew.length < 6) {
            addToast('Password must be at least 6 characters', 'error');
            return;
        }
        if (cpNew !== cpConfirm) {
            addToast('Passwords do not match', 'error');
            return;
        }
        setCpLoading(true);
        try {
            const token = localStorage.getItem('admin_token');
            const res = await fetch('/api/auth/change-password', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${token}`,
                },
                body: JSON.stringify({ currentPassword: cpCurrent, newPassword: cpNew }),
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.message);
            addToast('Password changed successfully', 'success');
            setSettingsOpen(false);
            setCpCurrent('');
            setCpNew('');
            setCpConfirm('');
        } catch (err: any) {
            addToast(err.message, 'error');
        } finally {
            setCpLoading(false);
        }
    };

    const isActive = (path: string, exact?: boolean) => {
        if (exact) {
            return location.pathname === path;
        }
        return location.pathname.startsWith(path);
    };

    const handleLogout = () => {
        localStorage.removeItem('admin_token');
        window.location.href = '/';
    };

    if (checkingAuth) return null;

    return (
        <div className={styles.adminLayout}>
            <aside className={`${styles.sidebar} ${isMobileMenuOpen ? styles.sidebarOpen : ''}`}>
                <div className={styles.sidebarHeader}>
                    <Link to="/admin" className={styles.logo}>
                        <img src={logo} alt="U Can Solution" className={styles.logoImg} />
                        <span className={styles.logoText}>Admin</span>
                    </Link>
                </div>

                <nav className={styles.sidebarNav}>
                    {sidebarLinks.map(({ path, label, icon: Icon, exact }) => (
                        <Link
                            key={path}
                            to={path}
                            className={`${styles.navLink} ${isActive(path, exact) ? styles.navLinkActive : ''}`}
                        >
                            <Icon size={18} />
                            <span>{label}</span>
                        </Link>
                    ))}
                </nav>

                <div className={styles.sidebarFooter}>
                    <Link
                        to="/admin/archive"
                        className={`${styles.navLink} ${isActive('/admin/archive') ? styles.navLinkActive : ''}`}
                    >
                        <ArchiveIcon size={18} />
                        <span>Archive</span>
                    </Link>
                    <Link
                        to="/admin/trash"
                        className={`${styles.navLink} ${isActive('/admin/trash') ? styles.navLinkActive : ''}`}
                    >
                        <Trash2 size={18} />
                        <span>Trash</span>
                    </Link>
                    <button onClick={() => setSettingsOpen(true)} className={styles.navLink}>
                        <SettingsIcon size={18} />
                        <span>Settings</span>
                    </button>
                    <button onClick={handleLogout} className={styles.logoutBtn}>
                        <ArrowLeft size={18} />
                        <span>Logout and Back to website</span>
                    </button>
                </div>
            </aside>

            <div 
                className={`${styles.mobileOverlay} ${isMobileMenuOpen ? styles.mobileOverlayOpen : ''}`}
                onClick={() => setIsMobileMenuOpen(false)}
            />

            <div className={styles.mainContent}>
                <header className={styles.mobileHeader}>
                    <Link to="/admin" className={styles.logo}>
                        <img src={logo} alt="U Can Solution" className={styles.logoImg} />
                        <span className={styles.logoText}>Admin</span>
                    </Link>
                    <button 
                        className={styles.menuToggle}
                        onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                        aria-label={isMobileMenuOpen ? 'Close menu' : 'Open menu'}
                    >
                        {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
                    </button>
                </header>

                <main className={styles.pageContent}>
                    <Outlet />
                </main>
            </div>

            <Drawer
                isOpen={settingsOpen}
                onClose={() => { setSettingsOpen(false); setCpCurrent(''); setCpNew(''); setCpConfirm(''); }}
                title="Settings"
                maxWidth="420px"
            >
                <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-6)' }}>
                    <form id="changePasswordForm" onSubmit={(e) => { e.preventDefault(); handleChangePassword(); }} style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-4)' }}>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                            <label style={{ fontSize: '13px', fontWeight: 500, color: 'var(--muted-foreground)' }}>Current password</label>
                            <input
                                className={styles.drawerInput}
                                type="password"
                                value={cpCurrent}
                                onChange={(e) => setCpCurrent(e.target.value)}
                                required
                                autoFocus
                            />
                        </div>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                            <label style={{ fontSize: '13px', fontWeight: 500, color: 'var(--muted-foreground)' }}>New password</label>
                            <input
                                className={styles.drawerInput}
                                type="password"
                                value={cpNew}
                                onChange={(e) => setCpNew(e.target.value)}
                                required
                                minLength={6}
                            />
                        </div>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                            <label style={{ fontSize: '13px', fontWeight: 500, color: 'var(--muted-foreground)' }}>Confirm new password</label>
                            <input
                                className={styles.drawerInput}
                                type="password"
                                value={cpConfirm}
                                onChange={(e) => setCpConfirm(e.target.value)}
                                required
                                minLength={6}
                            />
                        </div>
                        <button
                            type="submit"
                            className={styles.drawerBtn}
                            disabled={cpLoading}
                        >
                            {cpLoading ? 'Saving...' : <><Check size={16} /> Save</>}
                        </button>
                    </form>

                    <div style={{ borderTop: '1px solid var(--border)', paddingTop: 'var(--space-4)' }}>
                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                            <div>
                                <div style={{ fontSize: '14px', fontWeight: 500, color: 'var(--foreground)' }}>Email Notifications</div>
                                <div style={{ fontSize: '12px', color: 'var(--muted-foreground)', marginTop: '2px' }}>Receive email when a form is submitted</div>
                            </div>
                            <label className={styles.toggle}>
                                <input
                                    type="checkbox"
                                    checked={notificationsEnabled}
                                    onChange={(e) => handleToggleNotifications(e.target.checked)}
                                />
                                <span className={styles.toggleSlider} />
                            </label>
                        </div>
                    </div>
                </div>
            </Drawer>
        </div>
    );
};
