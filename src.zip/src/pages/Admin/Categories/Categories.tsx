import { useState, useEffect } from 'react';
import { Plus, Trash2, RotateCcw } from 'lucide-react';
import { NotionTable } from '../components';
import { Badge } from '../../../components/Badge';
import { Button } from '../../../components/Button';
import { useToast } from '../../../components/Toast';
import styles from './Categories.module.css';

interface Category {
    _id: string;
    name: string;
    slug: string;
    type: 'project' | 'course' | 'internship';
    order: number;
    deletedAt: string | null;
    createdAt: string;
}

export const Categories: React.FC = () => {
    const [categories, setCategories] = useState<Category[]>([]);
    const [loading, setLoading] = useState(true);
    const [page, setPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const [total, setTotal] = useState(0);
    const [selectedItems, setSelectedItems] = useState<Set<string>>(new Set());
    const [filterType, setFilterType] = useState<string>('all');
    const { addToast } = useToast();

    useEffect(() => {
        fetchCategories();
    }, [page, filterType]);

    const fetchCategories = async () => {
        setLoading(true);
        try {
            const typeParam = filterType !== 'all' ? `&type=${filterType}` : '';
            const res = await fetch(`/api/categories?page=${page}&limit=20${typeParam}`);
            if (res.ok) {
                const data = await res.json();
                setCategories(data);
                setTotal(data.length || 0);
                setTotalPages(1);
            }
        } catch (error) {
            console.error('Failed to fetch categories:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleDelete = async (id: string) => {
        if (!confirm('Move this category to trash?')) return;
        
        try {
            const res = await fetch(`/api/categories/${id}`, { method: 'DELETE' });
            if (res.ok) {
                addToast('Category moved to trash', 'success');
                fetchCategories();
            }
        } catch (error) {
            console.error('Failed to delete category:', error);
            addToast('Failed to delete category', 'error');
        }
    };

    const handleBulkDelete = async () => {
        if (selectedItems.size === 0) return;
        
        for (const id of selectedItems) {
            await fetch(`/api/categories/${id}`, { method: 'DELETE' });
        }
        
        addToast(`Moved ${selectedItems.size} categories to trash`, 'success');
        setSelectedItems(new Set());
        fetchCategories();
    };

    const getTypeBadge = (type: string) => {
        const colors: Record<string, string> = {
            project: '#000000',
            course: '#333333',
            internship: '#555555'
        };
        return (
            <span 
                className={styles.typeBadge}
                style={{ backgroundColor: `${colors[type]}20`, color: colors[type] }}
            >
                {type}
            </span>
        );
    };

    const columns = [
        {
            key: 'name',
            label: 'Name',
            sortable: true,
            render: (item: Category) => <span className={styles.nameCell}>{item.name}</span>
        },
        {
            key: 'slug',
            label: 'Slug',
            sortable: true,
            width: '200px'
        },
        {
            key: 'type',
            label: 'Type',
            sortable: true,
            filterable: true,
            width: '120px',
            render: (item: Category) => getTypeBadge(item.type)
        },
        {
            key: 'order',
            label: 'Order',
            sortable: true,
            width: '80px'
        },
        {
            key: 'createdAt',
            label: 'Created',
            sortable: true,
            width: '120px',
            render: (item: Category) => (
                <span className={styles.dateCell}>
                    {new Date(item.createdAt).toLocaleDateString()}
                </span>
            )
        }
    ];

    return (
        <div className={styles.page}>
            <div className={styles.header}>
                <div>
                    <h1 className={styles.title}>Categories</h1>
                    <p className={styles.subtitle}>{total} total categories</p>
                </div>
                <div className={styles.headerActions}>
                    <select 
                        value={filterType}
                        onChange={(e) => setFilterType(e.target.value)}
                        className={styles.filterSelect}
                    >
                        <option value="all">All Types</option>
                        <option value="project">Projects</option>
                        <option value="course">Courses</option>

                    </select>
                    <Button disabled>
                        <Plus size={16} />
                        Add Category
                    </Button>
                </div>
            </div>

            {loading ? (
                <div className={styles.loading}>Loading...</div>
            ) : (
                <>
                    <NotionTable
                        data={categories}
                        columns={columns}
                        getRowId={(item) => item._id}
                        onSelect={(ids) => setSelectedItems(new Set(ids))}
                        onDelete={(item) => handleDelete(item._id)}
                        showActions={true}
                        actionsConfig={{ view: false, edit: false, delete: true, restore: false }}
                        emptyMessage="No categories yet"
                        pagination={{ page, totalPages, total, onPageChange: setPage }}
                    />

                    {selectedItems.size > 0 && (
                        <div className={styles.bulkActions}>
                            <span className={styles.bulkInfo}>
                                {selectedItems.size} selected
                            </span>
                            <button onClick={handleBulkDelete} className={`${styles.bulkBtn} ${styles.bulkBtnDanger}`}>
                                <Trash2 size={16} />
                                Trash Selected
                            </button>
                        </div>
                    )}
                </>
            )}
        </div>
    );
};
