import { useState, useEffect, useCallback, useMemo } from 'react';
import { Icon } from '@iconify/react';
import { X, Search, Trash2, Plus, ChevronLeft, ChevronRight, ArrowRight, ChevronDown, Filter, ArrowUpDown } from 'lucide-react';
import { Button } from '../../../components/Button';
import { Drawer } from '../../../components/Drawer';
import { useToast } from '../../../components/Toast';
import { ConfirmModal } from '../../../components/Modal';
import { CourseForm } from './CourseForm';
import styles from './Courses.module.css';

interface Course {
    _id: string;
    courseId: string;
    title: string;
    description: string;
    mode: 'Online' | 'Offline' | 'Online-Offline';
    price: number;
    tags: string[];
    technologies: { icon: string; label: string }[];
    coverage: string[];
    status: 'draft' | 'published' | 'archived';
    createdAt: string;
    updatedAt: string;
}

const ITEMS_PER_PAGE = 100;

export const Courses: React.FC = () => {
    const [courses, setCourses] = useState<Course[]>([]);
    const [loading, setLoading] = useState(true);
    const [page, setPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const [total, setTotal] = useState(0);
    const [searchQuery, setSearchQuery] = useState('');
    const [debouncedSearch, setDebouncedSearch] = useState('');
    const [sortBy, setSortBy] = useState('createdAt_desc');
    const [openDropdown, setOpenDropdown] = useState<string | null>(null);
    const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
    const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
    const [isDetailOpen, setIsDetailOpen] = useState(false);
    const [isFormOpen, setIsFormOpen] = useState(false);
    const [editingCourse, setEditingCourse] = useState<Course | null>(null);
    const [deleteId, setDeleteId] = useState<string | null>(null);
    const [batchDeleteConfirm, setBatchDeleteConfirm] = useState(false);
    const { addToast } = useToast();

    useEffect(() => {
        fetchCourses();
    }, [page, debouncedSearch]);

    useEffect(() => {
        const timer = setTimeout(() => {
            setDebouncedSearch(searchQuery);
        }, 300);
        return () => clearTimeout(timer);
    }, [searchQuery]);

    useEffect(() => {
        setPage(1);
    }, [debouncedSearch]);

    useEffect(() => {
        const handleClickOutside = (e: MouseEvent) => {
            if (openDropdown && !(e.target as Element).closest(`.${styles.filterDropdown}`)) {
                setOpenDropdown(null);
            }
        };
        document.addEventListener('click', handleClickOutside);
        return () => document.removeEventListener('click', handleClickOutside);
    }, [openDropdown]);

    const fetchCourses = async () => {
        setLoading(true);
        try {
            let queryParams = `page=${page}&limit=${ITEMS_PER_PAGE}`;
            if (debouncedSearch) queryParams += `&search=${encodeURIComponent(debouncedSearch)}`;
            const res = await fetch(`/api/courses?${queryParams}`);
            if (res.ok) {
                const data = await res.json();
                setCourses(data.courses || []);
                setTotalPages(data.totalPages || 1);
                setTotal(data.total || 0);
            }
        } catch (error) {
            console.error('Failed to fetch courses:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleAdd = () => {
        setEditingCourse(null);
        setIsFormOpen(true);
    };

    const handleShowDetails = (course: Course) => {
        setSelectedCourse(course);
        setIsDetailOpen(true);
    };

    const handleEditFromDetail = () => {
        if (!selectedCourse) return;
        setIsDetailOpen(false);
        setEditingCourse(selectedCourse);
        setTimeout(() => setIsFormOpen(true), 300);
    };

    const handleDeleteFromDetail = () => {
        if (!selectedCourse) return;
        setDeleteId(selectedCourse._id);
    };

    const handleConfirmDelete = async () => {
        if (!deleteId) return;
        try {
            const res = await fetch(`/api/courses/${deleteId}`, { method: 'DELETE' });
            if (res.ok) {
                addToast('Course moved to trash', 'success');
                setIsDetailOpen(false);
                setSelectedCourse(null);
                fetchCourses();
            } else {
                addToast('Failed to delete course', 'error');
            }
        } catch (error) {
            addToast('Failed to delete course', 'error');
        } finally {
            setDeleteId(null);
        }
    };

    const handleBatchDelete = async () => {
        if (selectedIds.size === 0) return;
        setBatchDeleteConfirm(true);
    };

    const handleConfirmBatchDelete = async () => {
        let success = 0;
        for (const id of selectedIds) {
            try {
                const res = await fetch(`/api/courses/${id}`, { method: 'DELETE' });
                if (res.ok) success++;
            } catch { }
        }
        addToast(`${success} course(s) moved to trash`, success > 0 ? 'success' : 'error');
        setSelectedIds(new Set());
        setBatchDeleteConfirm(false);
        fetchCourses();
    };

    const handleSave = async (courseData: Partial<Course>) => {
        try {
            if (editingCourse?._id) {
                const res = await fetch(`/api/courses/${editingCourse._id}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(courseData)
                });
                if (res.ok) {
                    addToast('Course updated', 'success');
                    fetchCourses();
                } else {
                    const error = await res.json();
                    addToast(error.message || 'Failed to update course', 'error');
                }
            } else {
                const res = await fetch('/api/courses', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(courseData)
                });
                if (res.ok) {
                    addToast('Course added', 'success');
                    fetchCourses();
                } else {
                    const error = await res.json();
                    addToast(error.message || 'Failed to add course', 'error');
                }
            }
        } catch (error) {
            console.error('Failed to save course:', error);
            addToast('Failed to save course', 'error');
        }
    };

    const toggleSelect = (id: string) => {
        setSelectedIds(prev => {
            const next = new Set(prev);
            if (next.has(id)) next.delete(id);
            else next.add(id);
            return next;
        });
    };

    const toggleSelectAll = () => {
        if (selectedIds.size === courses.length) {
            setSelectedIds(new Set());
        } else {
            setSelectedIds(new Set(courses.map(p => p._id)));
        }
    };

    const formatPrice = (price: number): string => {
        return '\u20B9' + price.toLocaleString('en-IN');
    };

    const sortOptions = [
        { key: 'createdAt_desc', label: 'Newest' },
        { key: 'createdAt_asc', label: 'Oldest' },
        { key: 'courseId_asc', label: 'ID A-Z' },
        { key: 'courseId_desc', label: 'ID Z-A' },
        { key: 'title_asc', label: 'Name A-Z' },
        { key: 'title_desc', label: 'Name Z-A' }
    ];

    const sortedCourses = useMemo(() => {
        const sorted = [...courses];
        const [field, direction] = sortBy.split('_');
        sorted.sort((a, b) => {
            let aVal: any = a[field as keyof Course];
            let bVal: any = b[field as keyof Course];
            if (aVal === bVal) return 0;
            if (!aVal) return 1;
            if (!bVal) return -1;
            const cmp = String(aVal).localeCompare(String(bVal));
            return direction === 'asc' ? cmp : -cmp;
        });
        return sorted;
    }, [courses, sortBy]);

    const startItem = total === 0 ? 0 : (page - 1) * ITEMS_PER_PAGE + 1;
    const endItem = Math.min(page * ITEMS_PER_PAGE, total);

    return (
        <div className={styles.page}>
            <div className={styles.header}>
                <div className={styles.headerLeft}>
                    <h1 className={styles.title}>Courses</h1>
                    <p className={styles.subtitle}>{total} total courses</p>
                </div>
                <div className={styles.headerAction}>
                    <Button onClick={handleAdd}>
                        <Plus size={16} />
                        Add Course
                    </Button>
                </div>
            </div>

            <div className={styles.toolbar}>
                <div className={styles.searchContainer}>
                    <Search size={18} className={styles.searchIcon} />
                    <input
                        type="text"
                        placeholder="Search by title, ID, or tags..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className={styles.searchInput}
                    />
                    {searchQuery && (
                        <button
                            className={styles.searchClear}
                            onClick={() => setSearchQuery('')}
                            aria-label="Clear search"
                        >
                            <X size={16} />
                        </button>
                    )}
                </div>
                <div className={styles.filtersRow}>
                    <div className={styles.filterDropdown}>
                        <button
                            className={styles.filterBtn}
                            onClick={(e) => { e.stopPropagation(); setOpenDropdown(openDropdown === 'sort' ? null : 'sort'); }}
                        >
                            <ArrowUpDown size={14} className={styles.filterIcon} />
                            <span>{sortOptions.find(o => o.key === sortBy)?.label || 'Sort'}</span>
                            <ChevronDown size={14} />
                        </button>
                        {openDropdown === 'sort' && (
                            <div className={styles.filterMenu}>
                                {sortOptions.map(opt => (
                                    <button
                                        key={opt.key}
                                        className={`${styles.filterMenuItem} ${sortBy === opt.key ? styles.filterMenuItemActive : ''}`}
                                        onClick={() => { setSortBy(opt.key); setOpenDropdown(null); }}
                                    >
                                        {opt.label}
                                    </button>
                                ))}
                            </div>
                        )}
                    </div>
                </div>
            </div>

            {loading ? (
                <div className={styles.loading}>Loading...</div>
            ) : courses.length === 0 ? (
                <div className={styles.empty}>
                    {debouncedSearch ? `No courses found for "${debouncedSearch}".` : 'No courses yet.'}
                </div>
            ) : (
                <>
                    <div className={styles.resultsHeader}>
                        <label className={styles.selectAll}>
                            <input
                                type="checkbox"
                                checked={selectedIds.size === courses.length && courses.length > 0}
                                onChange={toggleSelectAll}
                                className={styles.checkbox}
                            />
                            <span className={styles.selectAllText}>
                                {selectedIds.size > 0 ? `${selectedIds.size} selected` : 'Select all'}
                            </span>
                        </label>
                        <span className={styles.resultsCount}>
                            Showing {startItem}-{endItem} of {total}
                        </span>
                    </div>

                    <div className={styles.list}>
                        {sortedCourses.map((course) => (
                            <div key={course._id} className={styles.row}>
                                <div className={styles.rowCheckbox}>
                                    <input
                                        type="checkbox"
                                        checked={selectedIds.has(course._id)}
                                        onChange={() => toggleSelect(course._id)}
                                        className={styles.checkbox}
                                    />
                                </div>
                                <div
                                    className={styles.rowContent}
                                    onClick={() => handleShowDetails(course)}
                                    role="button"
                                    tabIndex={0}
                                    onKeyDown={(e) => { if (e.key === 'Enter') handleShowDetails(course); }}
                                >
                                    <span className={styles.rowId}>{course.courseId}</span>
                                    <span className={styles.rowTitle}>{course.title}</span>
                                </div>
                                <button
                                    className={styles.rowArrow}
                                    onClick={() => handleShowDetails(course)}
                                    aria-label="Show details"
                                >
                                    <ChevronRight size={16} />
                                </button>
                            </div>
                        ))}
                    </div>

                    {totalPages > 1 && (
                        <div className={styles.pagination}>
                            <button
                                className={styles.paginationArrow}
                                onClick={() => { setPage(p => p - 1); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                                disabled={page === 1}
                                aria-label="Previous page"
                            >
                                <ChevronLeft size={18} />
                            </button>
                            <span className={styles.paginationInfo}>Page {page} of {totalPages}</span>
                            <button
                                className={styles.paginationArrow}
                                onClick={() => { setPage(p => p + 1); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                                disabled={page === totalPages}
                                aria-label="Next page"
                            >
                                <ChevronRight size={18} />
                            </button>
                        </div>
                    )}
                </>
            )}

            {selectedIds.size > 0 && (
                <div className={styles.deleteBar}>
                    <span className={styles.deleteBarCount}>{selectedIds.size} selected</span>
                    <button className={styles.deleteBarBtn} onClick={handleBatchDelete} aria-label="Delete selected">
                        <Trash2 size={18} />
                    </button>
                </div>
            )}

            <Drawer
                isOpen={isDetailOpen}
                onClose={() => setIsDetailOpen(false)}
                title="Course Details"
                footer={selectedCourse && (<>
                    <Button variant="outline" className={styles.deleteFooterBtn} onClick={handleDeleteFromDetail}>
                        <Trash2 size={14} /> Delete
                    </Button>
                    <Button onClick={handleEditFromDetail}>
                        Edit <ArrowRight size={14} />
                    </Button>
                </>)}
            >
                {selectedCourse && (
                    <div className={styles.detailContent}>
                        <div className={styles.detailId}>{selectedCourse.courseId}</div>
                        <div className={styles.modePill}>{selectedCourse.mode}</div>
                        <h2 className={styles.detailTitle}>{selectedCourse.title}</h2>
                        <p className={styles.detailDescription}>{selectedCourse.description}</p>
                        <div className={styles.detailIcons}>
                            {selectedCourse.technologies.map((tech, i) => (
                                <span key={i} className={styles.detailIconPill}>
                                    <Icon icon={tech.icon} width={16} height={16} />
                                    <span>{tech.label}</span>
                                </span>
                            ))}
                        </div>
                        <div className={styles.detailSection}>
                            <h3 className={styles.detailSectionTitle}>Course Coverage</h3>
                            <ul className={styles.detailList}>
                                {selectedCourse.coverage.map((item, i) => (
                                    <li key={i}>{item}</li>
                                ))}
                            </ul>
                        </div>
                        <div className={styles.detailPriceRow}>
                            <span className={styles.priceLabel}>Price:</span>
                            <span className={styles.detailPrice}>{formatPrice(selectedCourse.price)}</span>
                        </div>
                    </div>
                )}
            </Drawer>

            <CourseForm
                isOpen={isFormOpen}
                onClose={() => {
                    setIsFormOpen(false);
                    setEditingCourse(null);
                }}
                onSave={handleSave}
                course={editingCourse}
            />

            <ConfirmModal
                isOpen={!!deleteId}
                onClose={() => setDeleteId(null)}
                onConfirm={handleConfirmDelete}
                title="Move to trash?"
                message="This course will be moved to trash and auto-deleted after 14 days."
                confirmText="Delete"
                cancelText="Cancel"
            />

            <ConfirmModal
                isOpen={batchDeleteConfirm}
                onClose={() => setBatchDeleteConfirm(false)}
                onConfirm={handleConfirmBatchDelete}
                title={`Delete ${selectedIds.size} courses?`}
                message="These courses will be moved to trash and auto-deleted after 14 days."
                confirmText="Delete All"
                cancelText="Cancel"
            />
        </div>
    );
};
