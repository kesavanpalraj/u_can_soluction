import React, { useState, useEffect } from 'react';
import { Icon } from '@iconify/react';
import { Drawer } from '../../../components/Drawer/Drawer';
import { Input } from '../../../components/Input/Input';
import { Button } from '../../../components/Button/Button';
import { Select } from '../../../components/Select';
import { useToast } from '../../../components/Toast';
import styles from './CourseForm.module.css';

interface CourseFormProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (course: any) => void;
    course?: any;
}

export const CourseForm: React.FC<CourseFormProps> = ({
    isOpen,
    onClose,
    onSave,
    course
}) => {
    const [formData, setFormData] = useState<any>({
        courseId: '',
        title: '',
        description: '',
        mode: '',
        price: '',
        tags: [],
        technologies: [],
        coverage: [],
        status: 'draft'
    });
    const [tagInput, setTagInput] = useState('');
    const [techIcon, setTechIcon] = useState('');
    const [techLabel, setTechLabel] = useState('');
    const [coverageInput, setCoverageInput] = useState('');
    const [saving, setSaving] = useState(false);
    const { addToast } = useToast();

    useEffect(() => {
        if (course) {
            setFormData({
                _id: course._id,
                courseId: course.courseId,
                title: course.title,
                description: course.description,
                mode: course.mode || '',
                price: course.price || '',
                tags: course.tags || [],
                technologies: course.technologies || [],
                coverage: course.coverage || [],
                status: course.status,
                updatedAt: course.updatedAt
            });
        } else {
            setFormData({
                courseId: '',
                title: '',
                description: '',
                mode: '',
                price: '',
                tags: [],
                technologies: [],
                coverage: [],
                status: 'draft'
            });
        }
        setTagInput('');
        setTechIcon('');
        setTechLabel('');
        setCoverageInput('');
    }, [course, isOpen]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData((prev: any) => ({ ...prev, [name]: value }));
    };

    const addTag = () => {
        if (tagInput.trim() && !formData.tags?.includes(tagInput.trim())) {
            setFormData((prev: any) => ({
                ...prev,
                tags: [...(prev.tags || []), tagInput.trim()]
            }));
            setTagInput('');
        }
    };

    const removeTag = (tag: string) => {
        setFormData((prev: any) => ({
            ...prev,
            tags: prev.tags?.filter((t: string) => t !== tag) || []
        }));
    };

    const addTech = () => {
        if (techIcon.trim() && techLabel.trim()) {
            setFormData((prev: any) => ({
                ...prev,
                technologies: [...(prev.technologies || []), { icon: techIcon.trim(), label: techLabel.trim() }]
            }));
            setTechIcon('');
            setTechLabel('');
        }
    };

    const removeTech = (index: number) => {
        setFormData((prev: any) => ({
            ...prev,
            technologies: prev.technologies?.filter((_: any, i: number) => i !== index) || []
        }));
    };

    const addCoverage = () => {
        if (coverageInput.trim()) {
            setFormData((prev: any) => ({
                ...prev,
                coverage: [...(prev.coverage || []), coverageInput.trim()]
            }));
            setCoverageInput('');
        }
    };

    const removeCoverage = (index: number) => {
        setFormData((prev: any) => ({
            ...prev,
            coverage: prev.coverage?.filter((_: any, i: number) => i !== index) || []
        }));
    };

    const handleSubmit = async () => {
        if (!formData.courseId || !formData.title || !formData.mode || !formData.price) {
            addToast('Please fill in required fields', 'error');
            return;
        }

        setSaving(true);
        try {
            await onSave({ ...formData, price: Number(formData.price) });
            onClose();
        } finally {
            setSaving(false);
        }
    };

    const formatDate = (dateString?: string) => {
        if (!dateString) return 'Never';
        return new Date(dateString).toLocaleString();
    };

    const isEditing = !!course?._id;

    return (
        <Drawer
            isOpen={isOpen}
            onClose={onClose}
            title={isEditing ? 'Edit Course' : 'Add Course'}
            subtitle={isEditing && formData.updatedAt ? `Last edited: ${formatDate(formData.updatedAt)}` : undefined}
            footer={
                <>
                    <Button variant="secondary" onClick={onClose}>
                        Cancel
                    </Button>
                    <Button onClick={handleSubmit} disabled={saving}>
                        {isEditing ? 'Save Changes' : 'Add Course'}
                    </Button>
                </>
            }
        >
            <div className={styles.form}>
                <div className={styles.field}>
                    <label className={styles.label}>Course ID *</label>
                    <Input
                        name="courseId"
                        value={formData.courseId || ''}
                        onChange={handleChange}
                        placeholder="e.g., C0001"
                        disabled={isEditing}
                    />
                </div>

                <div className={styles.field}>
                    <label className={styles.label}>Title *</label>
                    <Input
                        name="title"
                        value={formData.title || ''}
                        onChange={handleChange}
                        placeholder="Course title"
                    />
                </div>

                <div className={styles.field}>
                    <label className={styles.label}>Mode *</label>
                    <Select
                        value={formData.mode}
                        options={[
                            { value: 'Online', label: 'Online' },
                            { value: 'Offline', label: 'Offline' },
                            { value: 'Online-Offline', label: 'Online-Offline' }
                        ]}
                        onChange={(val) => setFormData((prev: any) => ({ ...prev, mode: val }))}
                        placeholder="Select mode"
                    />
                </div>

                <div className={styles.field}>
                    <label className={styles.label}>Price *</label>
                    <Input
                        name="price"
                        type="number"
                        value={formData.price || ''}
                        onChange={handleChange}
                        placeholder="e.g., 4999"
                    />
                </div>

                <div className={styles.field}>
                    <label className={styles.label}>Description *</label>
                    <textarea
                        name="description"
                        value={formData.description || ''}
                        onChange={handleChange}
                        placeholder="Brief description"
                        className={styles.textarea}
                        rows={2}
                    />
                </div>

                <div className={styles.field}>
                    <label className={styles.label}>Tags</label>
                    <div className={styles.chipInput}>
                        <Input
                            value={tagInput}
                            onChange={(e: any) => setTagInput(e.target.value)}
                            placeholder="Add tag"
                            onKeyDown={(e: any) => e.key === 'Enter' && (e.preventDefault(), addTag())}
                        />
                        <Button variant="outline" onClick={addTag}>Add</Button>
                    </div>
                    <div className={styles.chips}>
                        {formData.tags?.map((tag: string) => (
                            <span key={tag} className={styles.chip}>
                                {tag}
                                <button onClick={() => removeTag(tag)}>&times;</button>
                            </span>
                        ))}
                    </div>
                </div>

                <div className={styles.field}>
                    <label className={styles.label}>
                        Technologies (icon IDs from{' '}
                        <a href="https://icon-sets.iconify.design/" target="_blank" rel="noopener noreferrer" className={styles.link}>
                            icon-sets.iconify.design
                        </a>
                        )
                    </label>
                    <div className={styles.techInputRow}>
                        <Input
                            value={techIcon}
                            onChange={(e: any) => setTechIcon(e.target.value)}
                            placeholder="Icon ID (e.g., logos:react)"
                        />
                        <Input
                            value={techLabel}
                            onChange={(e: any) => setTechLabel(e.target.value)}
                            placeholder="Display name (e.g., React)"
                        />
                        <Button variant="outline" onClick={addTech}>Add</Button>
                    </div>
                    <div className={styles.chips}>
                        {formData.technologies?.map((tech: any, i: number) => (
                            <span key={i} className={styles.techChip}>
                                <Icon icon={tech.icon} width={16} height={16} />
                                <span>{tech.label}</span>
                                <button onClick={() => removeTech(i)}>&times;</button>
                            </span>
                        ))}
                    </div>
                </div>

                <div className={styles.field}>
                    <label className={styles.label}>Course Coverage</label>
                    <div className={styles.chipInput}>
                        <Input
                            value={coverageInput}
                            onChange={(e: any) => setCoverageInput(e.target.value)}
                            placeholder="Add coverage item"
                            onKeyDown={(e: any) => e.key === 'Enter' && (e.preventDefault(), addCoverage())}
                        />
                        <Button variant="outline" onClick={addCoverage}>Add</Button>
                    </div>
                    <div className={styles.chips}>
                        {formData.coverage?.map((d: string, i: number) => (
                            <span key={i} className={styles.chip}>
                                {d}
                                <button onClick={() => removeCoverage(i)}>&times;</button>
                            </span>
                        ))}
                    </div>
                </div>
            </div>
        </Drawer>
    );
};
