import React, { useState, useEffect } from 'react';
import { Badge } from '../../components/Badge';
import { Button } from '../../components/Button';
import { Select } from '../../components/Select';
import { SuccessModal } from '../../components/SuccessModal';
import { internshipDomainApi, internshipDurationApi, InternshipDomain, InternshipDuration } from '../../api';
import styles from './Internships.module.css';

const YEAR_OPTIONS = [
  { value: 'Completed', label: 'Completed' },
  { value: '1st Year', label: '1st Year' },
  { value: '2nd Year', label: '2nd Year' },
  { value: '3rd Year', label: '3rd Year' },
  { value: '4th Year', label: '4th Year' },
];

export const Internships: React.FC = () => {
  const [domains, setDomains] = useState<InternshipDomain[]>([]);
  const [durations, setDurations] = useState<InternshipDuration[]>([]);
  const [formData, setFormData] = useState({
    name: '',
    gender: '',
    phone: '',
    email: '',
    address: '',
    degree: '',
    yearOfStudy: '',
    college: '',
    collegeLocation: '',
    domain: '',
    duration: '',
    mode: '',
    message: ''
  });
  const [submitting, setSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  useEffect(() => {
    internshipDomainApi.getAll().then(setDomains).catch(() => {});
    internshipDurationApi.getAll().then(setDurations).catch(() => {});
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.yearOfStudy || !formData.domain || !formData.duration) {
      alert('Please fill in all required fields');
      return;
    }
    setSubmitting(true);
    try {
      await fetch('/api/internships/applications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });
      setShowSuccess(true);
      setFormData({ name: '', gender: '', phone: '', email: '', address: '', degree: '', yearOfStudy: '', college: '', collegeLocation: '', domain: '', duration: '', mode: '', message: '' });
    } catch {
      alert('Something went wrong. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleCloseSuccess = () => {
    setShowSuccess(false);
  };

  return (
    <div className={styles.page}>
      <section className={styles.header}>
        <div className={styles.container}>
          <h1 className={styles.title}>Internships</h1>
          <p className={styles.description}>
            For all Undergraduate and Postgraduate students, U Can Solution offers flexible 15-day and 30-day paid internship programs in both online and offline modes, along with company certification and a free project with documentation.<br /> For MCA, M.Sc (CS), and M.Sc (IT) students, we provide a 6-month Project cum Internship program in both online and offline modes, with certification from our IT partner companies in Madurai and Coimbatore.
          </p>
        </div>
      </section>

      <div className={styles.badgeRow}>
        <Badge variant="outline">Internship Registration Form</Badge>
      </div>

      <section className={styles.section}>
        <div className={styles.container}>
          <div className={styles.formContent}>
            <form id="internshipForm" className={styles.form} onSubmit={handleSubmit}>
              <div className={styles.formGroup}>
                <label className={styles.formLabel}>Full Name *</label>
                <input type="text" name="name" className={styles.formInput} value={formData.name} onChange={handleChange} required />
              </div>
              <div className={styles.formGroup}>
                <label className={styles.formLabel}>Gender *</label>
                <div className={styles.radioGroup}>
                  <label className={styles.radioLabel}>
                    <input type="radio" name="gender" value="Male" checked={formData.gender === 'Male'} onChange={handleChange} required />
                    <span>Male</span>
                  </label>
                  <label className={styles.radioLabel}>
                    <input type="radio" name="gender" value="Female" checked={formData.gender === 'Female'} onChange={handleChange} />
                    <span>Female</span>
                  </label>
                </div>
              </div>
              <div className={styles.formGroup}>
                <label className={styles.formLabel}>Phone Number *</label>
                <input type="tel" name="phone" className={styles.formInput} value={formData.phone} onChange={handleChange} required />
              </div>
              <div className={styles.formGroup}>
                <label className={styles.formLabel}>Email ID *</label>
                <input type="email" name="email" className={styles.formInput} value={formData.email} onChange={handleChange} required />
              </div>
              <div className={styles.formGroup}>
                <label className={styles.formLabel}>Address *</label>
                <textarea name="address" className={styles.formTextarea} value={formData.address} onChange={handleChange} rows={3} required />
              </div>
              <div className={styles.formGroup}>
                <label className={styles.formLabel}>Degree (Pursuing/Pursued) *</label>
                <input type="text" name="degree" className={styles.formInput} value={formData.degree} onChange={handleChange} placeholder="Eg. B.E (ECE), M.Sc (IT)" required />
              </div>
              <div className={styles.formGroup}>
                <label className={styles.formLabel}>Year of Study *</label>
                <Select
                  value={formData.yearOfStudy}
                  options={YEAR_OPTIONS}
                  onChange={(v) => setFormData({ ...formData, yearOfStudy: v })}
                  placeholder="Select year"
                />
              </div>
              <div className={styles.formGroup}>
                <label className={styles.formLabel}>College Name *</label>
                <input type="text" name="college" className={styles.formInput} value={formData.college} onChange={handleChange} required />
              </div>
              <div className={styles.formGroup}>
                <label className={styles.formLabel}>College Location *</label>
                <input type="text" name="collegeLocation" className={styles.formInput} value={formData.collegeLocation} onChange={handleChange} required />
              </div>
              <div className={styles.formGroup}>
                <label className={styles.formLabel}>Select Internship Program Domain *</label>
                <Select
                  value={formData.domain}
                  options={domains.map(d => ({ value: d.name, label: d.name }))}
                  onChange={(v) => setFormData({ ...formData, domain: v })}
                  placeholder="Select domain"
                />
              </div>
              <div className={styles.formGroup}>
                <label className={styles.formLabel}>Internship Duration (To be Mentioned in Certificate) *</label>
                <Select
                  value={formData.duration}
                  options={durations.map(d => ({ value: d.name, label: d.name }))}
                  onChange={(v) => setFormData({ ...formData, duration: v })}
                  placeholder="Select duration"
                />
              </div>
              <div className={styles.formGroup}>
                <label className={styles.formLabel}>Mode of Training *</label>
                <p className={styles.formHint}>Hardcopy certificate will be provided without mentioning the mode of training.</p>
                <div className={styles.radioGroup}>
                  <label className={styles.radioLabel}>
                    <input type="radio" name="mode" value="Online" checked={formData.mode === 'Online'} onChange={handleChange} required />
                    <span>Online</span>
                  </label>
                  <label className={styles.radioLabel}>
                    <input type="radio" name="mode" value="Offline" checked={formData.mode === 'Offline'} onChange={handleChange} />
                    <span>Offline</span>
                  </label>
                </div>
              </div>
              <div className={styles.formGroup}>
                <label className={styles.formLabel}>Want to share something regarding this internship?</label>
                <textarea name="message" className={styles.formTextarea} value={formData.message} onChange={handleChange} rows={3} />
              </div>
              <div className={styles.formActions}>
                <Button type="submit" disabled={submitting}>
                  {submitting ? 'Submitting...' : 'Submit form'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      </section>

      <SuccessModal
        isOpen={showSuccess}
        onClose={handleCloseSuccess}
        title="Thank You!"
        message="Your application has been submitted successfully. We will contact you shortly."
      />
    </div>
  );
};
