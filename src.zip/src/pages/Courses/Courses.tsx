import React, { useState, useEffect } from 'react';
import { ArrowRight } from 'lucide-react';
import { Icon } from '@iconify/react';
import { Card } from '../../components/Card';
import { Button } from '../../components/Button';
import { Drawer } from '../../components/Drawer';
import { SuccessModal } from '../../components/SuccessModal';
import { courseApi, courseEnquiryApi } from '../../api';
import { Course } from '../../types';
import styles from './Courses.module.css';

const formatPrice = (price: number): string => {
  return '\u20B9' + price.toLocaleString('en-IN');
};

export const Courses: React.FC = () => {
  const [courses, setCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [isFormOpen, setIsFormOpen] = useState(false);
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        phone: '',
        address: '',
        degree: '',
        college: '',
        message: ''
    });
    const [showSuccess, setShowSuccess] = useState(false);

    useEffect(() => {
    fetchCourses();
  }, []);

  const fetchCourses = async () => {
    setLoading(true);
    try {
      const data = await courseApi.getAll();
      setCourses(data.courses || []);
    } catch (error) {
      console.error('Failed to fetch courses:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleViewCourse = (course: Course) => {
    setSelectedCourse(course);
    setIsDetailOpen(true);
  };

  const handleApplyNow = () => {
    setIsDetailOpen(false);
    setIsFormOpen(true);
  };

  const handleCloseForm = () => {
    setIsFormOpen(false);
    setFormData({ name: '', email: '', phone: '', address: '', degree: '', college: '', message: '' });
  };

  const handleSuccessClose = () => {
    setShowSuccess(false);
    handleCloseForm();
  };

  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCourse) return;
    try {
      await courseEnquiryApi.submit({
        course: selectedCourse._id,
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        address: formData.address,
        degree: formData.degree,
        college: formData.college,
        message: formData.message
      });
      setShowSuccess(true);
    } catch {
      alert('Failed to submit. Please try again.');
    }
  };

  return (
    <div className={styles.page}>
      <section className={styles.header}>
        <div className={styles.container}>
          <h1 className={styles.title}>Courses</h1>
          <p className={styles.description}>
            Industry-relevant courses designed by experts to accelerate your tech career.
          </p>
        </div>
      </section>

      <section className={styles.section}>
        <div className={styles.container}>
          {loading ? (
            <div className={styles.loading}>Loading courses...</div>
          ) : courses.length === 0 ? (
            <div className={styles.loading}>No courses available yet.</div>
          ) : (
            <div className={styles.grid}>
              {courses.map(course => (
                <Card key={course._id} className={styles.card}>
                  <div className={styles.cardBody}>
                    <div className={styles.cardMeta}>
                      <span className={styles.cardMode}>{course.mode}</span>
                      <span className={styles.cardId}>{course.courseId}</span>
                    </div>
                    <h3 className={styles.cardTitle}>{course.title}</h3>
                    <p className={styles.cardDescription}>{course.description}</p>
                    <div className={styles.cardIcons}>
                      {course.technologies.slice(0, 3).map((tech, i) => (
                        <span key={i} className={styles.cardIconPill}>
                          <Icon icon={tech.icon} width={20} height={20} />
                          <span>{tech.label}</span>
                        </span>
                      ))}
                    </div>
                    <div className={styles.cardDivider} />
                    <div className={styles.cardFooter}>
                      <span className={styles.cardPrice}>{formatPrice(course.price)}</span>
                      <Button size="sm" onClick={() => handleViewCourse(course)}>
                        View course <ArrowRight size={14} />
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      </section>

      <Drawer
        isOpen={isDetailOpen}
        onClose={() => setIsDetailOpen(false)}
        title="Course Details"
        footer={selectedCourse && (
          <Button onClick={handleApplyNow}>
            Apply Now <ArrowRight size={16} />
          </Button>
        )}
      >
        {selectedCourse && (
          <div className={styles.detailContent}>
            <div className={styles.detailId}>{selectedCourse.courseId}</div>
            <span className={styles.detailMode}>{selectedCourse.mode}</span>
            <h2 className={styles.detailTitle}>{selectedCourse.title}</h2>
            <p className={styles.detailDescription}>{selectedCourse.description}</p>
            <div className={styles.detailIcons}>
              {selectedCourse.technologies.map((tech, i) => (
                <span key={i} className={styles.detailIconPill}>
                  <Icon icon={tech.icon} width={20} height={20} />
                  <span>{tech.label}</span>
                </span>
              ))}
            </div>
            <div className={styles.detailSection}>
              <h3 className={styles.detailSectionTitle}>Course Coverage</h3>
              <ul className={styles.detailList}>
                {selectedCourse.coverage.map((item, i) => (
                  <li key={i}>{item}</li>
                ))}
              </ul>
            </div>
            <div className={styles.detailPriceRow}>
              <span className={styles.priceLabel}>Price:</span>
              <span className={styles.detailPrice}>{formatPrice(selectedCourse.price)}</span>
            </div>
          </div>
        )}
      </Drawer>

      <Drawer
        isOpen={isFormOpen}
        onClose={handleCloseForm}
        title="Course Enrollment"
        maxWidth="500px"
        footer={
          <>
            <Button variant="outline" onClick={handleCloseForm}>Cancel</Button>
            <Button type="submit" form="courseForm">Submit form</Button>
          </>
        }
      >
        {selectedCourse && (
          <div className={styles.formContent}>
            <div className={styles.formCourseInfo}>
              <span className={styles.formCourseId}>{selectedCourse.courseId}</span>
              <h3 className={styles.formCourseTitle}>{selectedCourse.title}</h3>
            </div>
            <form id="courseForm" className={styles.form} onSubmit={handleFormSubmit}>
              <div className={styles.formGroup}>
                <label className={styles.formLabel}>Full Name *</label>
                <input type="text" name="name" className={styles.formInput} value={formData.name} onChange={handleFormChange} required />
              </div>
              <div className={styles.formGroup}>
                <label className={styles.formLabel}>Email Address *</label>
                <input type="email" name="email" className={styles.formInput} value={formData.email} onChange={handleFormChange} required />
              </div>
              <div className={styles.formGroup}>
                <label className={styles.formLabel}>Phone Number *</label>
                <input type="tel" name="phone" className={styles.formInput} value={formData.phone} onChange={handleFormChange} required />
              </div>
              <div className={styles.formGroup}>
                <label className={styles.formLabel}>Address *</label>
                <textarea name="address" className={styles.formTextarea} value={formData.address} onChange={handleFormChange} rows={3} required />
              </div>
              <div className={styles.formGroup}>
                <label className={styles.formLabel}>Degree (Pursuing/Pursued)</label>
                <input type="text" name="degree" className={styles.formInput} value={formData.degree} onChange={handleFormChange} placeholder="Eg. B.Sc (CS), MCA" />
              </div>
              <div className={styles.formGroup}>
                <label className={styles.formLabel}>College/University</label>
                <input type="text" name="college" className={styles.formInput} value={formData.college} onChange={handleFormChange} />
              </div>
              <div className={styles.formGroup}>
                <label className={styles.formLabel}>Want to share something regarding this course?</label>
                <textarea name="message" className={styles.formTextarea} value={formData.message} onChange={handleFormChange} rows={3} />
              </div>
            </form>
          </div>
        )}
      </Drawer>

      <SuccessModal isOpen={showSuccess} onClose={handleSuccessClose} title="Thank You!" message="Your application has been submitted successfully. We will contact you shortly." />
    </div>
  );
};
