import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Badge } from '../../components/Badge';
import { Button } from '../../components/Button';
import { aboutSettingsApi, AboutSettings } from '../../api';
import styles from './About.module.css';
import logo from '../../assets/logo.jpg';

export const About: React.FC = () => {
  const [settings, setSettings] = useState<AboutSettings | null>(null);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [itemsPerView, setItemsPerView] = useState(3);

  useEffect(() => {
    aboutSettingsApi.get().then(setSettings).catch(console.error);
  }, []);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) setItemsPerView(3);
      else if (window.innerWidth >= 640) setItemsPerView(2);
      else setItemsPerView(1);
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const galleryImages = settings?.gallery ?? [];
  const maxSlides = Math.max(0, galleryImages.length - itemsPerView);

  const nextSlide = useCallback(() => {
    setCurrentSlide((prev) => (prev >= maxSlides ? 0 : prev + 1));
  }, [maxSlides]);

  const prevSlide = useCallback(() => {
    setCurrentSlide((prev) => (prev <= 0 ? maxSlides : prev - 1));
  }, [maxSlides]);

  useEffect(() => {
    if (!isPaused && maxSlides > 0) {
      const interval = setInterval(nextSlide, 3000);
      return () => clearInterval(interval);
    }
  }, [isPaused, nextSlide, maxSlides]);

  const team = settings?.team ?? [];

  return (
    <div className={styles.page}>
      {/* About Section */}
      <section className={styles.aboutSection}>
        <div className={styles.container}>
          <img src={logo} alt="U Can Solution" className={styles.logo} />
          <h1 className={styles.title}>{settings?.aboutTitle || 'About us'}</h1>
          <div className={styles.aboutContent}>
            {(settings?.aboutParagraphs?.length ? settings.aboutParagraphs : [
              'U Can Solution is a leading project development and training institute dedicated to empowering students and professionals with industry-oriented skills since 2010. With centers in Thiruthangal and Coimbatore, we focus on delivering practical learning experiences through professional training, internships, and real-time project development.',
              'Our goal is to bridge the gap between academic learning and industry expectations by providing hands-on exposure, updated technologies, and career-focused guidance. We believe learning should be practical, accessible, and aligned with the demands of today\'s fast-evolving digital world.'
            ]).map((p, i) => (
              <p key={i}>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{p}</p>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery Carousel */}
      <section className={styles.carouselSection}>
        <div className={styles.container}>
          <div className={styles.sectionHeader}>
            <Badge variant="outline">Gallery</Badge>
            <h2 className={styles.sectionTitle}>Life at U Can Solution</h2>
          </div>
          {galleryImages.length > 0 ? (
            <div className={styles.carouselContainer}>
              <div
                className={styles.carouselViewport}
                onClick={() => setIsPaused(true)}
                onMouseEnter={() => setIsPaused(true)}
                onMouseLeave={() => setIsPaused(false)}
              >
                <div
                  className={styles.carouselTrack}
                  style={{ transform: `translateX(-${currentSlide * (100 / itemsPerView)}%)` }}
                >
                  {galleryImages.map((image, i) => (
                    <div key={image._id || i} className={styles.carouselSlide}>
                      {image.image ? (
                        <img src={image.image} alt={image.alt} className={styles.galleryImage} />
                      ) : (
                        <div className={styles.galleryImagePlaceholder}>
                          {image.alt}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
              {maxSlides > 0 && (
                <div className={styles.carouselControls}>
                  <button className={styles.arrowBtn} onClick={() => { prevSlide(); setIsPaused(true); }} aria-label="Previous">
                    <ChevronLeft size={20} />
                  </button>
                  <button className={styles.arrowBtn} onClick={() => { nextSlide(); setIsPaused(true); }} aria-label="Next">
                    <ChevronRight size={20} />
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className={styles.carouselContainer}>
              <div className={styles.carouselViewport}>
                <div className={styles.emptyGallery}>No gallery images yet</div>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Team Section */}
      {team.length > 0 && (
        <section className={styles.section}>
          <div className={styles.container}>
            <div className={styles.sectionHeader}>
              <Badge variant="outline">Our Team</Badge>
              <h2 className={styles.sectionTitle}>People Behind U Can Solution</h2>
            </div>
            <div className={styles.teamGrid}>
              {team.map((member, i) => (
                <div key={member._id || i} className={styles.teamMemberCard}>
                  <div className={styles.memberImageWrapper}>
                    {member.image ? (
                      <img src={member.image} alt={member.name} className={styles.memberImage} />
                    ) : (
                      <div className={styles.memberImagePlaceholder}>{member.name.charAt(0)}</div>
                    )}
                  </div>
                  <h4 className={styles.memberName}>{member.name}</h4>
                  <p className={styles.memberRole}>{member.role}</p>
                  <p className={styles.memberDescription}>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{member.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* CTA Section */}
      <section className={styles.ctaSection}>
        <div className={styles.container}>
          <div className={styles.ctaBox}>
            <div className={styles.ctaContent}>
              <h2 className={styles.ctaTitle}>Ready to start your journey?</h2>
              <p className={styles.ctaDescription}>
                Join hundreds of students who have transformed their careers with U Can Solution.
              </p>
              <div className={styles.ctaActions}>
                <Link to="/courses">
                  <Button>Get Started Today</Button>
                </Link>
                <Link to="/internships">
                  <Button variant="outline">View Internships</Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
