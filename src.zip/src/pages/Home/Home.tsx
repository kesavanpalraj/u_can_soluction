import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Icon } from '@iconify/react';
import { Button } from '../../design-system';
import { Badge } from '../../design-system';
import { Card, Heading } from '../../design-system';
import { NewsTicker } from '../../components/NewsTicker';
import { HomepageSettings, homepageSettingsApi } from '../../api';
import styles from './Home.module.css';

const useCountUp = (end: number, duration: number = 2000, startOnView: boolean = true) => {
  const [count, setCount] = useState(0);
  const [hasStarted, setHasStarted] = useState(!startOnView);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!startOnView) return;
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !hasStarted) {
          setHasStarted(true);
        }
      },
      { threshold: 0.3 }
    );
    if (ref.current) {
      observer.observe(ref.current);
    }
    return () => observer.disconnect();
  }, [startOnView, hasStarted]);

  useEffect(() => {
    if (!hasStarted) return;
    let startTime: number;
    let animationFrame: number;
    const animate = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      const easeOutQuart = 1 - Math.pow(1 - progress, 4);
      setCount(Math.floor(easeOutQuart * end));
      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate);
      }
    };
    animationFrame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationFrame);
  }, [end, duration, hasStarted]);

  return { count, ref };
};

const StatItem: React.FC<{ stat: { value: number; suffix: string; label: string }; delay: number }> = ({ stat, delay }) => {
  const { count, ref } = useCountUp(stat.value, 2000 + delay);
  return (
    <div ref={ref} className={styles.statItem}>
      <span className={styles.statValue}>
        {count}
        <span className={styles.statSuffix}>{stat.suffix}</span>
      </span>
      <span className={styles.statLabel}>{stat.label}</span>
    </div>
  );
};

const features = [
  {
    icon: 'ph:chalkboard-teacher-bold',
    title: 'Industry-Experienced Trainers',
    description: 'Learn from professionals who bring real-world industry experience into the classroom. Our trainers focus on practical understanding, not just theory, helping students gain confidence in applying concepts.'
  },
  {
    icon: 'ph:certificate-bold',
    title: 'Internship with Certification',
    description: 'We offer 6-month project-based internships with certification through our industry collaborations in Madurai and Coimbatore, giving students valuable academic and practical exposure.'
  },
  {
    icon: 'ph:stack-bold',
    title: 'Wide Technology Domains',
    description: 'Training and projects are available across multiple domains including Web Development, Mobile Applications, Artificial Intelligence, IoT, Data Science, and other emerging technologies.'
  },
  {
    icon: 'ph:devices-bold',
    title: 'Flexible Learning Modes',
    description: 'Students can choose between online and offline learning modes, allowing them to learn at their own pace while balancing academic commitments.'
  },
  {
    icon: 'ph:book-open-text-bold',
    title: 'Complete Academic Project Guidance',
    description: 'Comprehensive support for undergraduate and postgraduate students, including topic selection, development, documentation, and final project delivery.'
  }
];

const TECH_ICON_POOL = [
  'logos:html-5',
  'logos:css-3',
  'logos:javascript',
  'logos:firebase-icon',
  'logos:bootstrap',
  'logos:nodejs-icon',
  'logos:vue',
  'logos:angular-icon',
  'logos:react',
  'logos:adobe-photoshop',
  'logos:adobe-illustrator',
  'vscode-icons:file-type-excel',
  'vscode-icons:file-type-powerpoint',
  'logos:aws',
  'devicon:jquery',
  'logos:python',
  'logos:java',
  'logos:kotlin-icon',
  'logos:php',
  'logos:arduino',
  'logos:raspberry-pi',
  'logos:android-icon',
  'logos:mysql',
];

const TestimonialCarousel: React.FC<{ testimonials: HomepageSettings['testimonials']; styles: Record<string, string> }> = ({ testimonials, styles }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const timerRef = useRef<ReturnType<typeof setInterval>>();

  const startTimer = () => {
    stopTimer();
    timerRef.current = setInterval(() => {
      setCurrentIndex(prev => (prev + 1) % testimonials.length);
    }, 5000);
  };

  const stopTimer = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = undefined;
    }
  };

  useEffect(() => {
    if (testimonials.length > 1) startTimer();
    return stopTimer;
  }, [testimonials.length]);

  const testimonial = testimonials[currentIndex];

  return (
    <div
      className={styles.testimonialsCarousel}
      onMouseEnter={stopTimer}
      onMouseLeave={startTimer}
    >
      <div key={currentIndex} className={`${styles.testimonialCard} ${styles.fadeIn}`}>
        <div className={styles.testimonialHeader}>
          <div className={styles.testimonialAvatar}>
            {testimonial.profilePic ? (
              <img src={testimonial.profilePic} alt={testimonial.name} className={styles.testimonialImage} />
            ) : (
              testimonial.name.charAt(0).toUpperCase()
            )}
          </div>
          <div className={styles.testimonialInfo}>
            <span className={styles.testimonialName}>{testimonial.name}</span>
          </div>
        </div>
        <div className={styles.testimonialRating}>
          {[1, 2, 3, 4, 5].map((star) => (
            <Icon key={star} icon={star <= testimonial.rating ? 'ph:star-fill' : 'ph:star'} width={14} height={14} className={styles.starIconSmall} />
          ))}
          <span className={styles.testimonialRatingText}>{testimonial.rating} out of 5</span>
        </div>
        <p className={styles.testimonialText}>"{testimonial.text}"</p>
      </div>
      {testimonials.length > 1 && (
        <div className={styles.testimonialControls}>
          <button className={styles.arrowBtn} onClick={() => setCurrentIndex(prev => (prev - 1 + testimonials.length) % testimonials.length)} aria-label="Previous">
            <ChevronLeft size={20} />
          </button>
          <button className={styles.arrowBtn} onClick={() => setCurrentIndex(prev => (prev + 1) % testimonials.length)} aria-label="Next">
            <ChevronRight size={20} />
          </button>
        </div>
      )}
    </div>
  );
};

export const Home: React.FC = () => {
  const [settings, setSettings] = useState<HomepageSettings | null>(null);
  const [settingsLoaded, setSettingsLoaded] = useState(false);

  useEffect(() => {
    homepageSettingsApi.get().then(data => { setSettings(data); setSettingsLoaded(true); }).catch(console.error);
  }, []);

  const statsData = settings?.stats || [
    { value: 500, suffix: '+', label: 'Students Trained' },
    { value: 50, suffix: '+', label: 'Projects Completed' },
    { value: 95, suffix: '%', label: 'Placement Rate' },
    { value: 20, suffix: '+', label: 'Industry Partners' }
  ];

  const testimonials = settings?.testimonials || [];
  const googleRating = settings?.googleRating || { rating: 4.9, count: 120 };

  return (
    <div className={styles.page}>
      {/* Hero Section */}
      <section className={styles.hero}>
        <div className={styles.container}>
          <Card variant="plain" className={styles.heroCard}>
            <div className={styles.techMarquee}>
              <div className={styles.techTrack}>
                {[...TECH_ICON_POOL, ...TECH_ICON_POOL].map((icon, i) => (
                  <span key={i} className={styles.techIconItem}>
                    <Icon icon={icon} width={20} height={20} />
                  </span>
                ))}
              </div>
            </div>
          <Heading as="h1" className={styles.heroTitle}>
            <span className={styles.heroLine1}>
              <span className={styles.heroWord}>Student&nbsp;&nbsp;Education&nbsp;&nbsp;Centre</span>
            </span>
            <span className={styles.heroLine2}>Get&nbsp;&nbsp;Industry-Ready!</span>
          </Heading>
          <p className={styles.heroDescription}>
            Industry-ready training programs, hands-on projects, and internship opportunities 
            to launch your career in technology.
          </p>
          <div className={styles.heroActions}>
            <Link to="/internships">
              <Button>
                Get Internship
                <Icon icon="icon-park-outline:arrow-right-up" width={18} height={18} />
              </Button>
            </Link>
          </div>
          </Card>
        </div>
      </section>

      <NewsTicker />

      {settingsLoaded && (
      <section className={styles.statsSection}>
        <div className={styles.statsContainer}>
          <div className={styles.statsBox}>
            {statsData.map((stat, index) => (
              <StatItem key={stat.label} stat={stat} delay={index * 100} />
            ))}
          </div>
        </div>
      </section>)}

      {/* Services Section */}
      <section className={styles.servicesSection}>
        <div className={styles.container}>
          <div className={styles.sectionHeader}>
            <Badge variant="outline">Our Services</Badge>
            <h2 className={styles.sectionTitle}>We cover all the tracks</h2>
          </div>
          <div className={styles.servicesWrapper}>
          <div className={styles.servicesGrid}>
            <Link to="/projects" className={styles.serviceCard}>
              <div className={styles.serviceIcon}>
                <Icon icon="ph:code-bold" width={28} height={28} />
              </div>
              <h3 className={styles.serviceTitle}>Projects</h3>
              <p className={styles.serviceDescription}>
                Real-world projects to build your portfolio and gain practical experience.
              </p>
              <span className={styles.serviceButton}>
                Explore Projects
                <Icon icon="icon-park-outline:arrow-right-up" width={16} height={16} />
              </span>
            </Link>

            <Link to="/courses" className={styles.serviceCard}>
              <div className={styles.serviceIcon}>
                <Icon icon="ph:graduation-cap-bold" width={28} height={28} />
              </div>
              <h3 className={styles.serviceTitle}>Courses</h3>
              <p className={styles.serviceDescription}>
                Industry-relevant courses designed by experts to make you job-ready.
              </p>
              <span className={styles.serviceButton}>
                Browse Courses
                <Icon icon="icon-park-outline:arrow-right-up" width={16} height={16} />
              </span>
            </Link>

            <Link to="/internships" className={styles.serviceCard}>
              <div className={styles.serviceIcon}>
                <Icon icon="ph:briefcase-bold" width={28} height={28} />
              </div>
              <h3 className={styles.serviceTitle}>Internships</h3>
              <p className={styles.serviceDescription}>
                Paid internship opportunities with top companies to kickstart your career.
              </p>
              <span className={styles.serviceButton}>
                Find Internships
                <Icon icon="icon-park-outline:arrow-right-up" width={16} height={16} />
              </span>
            </Link>
          </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className={styles.featuresSection}>
        <div className={styles.container}>
          <div className={styles.sectionHeader}>
            <Badge variant="outline">Why Choose Us</Badge>
            <h2 className={styles.sectionTitle}>Built to Help You Succeed</h2>
          </div>
          <div className={styles.featuresGrid}>
            {features.map((feature, index) => (
              <div key={feature.title} className={`${styles.featureItem} ${index >= 3 ? styles.featureItemBottom : ''}`}>
                <div className={styles.featureIcon}>
                  <Icon icon={feature.icon} width={24} height={24} />
                </div>
                <h3 className={styles.featureTitle}>{feature.title}</h3>
                <p className={styles.featureDescription}>{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className={styles.testimonialsSection}>
        <div className={styles.container}>
          <div className={styles.sectionHeader}>
            <Badge variant="outline">Testimonials</Badge>
            <h2 className={styles.sectionTitle}>What our students say</h2>
          </div>

          {/* Google Reviews Rating */}
          {settingsLoaded && googleRating.rating > 0 && (
            <div className={styles.googleRating}>
              <div className={styles.googleLogo}>
                <Icon icon="flat-color-icons:google" width={24} height={24} />
              </div>
              <div className={styles.ratingStars}>
                {[1, 2, 3, 4, 5].map((star) => {
                  const fraction = googleRating.rating - star + 1;
                  let icon = 'ph:star';
                  if (fraction >= 1) icon = 'ph:star-fill';
                  else if (fraction >= 0.25) icon = 'ph:star-half-fill';
                  return <Icon key={star} icon={icon} width={20} height={20} className={styles.starIcon} />;
                })}
              </div>
              <span className={styles.ratingText}>{googleRating.rating} out of 5</span>
              <span className={styles.ratingCount}>based on {googleRating.count}+ reviews</span>
            </div>
          )}

          {/* Testimonials Carousel */}
          {testimonials.length > 0 && (
            <TestimonialCarousel testimonials={testimonials} styles={styles} />
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className={styles.ctaSection}>
        <div className={styles.container}>
          <div className={styles.ctaBox}>
            <div className={styles.ctaContent}>
              <h2 className={styles.ctaTitle}>Ready to start your journey?</h2>
              <p className={styles.ctaDescription}>
                Join hundreds of students who have transformed their careers with U Can Solution.
              </p>
              <div className={styles.ctaActions}>
                <Link to="/courses">
                  <Button>Get Started Today</Button>
                </Link>
                <Link to="/internships">
                  <Button variant="outline" className={styles.ctaOutlineBtn}>View Internships</Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
