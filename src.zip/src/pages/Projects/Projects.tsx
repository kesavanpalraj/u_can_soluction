import React, { useState, useEffect, useCallback } from 'react';
import { X, ArrowRight, ChevronLeft, ChevronRight, Search, ExternalLink } from 'lucide-react';
import { Button } from '../../components/Button';
import { Drawer } from '../../components/Drawer';
import { SuccessModal } from '../../components/SuccessModal';
import { categoryApi, projectApi, enquiryApi, projectPdfApi } from '../../api';
import { Category, Project, ProjectEnquiry } from '../../types';
import { CategoryFilter } from '../../components/CategoryFilter';
import styles from './Projects.module.css';

const ITEMS_PER_PAGE = 100;

export const Projects: React.FC = () => {
    const [categories, setCategories] = useState<Category[]>([]);
    const [projects, setProjects] = useState<Project[]>([]);
    const [selectedCategory, setSelectedCategory] = useState('All');
    const [isFilterOpen, setIsFilterOpen] = useState(false);
    const [selectedProject, setSelectedProject] = useState<Project | null>(null);
    const [isDetailOpen, setIsDetailOpen] = useState(false);
    const [isFormOpen, setIsFormOpen] = useState(false);
    const [currentPage, setCurrentPage] = useState(1);
    const [searchQuery, setSearchQuery] = useState('');
    const [debouncedSearch, setDebouncedSearch] = useState('');
    const [totalProjects, setTotalProjects] = useState(0);
    const [totalPages, setTotalPages] = useState(1);
    const [isLoading, setIsLoading] = useState(true);
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        phone: '',
        address: '',
        degree: '',
        college: '',
        message: ''
    });
    const [showSuccess, setShowSuccess] = useState(false);
    const [projectPdfUrl, setProjectPdfUrl] = useState('');

    const fetchCategories = useCallback(async () => {
        try {
            const data = await categoryApi.getAll();
            setCategories(data);
        } catch (error) {
            console.error('Failed to fetch categories:', error);
        }
    }, []);

    const fetchProjects = useCallback(async () => {
        setIsLoading(true);
        try {
            const categoryId = selectedCategory === 'All' ? undefined : selectedCategory;

            const data = await projectApi.getAll({
                category: categoryId,
                search: debouncedSearch || undefined,
                page: currentPage,
                limit: ITEMS_PER_PAGE
            });

            setProjects(data.projects || []);
            setTotalProjects(data.total);
            setTotalPages(data.totalPages);
        } catch (error) {
            console.error('Failed to fetch projects:', error);
            setProjects([]);
        } finally {
            setIsLoading(false);
        }
    }, [selectedCategory, debouncedSearch, currentPage]);

    const fetchPdfUrl = useCallback(async () => {
        try {
            const data = await projectPdfApi.get();
            setProjectPdfUrl(data.url || '');
        } catch (error) {
            console.error('Failed to fetch project PDF URL:', error);
        }
    }, []);

    useEffect(() => {
        fetchCategories();
        fetchPdfUrl();
    }, [fetchCategories, fetchPdfUrl]);

    useEffect(() => {
        fetchProjects();
    }, [fetchProjects]);

    useEffect(() => {
        const timer = setTimeout(() => {
            setDebouncedSearch(searchQuery);
        }, 300);
        return () => clearTimeout(timer);
    }, [searchQuery]);

    useEffect(() => {
        setCurrentPage(1);
    }, [selectedCategory, debouncedSearch]);

    const handleCategoryToggle = (category: string) => {
        setSelectedCategory(selectedCategory === category ? 'All' : category);
    };

    const handleClearFilters = () => {
        setSelectedCategory('All');
    };

    const handleShowDetails = (project: Project) => {
        setSelectedProject(project);
        setIsDetailOpen(true);
    };

    const handleGetProject = () => {
        setIsDetailOpen(false);
        setIsFormOpen(true);
    };

    const handleCloseForm = () => {
        setIsFormOpen(false);
        setFormData({ name: '', email: '', phone: '', address: '', degree: '', college: '', message: '' });
    };

    const handleSuccessClose = () => {
        setShowSuccess(false);
        handleCloseForm();
    };

    const handleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        });
    };

    const handleFormSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!selectedProject) return;

        try {
            const enquiryData: Omit<ProjectEnquiry, '_id' | 'status'> = {
                project: selectedProject._id,
                projectId: selectedProject.projectId,
                name: formData.name,
                email: formData.email,
                phone: formData.phone,
                address: formData.address,
                degree: formData.degree,
                college: formData.college,
                message: formData.message
            };

            await enquiryApi.submit(enquiryData);
            setShowSuccess(true);
        } catch (error) {
            console.error('Failed to submit enquiry:', error);
            alert('Failed to submit. Please try again.');
        }
    };

    const hasActiveFilters = selectedCategory !== 'All';

    const getCategoryName = (category: Category | string): string => {
        if (typeof category === 'string') return category;
        return category.name;
    };

    const displayCategories = categories.filter(c => c.name !== 'All');

    const formatProjectId = (id: string): string => {
        const num = id.replace(/\D/g, '');
        return `P${num.padStart(4, '0')}`;
    };

    const getYouTubeEmbedUrl = (url: string): string | null => {
        const match = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([a-zA-Z0-9_-]{11})/);
        return match ? `https://www.youtube.com/embed/${match[1]}` : null;
    };

    const startItem = totalProjects === 0 ? 0 : (currentPage - 1) * ITEMS_PER_PAGE + 1;
    const endItem = Math.min(currentPage * ITEMS_PER_PAGE, totalProjects);

    return (
        <div className={styles.page}>
            <section className={styles.header}>
                <div className={styles.container}>
                    <h1 className={styles.title}>Projects</h1>
                    <p className={styles.description}>
                        Projects are delivered online and offline for students pursuing B.Sc (CS), IT, BCA, B.Com (CA), M.Com (CA), M.Sc, MCA, Diploma, BE, and ME.
                    </p>
                    {projectPdfUrl && (
                        <a href={projectPdfUrl} target="_blank" rel="noopener noreferrer" className={styles.downloadLink}>
                            <ExternalLink size={14} />
                            Download Complete Project List (PDF)
                        </a>
                    )}
                </div>
            </section>

            <section className={styles.section}>
                <div className={styles.container}>
                    <div className={styles.layout}>
                        <aside className={styles.filterSidebar}>
                            <div className={styles.filterHeader}>
                                <h3 className={styles.filterTitle}>Categories</h3>
                                <button
                                    className={`${styles.clearButton}${!hasActiveFilters ? ` ${styles.clearButtonHidden}` : ''}`}
                                    onClick={handleClearFilters}
                                >
                                    Clear
                                </button>
                            </div>
                            <CategoryFilter
                                categories={[
                                    { value: 'All', label: 'All categories' },
                                    ...displayCategories.map(c => ({ value: c._id, label: c.name }))
                                ]}
                                selected={selectedCategory}
                                onSelect={(val) => handleCategoryToggle(val)}
                                variant="sidebar"
                            />
                        </aside>

                        <div className={styles.content}>
                            <div className={styles.resultsHeader}>
                                <div className={styles.searchContainer}>
                                    <Search size={18} className={styles.searchIcon} />
                                    <input
                                        type="text"
                                        placeholder="Search by title, ID, or tags..."
                                        value={searchQuery}
                                        onChange={(e) => setSearchQuery(e.target.value)}
                                        className={styles.searchInput}
                                    />
                                    {searchQuery && (
                                        <button
                                            className={styles.searchClear}
                                            onClick={() => setSearchQuery('')}
                                            aria-label="Clear search"
                                        >
                                            <X size={16} />
                                        </button>
                                    )}
                                </div>
                                <p className={styles.resultsCount}>
                                    {isLoading ? 'Loading...' : `Showing ${startItem}-${endItem} of ${totalProjects} projects`}
                                </p>
                            </div>

                            {isLoading ? (
                                <div className={styles.noResults}>
                                    <p>Loading projects...</p>
                                </div>
                            ) : projects.length === 0 ? (
                                <div className={styles.noResults}>
                                    <p>
                                        {searchQuery
                                            ? `No projects found for "${searchQuery}"${selectedCategory !== 'All' ? ' in selected category' : ''}.`
                                            : 'No projects found for the selected category.'}
                                    </p>
                                    {(searchQuery || selectedCategory !== 'All') && (
                                        <Button variant="outline" onClick={() => {
                                            setSearchQuery('');
                                            handleClearFilters();
                                        }}>
                                            Clear All Filters
                                        </Button>
                                    )}
                                </div>
                            ) : (
                                <>
                                    <div className={styles.list}>
                                        {projects.map((project) => (
                                            <div
                                                key={project._id}
                                                className={styles.row}
                                                onClick={() => handleShowDetails(project)}
                                                role="button"
                                                tabIndex={0}
                                                onKeyDown={(e) => { if (e.key === 'Enter') handleShowDetails(project); }}
                                            >
                                                <span className={styles.rowId}>{formatProjectId(project.projectId ?? '')}</span>
                                                <span className={styles.rowTitle}>{project.title}</span>
                                                <span className={styles.rowCategory}>{getCategoryName(project.category)}</span>
                                                <ChevronRight size={16} className={styles.rowArrow} />
                                            </div>
                                        ))}
                                    </div>

                                    {totalPages > 1 && (
                                        <div className={styles.pagination}>
                                            <button
                                                className={styles.paginationArrow}
                                                onClick={() => {
                                                    setCurrentPage(p => p - 1);
                                                    window.scrollTo({ top: 0, behavior: 'smooth' });
                                                }}
                                                disabled={currentPage === 1}
                                                aria-label="Previous page"
                                            >
                                                <ChevronLeft size={18} />
                                            </button>
                                            <span className={styles.paginationInfo}>
                                                Page {currentPage} of {totalPages}
                                            </span>
                                            <button
                                                className={styles.paginationArrow}
                                                onClick={() => {
                                                    setCurrentPage(p => p + 1);
                                                    window.scrollTo({ top: 0, behavior: 'smooth' });
                                                }}
                                                disabled={currentPage === totalPages}
                                                aria-label="Next page"
                                            >
                                                <ChevronRight size={18} />
                                            </button>
                                        </div>
                                    )}
                                </>
                            )}
                        </div>
                    </div>
                </div>
            </section>

            <button
                className={`${styles.mobileFilterButton} ${hasActiveFilters ? styles.mobileFilterButtonActive : ''}`}
                onClick={() => setIsFilterOpen(true)}
                aria-label="Open filters"
            >
                <Search size={18} />
                <span className={styles.mobileFilterText}>Filter</span>
                {hasActiveFilters && (
                    <span className={styles.filterBadge}>1</span>
                )}
            </button>

            <Drawer
                isOpen={isFilterOpen}
                onClose={() => setIsFilterOpen(false)}
                title="Filter by Category"
                footer={
                    <>
                        {hasActiveFilters && (
                            <Button variant="outline" onClick={handleClearFilters}>
                                Clear
                            </Button>
                        )}
                        <Button onClick={() => setIsFilterOpen(false)}>
                            Show {totalProjects} Projects
                        </Button>
                    </>
                }
            >
                <CategoryFilter
                    categories={[
                        { value: 'All', label: 'All categories' },
                        ...displayCategories.map(c => ({ value: c._id, label: c.name }))
                    ]}
                    selected={selectedCategory}
                    onSelect={(val) => handleCategoryToggle(val)}
                    variant="mobile"
                />
            </Drawer>

            <Drawer
                isOpen={isDetailOpen}
                onClose={() => setIsDetailOpen(false)}
                title="Project Details"
                footer={selectedProject && (
                    <Button onClick={handleGetProject}>
                        Get Project <ArrowRight size={16} />
                    </Button>
                )}
            >
                {selectedProject && (
                    <div className={styles.detailContent}>
                        <div className={styles.detailMeta}>
                            <span className={styles.detailCategory}>{getCategoryName(selectedProject.category)}</span>
                            <span className={styles.detailId}>{selectedProject.projectId}</span>
                        </div>
                        <h2 className={styles.detailTitle}>{selectedProject.title}</h2>
                        <p className={styles.detailDescription}>{selectedProject.description}</p>
                        {selectedProject.tags?.length > 0 && (
                            <div className={styles.detailTags}>
                                {selectedProject.tags.map(tag => (
                                    <span key={tag} className={styles.detailTag}>{tag}</span>
                                ))}
                            </div>
                        )}
                        {selectedProject.downloadAbstract && (
                            <a
                                href={selectedProject.downloadAbstract}
                                target="_blank"
                                rel="noopener noreferrer"
                                className={styles.abstractLink}
                            >
                                Download full abstract <ExternalLink size={14} />
                            </a>
                        )}
                        {selectedProject.youtubeUrl && (() => {
                            const embedUrl = getYouTubeEmbedUrl(selectedProject.youtubeUrl);
                            return embedUrl ? (
                                <div className={styles.youtubeContainer}>
                                    <iframe
                                        src={embedUrl}
                                        title="YouTube video"
                                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                        allowFullScreen
                                    />
                                </div>
                            ) : null;
                        })()}
                    </div>
                )}
            </Drawer>

            <Drawer
                isOpen={isFormOpen}
                onClose={handleCloseForm}
                title="Get Project"
                maxWidth="500px"
                footer={
                    <>
                        <Button variant="outline" onClick={handleCloseForm}>Cancel</Button>
                        <Button type="submit" form="projectForm">Submit form</Button>
                    </>
                }
            >
                {selectedProject && (
                    <div className={styles.formContent}>
                        <div className={styles.formProjectInfo}>
                            <span className={styles.formProjectId}>{selectedProject.projectId}</span>
                            <h3 className={styles.formProjectTitle}>{selectedProject.title}</h3>
                        </div>
                        <form id="projectForm" className={styles.form} onSubmit={handleFormSubmit}>
                            <div className={styles.formGroup}>
                                <label className={styles.formLabel}>Full Name *</label>
                                <input type="text" name="name" className={styles.formInput} value={formData.name} onChange={handleFormChange} required />
                            </div>
                            <div className={styles.formGroup}>
                                <label className={styles.formLabel}>Email Address *</label>
                                <input type="email" name="email" className={styles.formInput} value={formData.email} onChange={handleFormChange} required />
                            </div>
                            <div className={styles.formGroup}>
                                <label className={styles.formLabel}>Phone Number *</label>
                                <input type="tel" name="phone" className={styles.formInput} value={formData.phone} onChange={handleFormChange} required />
                            </div>
                            <div className={styles.formGroup}>
                                <label className={styles.formLabel}>Address *</label>
                                <textarea name="address" className={styles.formTextarea} value={formData.address} onChange={handleFormChange} rows={3} required />
                            </div>
                            <div className={styles.formGroup}>
                                <label className={styles.formLabel}>Degree (Pursuing/Pursued)</label>
                                <input type="text" name="degree" className={styles.formInput} value={formData.degree} onChange={handleFormChange} placeholder="Eg. B.Sc (CS), MCA" />
                            </div>
                            <div className={styles.formGroup}>
                                <label className={styles.formLabel}>College/University</label>
                                <input type="text" name="college" className={styles.formInput} value={formData.college} onChange={handleFormChange} />
                            </div>
                            <div className={styles.formGroup}>
                                <label className={styles.formLabel}>Want to share something regarding this project?</label>
                                <textarea name="message" className={styles.formTextarea} value={formData.message} onChange={handleFormChange} rows={4} />
                            </div>
                        </form>
                    </div>
                )}
            </Drawer>

            <SuccessModal isOpen={showSuccess} onClose={handleSuccessClose} title="Thank You!" message="Your application has been submitted successfully. We will contact you shortly." />
        </div>
    );
};