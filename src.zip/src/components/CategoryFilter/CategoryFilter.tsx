import styles from './CategoryFilter.module.css';

interface CategoryFilterProps {
    categories: { value: string; label: string }[];
    selected: string;
    onSelect: (value: string) => void;
    variant?: 'sidebar' | 'mobile';
}

export const CategoryFilter: React.FC<CategoryFilterProps> = ({ categories, selected, onSelect, variant = 'sidebar' }) => {
    const isMobile = variant === 'mobile';
    return (
        <div className={isMobile ? styles.mobileList : styles.list}>
            {categories.map(cat => {
                const isActive = selected === cat.value;
                return (
                    <button
                        key={cat.value}
                        className={`${isMobile ? styles.mobileItem : styles.item} ${isActive ? (isMobile ? styles.mobileItemActive : styles.itemActive) : ''}`}
                        onClick={() => onSelect(cat.value)}
                    >
                        <span className={styles.radio}>
                            {isActive && <span className={styles.dot} />}
                        </span>
                        <span>{cat.label}</span>
                    </button>
                );
            })}
        </div>
    );
};
