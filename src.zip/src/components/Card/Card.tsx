import React from 'react';
import styles from './Card.module.css';

interface CardProps {
  className?: string;
  children: React.ReactNode;
}

export const Card: React.FC<CardProps> = ({ className = '', children }) => (
  <div className={`${styles.card} ${className}`}>{children}</div>
);

export const CardHeader: React.FC<CardProps> = ({ className = '', children }) => (
  <div className={`${styles.header} ${className}`}>{children}</div>
);

export const CardTitle: React.FC<CardProps & { as?: 'h1' | 'h2' | 'h3' | 'h4' }> = ({ 
  className = '', 
  children,
  as: Tag = 'h3'
}) => (
  <Tag className={`${styles.title} ${className}`}>{children}</Tag>
);

export const CardDescription: React.FC<CardProps> = ({ className = '', children }) => (
  <p className={`${styles.description} ${className}`}>{children}</p>
);

export const CardContent: React.FC<CardProps> = ({ className = '', children }) => (
  <div className={`${styles.content} ${className}`}>{children}</div>
);

export const CardFooter: React.FC<CardProps> = ({ className = '', children }) => (
  <div className={`${styles.footer} ${className}`}>{children}</div>
);
