import React from 'react';
import './Section.css';

export interface SectionProps {
  children: React.ReactNode;
  className?: string;
  background?: 'default' | 'muted' | 'dark';
  size?: 'sm' | 'md' | 'lg';
}

export const Section: React.FC<SectionProps> = ({
  children,
  className = '',
  background = 'default',
  size = 'md',
}) => {
  const classes = [
    'section',
    `section--${background}`,
    `section--${size}`,
    className,
  ].filter(Boolean).join(' ');

  return <section className={classes}>{children}</section>;
};

export const SectionHeader: React.FC<{
  children: React.ReactNode;
  centered?: boolean;
  className?: string;
}> = ({ children, centered = true, className = '' }) => {
  const classes = [
    'section__header',
    centered ? 'section__header--centered' : '',
    className,
  ].filter(Boolean).join(' ');

  return <div className={classes}>{children}</div>;
};

export const SectionTitle: React.FC<{
  children: React.ReactNode;
  className?: string;
}> = ({ children, className = '' }) => (
  <h2 className={`section__title ${className}`}>{children}</h2>
);

export const SectionDescription: React.FC<{
  children: React.ReactNode;
  className?: string;
}> = ({ children, className = '' }) => (
  <p className={`section__description ${className}`}>{children}</p>
);
