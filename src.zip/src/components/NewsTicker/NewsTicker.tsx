import { useState, useEffect, useCallback } from 'react';
import { ExternalLink } from 'lucide-react';
import { newsEventApi, NewsEvent } from '../../api';
import { Badge } from '../../design-system';
import { Drawer } from '../Drawer';
import styles from './NewsTicker.module.css';

export const NewsTicker = () => {
    const [items, setItems] = useState<NewsEvent[]>([]);
    const [isDrawerOpen, setIsDrawerOpen] = useState(false);

    useEffect(() => {
        newsEventApi.getActive().then(setItems).catch(() => {});
    }, []);

    const handleViewAll = useCallback(() => setIsDrawerOpen(true), []);

    const renderItem = (item: NewsEvent, idx: number) => (
        <div key={`${item._id}-${idx}`} className={styles.itemRow}>
            <span className={`${styles.dot} ${item.type === 'event' ? styles.dotEvent : styles.dotNews}`} />
            <span className={styles.itemText}>{item.title}</span>
            {item.link && <ExternalLink size={12} className={styles.linkIcon} />}
        </div>
    );

    return (
        <section className={styles.section}>
            <div className={styles.container}>
                <div className={styles.ticker}>
                    <div className={styles.tickerHeader}>
                        <Badge variant="outline">Latest News & Events</Badge>
                    </div>
                    <div className={styles.scrollContainer}>
                        {items.length > 0 && (
                            <div className={styles.scrollTrack}>
                                {items.map((item) => renderItem(item, 0))}
                                {items.map((item) => renderItem(item, 1))}
                            </div>
                        )}
                        {items.length === 0 && (
                            <div className={styles.emptyState}>No announcements yet</div>
                        )}
                    </div>
                    {items.length > 0 && (
                        <button className={styles.viewAll} onClick={handleViewAll}>
                            View all →
                        </button>
                    )}
                </div>
            </div>

            <Drawer
                isOpen={isDrawerOpen}
                onClose={() => setIsDrawerOpen(false)}
                title="All News & Events"
                maxWidth="800px"
            >
                <div className={styles.drawerList}>
                    {items.map((item) => (
                        <div key={item._id} className={styles.drawerItem}>
                            <span className={`${styles.drawerDot} ${item.type === 'event' ? styles.dotEvent : styles.dotNews}`} />
                            <div className={styles.drawerContent}>
                                <span className={styles.drawerTitle}>{item.title}</span>
                                <span className={styles.drawerType}>{item.type === 'event' ? 'Event' : 'News'}</span>
                            </div>
                            {item.link && (
                                <a href={item.link} target="_blank" rel="noopener noreferrer" className={styles.drawerLink}>
                                    <ExternalLink size={14} />
                                </a>
                            )}
                        </div>
                    ))}
                    {items.length === 0 && (
                        <div className={styles.drawerEmpty}>No announcements yet</div>
                    )}
                </div>
            </Drawer>
        </section>
    );
};
