import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import styles from './Navigation.module.css';
import logo from '../../assets/logo.jpg';

const navLinks = [
  { path: '/', label: 'Home' },
  { path: '/projects', label: 'Projects' },
  { path: '/courses', label: 'Courses' },
  { path: '/internships', label: 'Internships' },
  { path: '/about', label: 'About Us' },
];

export const Navigation: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  const toggleMenu = () => setIsOpen(!isOpen);
  const closeMenu = () => setIsOpen(false);

  // Prevent body scroll when menu is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  // Close menu on route change
  useEffect(() => {
    closeMenu();
  }, [location.pathname]);

  return (
    <>
      <header className={styles.header}>
        <div className={styles.container}>
          {/* Logo */}
          <Link to="/" className={styles.logo} onClick={closeMenu}>
            <img src={logo} alt="U Can Solution" className={styles.logoImg} />
            <span className={styles.logoText}>U Can Solution</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className={styles.desktopNav}>
            {navLinks.map(({ path, label }) => (
              <Link
                key={path}
                to={path}
                className={`${styles.navLink} ${location.pathname === path ? styles.active : ''}`}
              >
                {label}
              </Link>
            ))}
          </nav>

          {/* Mobile Menu Toggle */}
          <button
            className={`${styles.menuToggle} ${isOpen ? styles.menuToggleOpen : ''}`}
            onClick={toggleMenu}
            aria-label={isOpen ? 'Close menu' : 'Open menu'}
            aria-expanded={isOpen}
          >
            <span className={styles.menuIcon}>
              <span className={styles.menuLine}></span>
              <span className={styles.menuLine}></span>
            </span>
          </button>
        </div>
      </header>

      {/* Mobile Navigation Overlay - Outside header for full screen */}
      <div className={`${styles.mobileOverlay} ${isOpen ? styles.mobileOverlayOpen : ''}`}>
        <nav className={styles.mobileNav}>
          {navLinks.map(({ path, label }) => (
            <Link
              key={path}
              to={path}
              className={`${styles.mobileNavLink} ${location.pathname === path ? styles.active : ''}`}
              onClick={closeMenu}
            >
              {label}
            </Link>
          ))}
        </nav>
      </div>
    </>
  );
};
