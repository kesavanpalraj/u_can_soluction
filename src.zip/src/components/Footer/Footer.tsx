import React from 'react';
import { Link } from 'react-router-dom';
import { Mail, Phone, MapPin, MessageCircle } from 'lucide-react';
import { Icon } from '@iconify/react';
import styles from './Footer.module.css';
import logo from '../../assets/logo.jpg';

export const Footer: React.FC = () => {
  const googleMapsUrl = 'https://www.google.com/maps/place/U+Can+Solutions/@9.4805615,77.8104061,17z/data=!3m1!4b1!4m6!3m5!1s0x3b06ce43d73d04ef:0xe39577ba11a22367!8m2!3d9.4805615!4d77.8104061!16s%2Fg%2F11clzj69g1';
  const googleMapsEmbedUrl = 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d980.5!2d77.8104061!3d9.4805615!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3b06ce43d73d04ef%3A0xe39577ba11a22367!2sU%20Can%20Solutions!5e0!3m2!1sen!2sin!4v1709900000000';
  const gmailComposeUrl = 'https://mail.google.com/mail/?view=cm&fs=1&to=ucansolutions4u@gmail.com';

  return (
    <>
      <footer className={styles.footer}>
        <div className={styles.container}>
          <div className={styles.grid}>
          {/* Brand & Description */}
          <div className={styles.brand}>
            <div className={styles.logoContainer}>
              <Link to="/" className={styles.logo}>
                <img src={logo} alt="U Can Solution" className={styles.logoImg} />
                <span className={styles.logoText}>U Can Solution</span>
              </Link>
            </div>
            <p className={styles.description}>
              U Can Solution is a computer training institute providing practical, career-oriented courses, project development, and internship support since 2010.
            </p>
            
            {/* Social Media Icons */}
            <div className={styles.social}>
              <a 
                href="https://www.facebook.com/ganesh.gagi?mibextid=ZbWKwL" 
                target="_blank" 
                rel="noopener noreferrer"
                aria-label="Facebook"
                className={styles.socialLink}
              >
                <Icon icon="mdi:facebook" width={20} height={20} />
              </a>
              <a 
                href="https://www.youtube.com/@techfevertablet" 
                target="_blank" 
                rel="noopener noreferrer"
                aria-label="YouTube"
                className={styles.socialLink}
              >
                <Icon icon="mdi:youtube" width={20} height={20} />
              </a>
              <a 
                href="https://instagram.com/ganesh_developer" 
                target="_blank" 
                rel="noopener noreferrer"
                aria-label="Instagram"
                className={styles.socialLink}
              >
                <Icon icon="mdi:instagram" width={20} height={20} />
              </a>
            </div>
          </div>

          {/* Contact */}
          <div className={styles.contact}>
            <h4 className={styles.heading}>Contact</h4>
            <ul className={styles.contactList}>
              <li className={styles.contactItem}>
                <MapPin size={16} className={styles.contactIcon} />
                <a 
                  href={googleMapsUrl}
                  target="_blank" 
                  rel="noopener noreferrer"
                  className={styles.contactLink}
                >
                  33 A, K.M.K.R Complex, S.N. Puram Road, Thiruthangal, Virudhunagar District, Tamilnadu – 626130
                </a>
              </li>
              <li className={styles.contactItem}>
                <Phone size={16} className={styles.contactIcon} />
                <div className={styles.phoneNumbers}>
                  <a href="tel:+919600874792" className={styles.contactLink}>+91 96008 74792</a>
                  <span className={styles.phoneSeparator}>|</span>
                  <a href="tel:+918072045527" className={styles.contactLink}>+91 80720 45527</a>
                </div>
              </li>
              <li className={styles.contactItem}>
                <MessageCircle size={16} className={styles.contactIcon} />
                <a 
                  href="https://wa.me/919600874792" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className={styles.contactLink}
                >
                  WhatsApp: +91 96008 74792
                </a>
              </li>
              <li className={styles.contactItem}>
                <Mail size={16} className={styles.contactIcon} />
                <a 
                  href={gmailComposeUrl}
                  target="_blank" 
                  rel="noopener noreferrer"
                  className={styles.contactLink}
                >
                  ucansolutions4u@gmail.com
                </a>
              </li>
            </ul>
          </div>

          {/* Google Map */}
          <div className={styles.mapSection}>
            <h4 className={styles.heading}>Find Us</h4>
            <a 
              href={googleMapsUrl}
              target="_blank" 
              rel="noopener noreferrer"
              className={styles.mapLink}
            >
              <div className={styles.mapWrapper}>
                <iframe
                  src={googleMapsEmbedUrl}
                  width="100%"
                  height="140"
                  style={{ border: 0, borderRadius: '8px' }}
                  allowFullScreen={false}
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="U Can Solution Location"
                ></iframe>
                <div className={styles.mapOverlay}>
                  <span>Open in Google Maps</span>
                  <Icon icon="icon-park-outline:arrow-right-up" width={14} height={14} />
                </div>
              </div>
            </a>
          </div>
        </div>

        {/* Bottom Section */}
        <div className={styles.bottom}>
          <p className={styles.copyright}>
            © {new Date().getFullYear()} U Can Solution. All rights reserved.
          </p>
          <p className={styles.madeWith}>
            Made with <span className={styles.heart}>❤</span>
          </p>
        </div>
      </div>
      </footer>
    </>
  );
};
