import { useState, createContext, useContext, useCallback, useRef } from 'react';
import { X, CheckCircle, AlertCircle, Info, XCircle } from 'lucide-react';
import styles from './Toast.module.css';

type ToastType = 'success' | 'error' | 'info' | 'warning';

interface Toast {
    id: string;
    message: string;
    type: ToastType;
    duration?: number;
}

interface ToastContextType {
    toasts: Toast[];
    addToast: (message: string, type?: ToastType, duration?: number) => void;
    removeToast: (id: string) => void;
}

const ToastContext = createContext<ToastContextType | undefined>(undefined);

export const useToast = () => {
    const context = useContext(ToastContext);
    if (!context) {
        throw new Error('useToast must be used within a ToastProvider');
    }
    return context;
};

export const ToastProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const [toasts, setToasts] = useState<Toast[]>([]);
    const toastIdCounter = useRef(0);

    const addToast = useCallback((message: string, type: ToastType = 'info', duration: number = 5000) => {
        const id = `toast-${++toastIdCounter.current}`;
        const newToast: Toast = { id, message, type, duration };
        
        setToasts(prev => [...prev, newToast]);

        if (duration > 0) {
            setTimeout(() => {
                removeToast(id);
            }, duration);
        }
    }, []);

    const removeToast = useCallback((id: string) => {
        setToasts(prev => prev.filter(t => t.id !== id));
    }, []);

    return (
        <ToastContext.Provider value={{ toasts, addToast, removeToast }}>
            {children}
            <ToastContainer toasts={toasts} onRemove={removeToast} />
        </ToastContext.Provider>
    );
};

const ToastContainer: React.FC<{ toasts: Toast[]; onRemove: (id: string) => void }> = ({ toasts, onRemove }) => {
    if (toasts.length === 0) return null;

    return (
        <div className={styles.container}>
            {toasts.map((t) => (
                <ToastItem key={t.id} toast={t} onRemove={onRemove} />
            ))}
        </div>
    );
};

const ToastItem: React.FC<{ toast: Toast; onRemove: (id: string) => void }> = ({ toast, onRemove }) => {
    const [isExiting, setIsExiting] = useState(false);

    const handleRemove = () => {
        setIsExiting(true);
        setTimeout(() => {
            onRemove(toast.id);
        }, 200);
    };

    const IconComponent = {
        success: CheckCircle,
        error: XCircle,
        info: Info,
        warning: AlertCircle,
    }[toast.type];

    return (
        <div className={`${styles.toast} ${styles[toast.type]} ${isExiting ? styles.exiting : ''}`}>
            <IconComponent size={18} className={styles.icon} />
            <span className={styles.message}>{toast.message}</span>
            <button onClick={handleRemove} className={styles.closeBtn}>
                <X size={16} />
            </button>
        </div>
    );
};

let toastInstance: ToastContextType | null = null;

export const initToast = (context: ToastContextType) => {
    toastInstance = context;
};

export const toast = {
    success: (message: string) => {
        toastInstance?.addToast(message, 'success');
    },
    error: (message: string) => {
        toastInstance?.addToast(message, 'error');
    },
    info: (message: string) => {
        toastInstance?.addToast(message, 'info');
    },
    warning: (message: string) => {
        toastInstance?.addToast(message, 'warning');
    },
};
