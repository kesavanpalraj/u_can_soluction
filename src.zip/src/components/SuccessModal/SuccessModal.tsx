import { useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';
import { Icon } from '@iconify/react';
import { ArrowLeft } from 'lucide-react';
import styles from './SuccessModal.module.css';

interface SuccessModalProps {
    isOpen: boolean;
    onClose: () => void;
    title: string;
    message: string;
}

export const SuccessModal: React.FC<SuccessModalProps> = ({ isOpen, onClose, title, message }) => {
    const fired = useRef(false);

    useEffect(() => {
        if (isOpen && !fired.current) {
            fired.current = true;
            const defaults = { particleCount: 80, spread: 70, origin: { y: 0.6 }, zIndex: 10000 };
            confetti({ ...defaults, angle: 60 });
            confetti({ ...defaults, angle: 120 });
        }
        if (!isOpen) {
            fired.current = false;
        }
    }, [isOpen]);

    useEffect(() => {
        if (!isOpen) return;
        const handleEscape = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
        document.addEventListener('keydown', handleEscape);
        document.body.style.overflow = 'hidden';
        return () => {
            document.removeEventListener('keydown', handleEscape);
            document.body.style.overflow = '';
        };
    }, [isOpen, onClose]);

    if (!isOpen) return null;

    return (
        <div className={styles.overlay} onClick={onClose}>
            <div className={styles.modal} onClick={(e) => e.stopPropagation()}>
                <div className={styles.iconWrap}>
                  <Icon icon="twemoji:party-popper" width={56} height={56} />
                </div>
                <h2 className={styles.title}>{title}</h2>
                <p className={styles.message}>{message}</p>
                <button className={styles.button} onClick={onClose}>
                  <ArrowLeft size={16} />
                  <span>Back</span>
                </button>
            </div>
        </div>
    );
};
