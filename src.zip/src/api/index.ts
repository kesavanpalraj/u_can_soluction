import { Category, Project, ProjectEnquiry, Course, CourseEnquiry, PaginatedResponse } from '../types';

const API_BASE = '/api';

async function fetchApi<T>(
    endpoint: string,
    options?: RequestInit
): Promise<T> {
    const response = await fetch(`${API_BASE}${endpoint}`, {
        headers: {
            'Content-Type': 'application/json',
        },
        ...options,
    });

    if (!response.ok) {
        const error = await response.json().catch(() => ({ message: 'Request failed' }));
        throw new Error(error.message || 'Request failed');
    }

    return response.json();
}

export const categoryApi = {
    getAll: (): Promise<Category[]> => {
        return fetchApi<Category[]>('/categories?type=project');
    },
};

export const projectApi = {
    getAll: (params?: {
        category?: string;
        search?: string;
        page?: number;
        limit?: number;
    }): Promise<PaginatedResponse<Project>> => {
        const searchParams = new URLSearchParams();
        if (params?.category && params.category !== 'All') {
            searchParams.set('category', params.category);
        }
        if (params?.search) {
            searchParams.set('search', params.search);
        }
        if (params?.page) {
            searchParams.set('page', String(params.page));
        }
        if (params?.limit) {
            searchParams.set('limit', String(params.limit));
        }

        const queryString = searchParams.toString();
        const endpoint = `/projects${queryString ? `?${queryString}` : ''}`;
        return fetchApi<PaginatedResponse<Project>>(endpoint);
    },

    getById: (id: string): Promise<Project> => {
        return fetchApi<Project>(`/projects/${id}`);
    },
};

export const courseApi = {
    getAll: (params?: {
        category?: string;
        search?: string;
        page?: number;
        limit?: number;
    }): Promise<PaginatedResponse<Course>> => {
        const searchParams = new URLSearchParams();
        if (params?.category && params.category !== 'All') {
            searchParams.set('category', params.category);
        }
        if (params?.search) {
            searchParams.set('search', params.search);
        }
        if (params?.page) {
            searchParams.set('page', String(params.page));
        }
        if (params?.limit) {
            searchParams.set('limit', String(params.limit));
        }

        const queryString = searchParams.toString();
        const endpoint = `/courses${queryString ? `?${queryString}` : ''}`;
        return fetchApi<PaginatedResponse<Course>>(endpoint);
    },

    getById: (id: string): Promise<Course> => {
        return fetchApi<Course>(`/courses/${id}`);
    },
};

export const courseEnquiryApi = {
    submit: (data: Omit<CourseEnquiry, '_id' | 'status'>): Promise<CourseEnquiry> => {
        return fetchApi<CourseEnquiry>('/courses/enquiries', {
            method: 'POST',
            body: JSON.stringify(data),
        });
    },
};

export const projectPdfApi = {
    get: (): Promise<{ url: string }> => {
        return fetchApi<{ url: string }>('/project-pdf');
    },
    update: (url: string): Promise<{ url: string }> => {
        return fetchApi<{ url: string }>('/project-pdf', {
            method: 'PUT',
            body: JSON.stringify({ url }),
        });
    },
};

export interface NewsEvent {
    _id: string;
    title: string;
    type: 'news' | 'event';
    link: string;
    isActive: boolean;
    order: number;
    createdAt: string;
    updatedAt: string;
}

export const newsEventApi = {
    getActive: (): Promise<NewsEvent[]> => {
        return fetchApi<NewsEvent[]>('/news-events');
    },
    getAll: (): Promise<NewsEvent[]> => {
        return fetchApi<NewsEvent[]>('/news-events/all');
    },
    create: (data: Partial<NewsEvent>): Promise<NewsEvent> => {
        return fetchApi<NewsEvent>('/news-events', {
            method: 'POST',
            body: JSON.stringify(data),
        });
    },
    update: (id: string, data: Partial<NewsEvent>): Promise<NewsEvent> => {
        return fetchApi<NewsEvent>(`/news-events/${id}`, {
            method: 'PUT',
            body: JSON.stringify(data),
        });
    },
    remove: (id: string): Promise<void> => {
        return fetchApi<void>(`/news-events/${id}`, {
            method: 'DELETE',
        });
    },
};

export const enquiryApi = {
    submit: (data: Omit<ProjectEnquiry, '_id' | 'status'>): Promise<ProjectEnquiry> => {
        return fetchApi<ProjectEnquiry>('/projects/enquiries', {
            method: 'POST',
            body: JSON.stringify(data),
        });
    },
};

export interface HomepageSettings {
    _id?: string;
    googleRating: { rating: number; count: number };
    stats: { value: number; suffix: string; label: string }[];
    testimonials: { _id?: string; name: string; profilePic: string; rating: number; text: string }[];
}

export const homepageSettingsApi = {
    get: (): Promise<HomepageSettings> => {
        return fetchApi<HomepageSettings>('/homepage-settings');
    },
    update: (data: Partial<HomepageSettings>): Promise<HomepageSettings> => {
        return fetchApi<HomepageSettings>('/homepage-settings', {
            method: 'PUT',
            body: JSON.stringify(data),
        });
    },
};

export interface AboutSettings {
    _id?: string;
    aboutTitle: string;
    aboutParagraphs: string[];
    team: { _id?: string; name: string; role: string; image: string; description: string }[];
    gallery: { _id?: string; alt: string; image: string }[];
}

export const aboutSettingsApi = {
    get: (): Promise<AboutSettings> => {
        return fetchApi<AboutSettings>('/about-settings');
    },
    update: (data: Partial<AboutSettings>): Promise<AboutSettings> => {
        return fetchApi<AboutSettings>('/about-settings', {
            method: 'PUT',
            body: JSON.stringify(data),
        });
    },
};

export interface AuthResponse {
    token?: string;
    resetToken?: string;
    email?: string;
    message?: string;
}

export const authApi = {
    login: (email: string, password: string): Promise<AuthResponse> =>
        fetchApi<AuthResponse>('/auth/login', {
            method: 'POST',
            body: JSON.stringify({ email, password }),
        }),
    forgotPassword: (email: string): Promise<AuthResponse> =>
        fetchApi<AuthResponse>('/auth/forgot-password', {
            method: 'POST',
            body: JSON.stringify({ email }),
        }),
    verifyOtp: (email: string, otp: string): Promise<AuthResponse> =>
        fetchApi<AuthResponse>('/auth/verify-otp', {
            method: 'POST',
            body: JSON.stringify({ email, otp }),
        }),
    resetPassword: (resetToken: string, password: string): Promise<AuthResponse> =>
        fetchApi<AuthResponse>('/auth/reset-password', {
            method: 'POST',
            body: JSON.stringify({ resetToken, password }),
        }),
    changePassword: (currentPassword: string, newPassword: string, token: string): Promise<AuthResponse> =>
        fetchApi<AuthResponse>('/auth/change-password', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({ currentPassword, newPassword }),
        }),
    me: (token: string): Promise<AuthResponse & { notificationsEnabled?: boolean }> =>
        fetchApi<AuthResponse>('/auth/me', {
            headers: { Authorization: `Bearer ${token}` },
        }),
    updateNotifications: (enabled: boolean, token: string): Promise<{ notificationsEnabled: boolean }> =>
        fetchApi<{ notificationsEnabled: boolean }>('/auth/notifications', {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({ enabled }),
        }),
};

export const uploadApi = {
    upload: async (file: File): Promise<{ url: string }> => {
        const formData = new FormData();
        formData.append('image', file);
        const res = await fetch('/api/upload', { method: 'POST', body: formData });
        if (!res.ok) {
            const err = await res.json().catch(() => ({ message: 'Upload failed' }));
            throw new Error(err.message);
        }
        return res.json();
    },
    delete: (url: string): Promise<void> => {
        return fetchApi<void>('/upload', {
            method: 'DELETE',
            body: JSON.stringify({ url }),
        });
    },
};

export interface InternshipDomain {
    _id: string;
    name: string;
    order: number;
}

export const internshipDomainApi = {
    getAll: (): Promise<InternshipDomain[]> => {
        return fetchApi<InternshipDomain[]>('/internships/domains');
    },
    create: (data: Partial<InternshipDomain>): Promise<InternshipDomain> => {
        return fetchApi<InternshipDomain>('/internships/domains', {
            method: 'POST',
            body: JSON.stringify(data),
        });
    },
    update: (id: string, data: Partial<InternshipDomain>): Promise<InternshipDomain> => {
        return fetchApi<InternshipDomain>(`/internships/domains/${id}`, {
            method: 'PUT',
            body: JSON.stringify(data),
        });
    },
    remove: (id: string): Promise<void> => {
        return fetchApi<void>(`/internships/domains/${id}`, {
            method: 'DELETE',
        });
    },
};

export interface InternshipDuration {
    _id: string;
    name: string;
    order: number;
}

export const internshipDurationApi = {
    getAll: (): Promise<InternshipDuration[]> => {
        return fetchApi<InternshipDuration[]>('/internships/durations');
    },
    create: (data: Partial<InternshipDuration>): Promise<InternshipDuration> => {
        return fetchApi<InternshipDuration>('/internships/durations', {
            method: 'POST',
            body: JSON.stringify(data),
        });
    },
    update: (id: string, data: Partial<InternshipDuration>): Promise<InternshipDuration> => {
        return fetchApi<InternshipDuration>(`/internships/durations/${id}`, {
            method: 'PUT',
            body: JSON.stringify(data),
        });
    },
    remove: (id: string): Promise<void> => {
        return fetchApi<void>(`/internships/durations/${id}`, {
            method: 'DELETE',
        });
    },
};
