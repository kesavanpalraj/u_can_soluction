export interface Category {
    _id: string;
    name: string;
    slug: string;
    order: number;
    isActive: boolean;
}

export interface Project {
    _id: string;
    projectId: string;
    title: string;
    description: string;
    category: Category | string;
    tags: string[];
    downloadAbstract: string;
    youtubeUrl: string;
    isActive: boolean;
}

export interface CourseTech {
    icon: string;
    label: string;
}

export interface Course {
    _id: string;
    courseId: string;
    title: string;
    description: string;
    mode: 'Online' | 'Offline' | 'Online-Offline';
    price: number;
    tags: string[];
    technologies: CourseTech[];
    coverage: string[];
    status: string;
    createdAt: string;
    updatedAt: string;
}

export interface ProjectEnquiry {
    _id?: string;
    project: string | Project;
    projectId?: string;
    name: string;
    email: string;
    phone: string;
    address?: string;
    degree?: string;
    college?: string;
    message?: string;
    status?: 'new' | 'contacted' | 'enrolled' | 'lost';
}

export interface CourseEnquiry {
    _id?: string;
    course: string | Course;
    name: string;
    email: string;
    phone: string;
    address?: string;
    degree?: string;
    college?: string;
    message?: string;
    status?: string;
}

export interface PaginatedResponse<T> {
    projects?: T[];
    courses?: T[];
    enquiries?: T[];
    total: number;
    page: number;
    totalPages: number;
}
